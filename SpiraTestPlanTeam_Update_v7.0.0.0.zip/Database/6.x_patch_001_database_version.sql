-- =====================================================================
-- Author:			Inflectra Corporation
-- =====================================================================
UPDATE [TST_GLOBAL_SETTING]
SET VALUE = '674' WHERE NAME = 'Database_Revision'
GO
