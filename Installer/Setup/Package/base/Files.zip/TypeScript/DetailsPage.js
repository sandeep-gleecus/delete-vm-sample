var PageProps = (function () {
    function PageProps() {
    }
    return PageProps;
}());
var pageProps = new PageProps();
var u_params = {
    width_lg: 992,
    width_md: 768,
    width_sm: 554,
    names: {
        base: 'width_',
        lg: 'width_lg',
        md: 'width_md',
        sm: 'width_sm',
        xs: 'width_xs'
    },
};
var artifactNameResizeContainer, artifactNameResizeChecker, artifactNameResizeField;
var initialLoad = true;
function artifactNameAutoResize() {
    if (artifactNameResizeField) {
        $(artifactNameResizeChecker).text(artifactNameResizeField.value + '\n');
    }
}
;
$(function () {
    uWrapper_onResize();
    if (SpiraContext.HasCollapsiblePanels) {
        Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.CollapsiblePanel_RetrieveStateAll(SpiraContext.pageId, retrieveCollapsiblePanelStates_Success, retrieveCollapsiblePanelStates_Success);
    }
    function setThemeIcons() {
        var iconList = document.querySelectorAll("img[data-themeIcon]");
        if (iconList.length) {
            for (var _i = 0, _a = iconList; _i < _a.length; _i++) {
                var icon = _a[_i];
                icon.src = SpiraContext.BaseThemeUrl + "Images/" + icon.dataset.themeicon;
            }
        }
    }
    setThemeIcons();
    function retrieveCollapsiblePanelStates_Success(data) {
        var collapsedPanels = data.filter(function (item) {
            return item.value === "Y";
        }).map(function (item) {
            return item.key;
        });
        $('[data-collapsible]').each(function (group) {
            if (collapsedPanels.indexOf($(this).attr("id")) >= 0) {
                var headerElement = $(this).find(".u-box_header");
                manageFieldGroupExpandCollapse(headerElement);
            }
        });
    }
    function retrieveCollapsiblePanelStates_Failure(err) {
        console.log(err);
    }
    $('.u-box_header').on('click', function (e) {
        e.preventDefault();
        manageFieldGroupExpandCollapse(this);
    });
    hideEmptyFieldGroups();
    if (!SpiraContext.IsEmailEnabled) {
        $('[data-requires-email="true"]').hide();
    }
});
$(window).on("resize", function () {
    uWrapper_onResize();
});
document.addEventListener("DOMContentLoaded", function () {
    artifactNameResizeContainer = document.querySelector('.textarea-resize_container');
    if (artifactNameResizeContainer) {
        artifactNameResizeChecker = artifactNameResizeContainer.querySelector('.textarea-resize_checker');
        artifactNameResizeField = artifactNameResizeContainer.querySelector('.textarea-resize_field');
        artifactNameAutoResize();
        if (artifactNameResizeField) {
            artifactNameResizeField.addEventListener('input', artifactNameAutoResize);
            artifactNameResizeField.addEventListener('keypress', function (event) {
                if (event.keyCode == 13)
                    event.preventDefault();
            });
        }
    }
});
function uWrapper_onResize() {
    $(".u-wrapper.".concat(u_params.names.lg, ", .u-wrapper.").concat(u_params.names.md, ", .u-wrapper.").concat(u_params.names.sm, ", .u-wrapper.").concat(u_params.names.xs)).each(function resizeWrapper() {
        var wrapperWidth = $(this).width(), originalWidthClass = $(this).hasClass(u_params.names.lg) ? u_params.names.lg :
            $(this).hasClass(u_params.names.md) ? u_params.names.md :
                $(this).hasClass(u_params.names.sm) ? u_params.names.sm :
                    $(this).hasClass(u_params.names.xs) ? u_params.names.xs : null, widthClass = '';
        if (wrapperWidth >= u_params.width_lg) {
            widthClass = u_params.names.lg;
        }
        else if (wrapperWidth >= u_params.width_md) {
            widthClass = u_params.names.md;
        }
        else if (wrapperWidth >= u_params.width_sm) {
            widthClass = u_params.names.sm;
        }
        else {
            widthClass = u_params.names.xs;
        }
        if (widthClass !== originalWidthClass) {
            var allWidthClasses = "".concat(u_params.names.lg, " ").concat(u_params.names.md, " ").concat(u_params.names.sm, " ").concat(u_params.names.xs);
            $(this).removeClass(allWidthClasses).addClass(widthClass);
        }
    });
}
;
function manageFieldGroupExpandCollapse(el) {
    var oldState = $(el).attr("aria-expanded"), newState = oldState === "true" ? false : true, isCollapsed = !newState;
    $(el).attr("aria-expanded", newState.toString());
    $(el).find('.u-anim_open-close').toggleClass('is-open o-1-always');
    var groupParentId = $(el).closest('[data-collapsible="true"]').attr('id');
    Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.CollapsiblePanel_UpdateState(SpiraContext.pageId, groupParentId, isCollapsed, updatePanelState_Success, updatePanelState_Failure);
    function updatePanelState_Success(data) {
    }
    function updatePanelState_Failure(err) {
    }
}
;
function hideEmptyFieldGroups() {
    $(".u-box_group .u-box_list")
        .filter(function () {
        return !($(this).children().is('li'));
    })
        .parent()
        .hide();
}
;
function showNonEmptyFieldGroups() {
    $(".u-box_group .u-box_list")
        .filter(function () {
        return ($(this).children().is('li'));
    })
        .parent()
        .show();
}
;
function loadFollowersBox(projectId, artifactTypeId, artifactId) {
    followers.dropMenu = btnSubscribe_id;
    followers.getFollowersList(projectId, artifactTypeId, artifactId);
}
;
function ajxFormManager_dataSaved(operation, newArtifactId) {
    var ajxFormManager = $find(ajxFormManager_id);
    if (operation == 'close') {
        ajxFormManager.set_suppressErrors(true);
        window.location.href = urlTemplate_artifactListUrl;
    }
    if (operation == 'new') {
        if (newArtifactId) {
            ajxFormManager.set_suppressErrors(true);
            ajxFormManager.set_primaryKey(newArtifactId, true);
            ajxFormManager.load_data();
            if (history && history.pushState) {
                var href = urlTemplate_artifactRedirectUrl.replace(globalFunctions.artifactIdToken, '' + newArtifactId);
                history.pushState(newArtifactId, null, href);
            }
        }
        else {
            ajxFormManager.set_suppressErrors(true);
            SpiraContext.Mode = 'new';
            ajxFormManager.set_primaryKey(null, true);
            ajxFormManager.load_data();
            if (history && history.pushState) {
                var href = urlTemplate_artifactNew;
                history.pushState(null, null, href);
            }
            if (!SpiraContext.PlaceholderId) {
                Inflectra.SpiraTest.Web.Services.Ajax.PlaceHolderService.PlaceHolder_GetNextId(SpiraContext.ProjectId, function (placeholderId) {
                    SpiraContext.PlaceholderId = placeholderId;
                    $('#' + hdnPlaceholderId_id).val(SpiraContext.PlaceholderId);
                });
            }
            else {
                $('#' + hdnPlaceholderId_id).val(SpiraContext.PlaceholderId);
            }
        }
    }
    if (operation == 'redirect' && newArtifactId) {
        ajxFormManager.set_suppressErrors(true);
        SpiraContext.Mode = 'update';
        SpiraContext.ArtifactId = newArtifactId;
        ajxFormManager.set_primaryKey(newArtifactId, true);
        ajxFormManager.load_data();
        if (history && history.pushState) {
            var newIncidentUrl = urlTemplate_artifactRedirectUrl.replace(globalFunctions.artifactIdToken, newArtifactId);
            history.pushState(null, null, newIncidentUrl);
        }
    }
}
function ajxFormManager_loaded(dontClearMessages) {
    var ajxFormManager = $find(ajxFormManager_id);
    if (ajxFormManager.get_dataItem() == null) {
        ajxFormManager.set_suppressErrors(true);
        window.location.href = urlTemplate_projectHome + "?errorMessage=" + resx.ArtifactDetails_ArtifactNotFound;
        return;
    }
    SpiraContext.ArtifactId = ajxFormManager.get_primaryKey();
    SpiraContext.IsArtifactCreatorOrOwner = ajxFormManager.get_isArtifactCreatorOrOwner();
    artifactNameAutoResize();
    var url;
    var isAuthorizedToAttachDocuments = false;
    if (SpiraContext.Mode == 'new') {
        url = urlTemplate_screenshot.replace('{0}', SpiraContext.PlaceholderId);
        url = url.replace('{1}', SpiraContext.PlaceholderArtifactTypeId);
    }
    else {
        url = urlTemplate_screenshot.replace('{0}', SpiraContext.ArtifactId);
        url = url.replace('{1}', SpiraContext.ArtifactTypeId);
    }
    if (typeof (CKEDITOR) != 'undefined' && CKEDITOR) {
        pageProps.screenshotUploadUrl = url;
        for (var instanceName in CKEDITOR.instances) {
            CKEDITOR.instances[instanceName].config.uploadUrl = pageProps.screenshotUploadUrl;
        }
    }
    if (SpiraContext.Mode == 'update') {
        if (typeof (lstComments_id) !== 'undefined') {
            var lstComments = $find(lstComments_id);
            lstComments.set_artifactId(SpiraContext.ArtifactId);
            lstComments.load_data(dontClearMessages);
        }
        var isAuthorizedToModify = false;
        var authorizedState = globalFunctions.isAuthorized(globalFunctions.permissionEnum.Modify, SpiraContext.ArtifactTypeId);
        if (authorizedState != globalFunctions.authorizationStateEnum.prohibited) {
            var isCreatorOrOwner = ajxFormManager.get_isArtifactCreatorOrOwner();
            if (authorizedState == globalFunctions.authorizationStateEnum.authorized || isCreatorOrOwner) {
                isAuthorizedToModify = true;
            }
        }
        if (typeof (btnSave_id) !== 'undefined') {
            $find(btnSave_id).set_authorized(isAuthorizedToModify);
        }
        if (typeof (btnSubscribe_id) !== 'undefined' && btnSubscribe_id) {
            ArtifactEmail_isUserSubscribed(SpiraContext.ProjectId, SpiraContext.ArtifactTypeId, SpiraContext.ArtifactId, $find(btnSubscribe_id));
            loadFollowersBox(SpiraContext.ProjectId, SpiraContext.ArtifactTypeId, SpiraContext.ArtifactId);
        }
    }
    else if (SpiraContext.Mode == 'new') {
        if (typeof (lstComments_id) !== 'undefined') {
            var lstComments = $find(lstComments_id);
            lstComments.set_artifactId(SpiraContext.ArtifactId);
            lstComments.retrieve_success(null);
        }
    }
    updateOtherTabs();
    if (!initialLoad && typeof (navigationBar_id) != 'undefined' && navigationBar_id) {
        var navigationBar = $find(navigationBar_id);
        navigationBar.set_selectedItemId(SpiraContext.ArtifactId);
        navigationBar.refresh_data(dontClearMessages);
    }
    else {
        initialLoad = false;
    }
    if (typeof (updatePageContent) != 'undefined') {
        updatePageContent();
    }
    if (typeof (tstucMessageManager) != 'undefined' && tstucMessageManager) {
        tstucMessageManager.set_artifactId(SpiraContext.ArtifactId);
    }
    if (SpiraContext.ProjectId && SpiraContext.ArtifactTypeId && SpiraContext.ArtifactId) {
        Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.UserSettings_UpdateRecentArtifact(SpiraContext.ProjectId, SpiraContext.ArtifactTypeId, SpiraContext.ArtifactId);
    }
    showHideToolbars();
}
;
function showHideToolbars() {
    if (SpiraContext.Mode == 'new') {
        var tabParent = $find(tabControl_id), overviewTab = tabParent.get_tabPage('tabOverview');
        tabParent._onClick(tabParent, { thisRef: tabParent, tabPage: overviewTab });
        var tabAssociations = $find(tabControl_id).get_tabPage('tabAssociations');
        if (tabAssociations) {
            tabAssociations.hide();
        }
        ;
        var commentSection = document.getElementById("form-group_comments");
        commentSection && $(commentSection).hide();
        $find(tabControl_id).get_tabPage('tabHistory').hide();
        if (typeof (btnNewComment_id) != 'undefined' && btnNewComment_id) {
            $('#' + btnNewComment_id).hide();
        }
        $('#plcToolbar').hide();
        $('#emailpalce').hide();
        $('#divMitigationsPanel1').hide();
        $('#Commentspaneel1').hide();
        $('#Commentspaneel2').hide();
        $('#divMitigationsPanel').hide();
    }
    else {
        if (typeof (btnEmail_id) != 'undefined' && btnEmail_id) {
            if (SpiraContext.EmailEnabled) {
                $('#' + btnEmail_id).show();
            }
            else {
                $('#' + btnEmail_id).hide();
            }
        }
        var tabAssociations = typeof tabControl_id != "undefined" ? $find(tabControl_id).get_tabPage('tabAssociations') : null;
        if (tabAssociations) {
            tabAssociations.show();
        }
        var tabHistory = typeof tabControl_id != "undefined" ? $find(tabControl_id).get_tabPage('tabHistory') : null;
        if (tabHistory) {
            tabHistory.show();
        }
        if (typeof (btnNewComment_id) != 'undefined' && btnNewComment_id) {
            var commentSection = document.getElementById("form-group_comments");
            commentSection && $(commentSection).show();
            if (SpiraContext.CanUserAddCommentToArtifacts) {
                $('#' + btnNewComment_id).show();
            }
            else {
                $('#' + btnNewComment_id).hide();
            }
        }
        $('#plcToolbar').show();
        $('#emailtool').show();
        $('#divMitigationsPanel').show();
        $('#Commentsdiv').show();
        $('#divMitigationsPanel1').show();
        $('#Commentspaneel1').show();
        $('#Commentspaneel2').show();
    }
}
function updateOtherTabs() {
    if (typeof (tstucAttachmentPanel) != 'undefined' && tstucAttachmentPanel) {
        if (SpiraContext.Mode == 'new') {
            tstucAttachmentPanel.set_artifactId(SpiraContext.PlaceholderId);
            tstucAttachmentPanel.set_artifactTypeId(SpiraContext.PlaceholderArtifactTypeId);
            tstucAttachmentPanel.check_hasData(attachment_callback);
            var filters = {};
            filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.PlaceholderId);
            filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.PlaceholderArtifactTypeId);
            tstucAttachmentPanel.load_data(filters, loadNow);
        }
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucAttachmentPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucAttachmentPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucAttachmentPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucAttachmentPanel.check_hasData(attachment_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlAttachments_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                tstucAttachmentPanel.load_data(filters, loadNow);
            }
            else {
                tstucAttachmentPanel.update_permissions();
            }
        }
    }
    if (typeof (tstucHistoryPanel) != 'undefined' && tstucHistoryPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucHistoryPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucHistoryPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucHistoryPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucHistoryPanel.check_hasData(history_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlHistory_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                filters[globalFunctions.keyPrefix + 'IsProjectAdmin'] = globalFunctions.serializeValueBool(SpiraContext.IsProjectAdmin);
                if (pageProps.includeStepHistory) {
                    filters[globalFunctions.keyPrefix + 'IncludeSteps'] = globalFunctions.serializeValueBool(true);
                }
                tstucHistoryPanel.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstucBaselinePanel) != 'undefined' && tstucBaselinePanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucBaselinePanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucBaselinePanel.set_artifactId(SpiraContext.ArtifactId);
            tstucBaselinePanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucBaselinePanel.check_hasData(baseline_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlBaseline_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                filters[globalFunctions.keyPrefix + 'IsProjectAdmin'] = globalFunctions.serializeValueBool(SpiraContext.IsProjectAdmin);
                tstucBaselinePanel.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstuc_cplMainContent_tstCoveragePanel) != 'undefined' && tstuc_cplMainContent_tstCoveragePanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstuc_cplMainContent_tstCoveragePanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstuc_cplMainContent_tstCoveragePanel.set_artifactId(SpiraContext.ArtifactId);
            tstuc_cplMainContent_tstCoveragePanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstuc_cplMainContent_tstCoveragePanel.check_hasData(coverage_callback);
            if (artifactChanged) {
                tstuc_cplMainContent_tstCoveragePanel.closeAddAssocationPanel();
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlCoverage_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                tstuc_cplMainContent_tstCoveragePanel.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstuc_cplMainContent_tstTestCaseMapping) != 'undefined' && tstuc_cplMainContent_tstTestCaseMapping) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstuc_cplMainContent_tstTestCaseMapping.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstuc_cplMainContent_tstTestCaseMapping.set_artifactId(SpiraContext.ArtifactId);
            tstuc_cplMainContent_tstTestCaseMapping.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstuc_cplMainContent_tstTestCaseMapping.check_hasData(testCases_callback);
            if (artifactChanged) {
                tstuc_cplMainContent_tstTestCaseMapping.closeAddAssocationPanel();
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlTestCases_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                tstuc_cplMainContent_tstTestCaseMapping.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstuc_cplMainContent_tstReleaseMappingPanel) != 'undefined' && tstuc_cplMainContent_tstReleaseMappingPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstuc_cplMainContent_tstReleaseMappingPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstuc_cplMainContent_tstReleaseMappingPanel.set_artifactId(SpiraContext.ArtifactId);
            tstuc_cplMainContent_tstReleaseMappingPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstuc_cplMainContent_tstReleaseMappingPanel.check_hasData(releases_callback);
            if (artifactChanged) {
                tstuc_cplMainContent_tstReleaseMappingPanel.closeAddAssocationPanel();
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlReleases_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                tstuc_cplMainContent_tstReleaseMappingPanel.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstucDiagramPanel) != 'undefined' && tstucDiagramPanel) {
        var ajxFormManager = $find(ajxFormManager_id);
        var hasSteps = false;
        var dataItem = ajxFormManager.get_dataItem();
        if (dataItem != null && dataItem.alternate) {
            hasSteps = true;
        }
        if (SpiraContext.ProductType == 'SpiraTest' || !hasSteps) {
            var tabControl = $find(tabControl_id);
            tabControl.get_tabPage('tabDiagram').hide();
            if (tabControl.get_selectedTabClientId() == pnlDiagram_id) {
                tabControl.set_selectedTabClientId(pnlOverview_id);
            }
        }
        else {
            $find(tabControl_id).get_tabPage('tabDiagram').show();
            var artifactChanged = false;
            if (tstucDiagramPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucDiagramPanel.set_artifactId(SpiraContext.ArtifactId);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlDiagram_id);
                tstucDiagramPanel.load_data(null, loadNow);
            }
        }
    }
    if (typeof (tstucTaskListPanel) != 'undefined' && tstucTaskListPanel) {
        if (SpiraContext.Mode == 'new') {
            $find(tabControl_id).get_tabPage('tabTasks').hide();
        }
        if (SpiraContext.Mode == 'update') {
            $find(tabControl_id).get_tabPage('tabTasks').show();
            var artifactChanged = false;
            if (tstucTaskListPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucTaskListPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucTaskListPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucTaskListPanel.check_hasData(tasks_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlTasks_id);
                var filters = {};
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.requirement) {
                    filters[globalFunctions.keyPrefix + 'RequirementId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTaskListPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.risk) {
                    filters[globalFunctions.keyPrefix + 'RiskId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTaskListPanel.load_data(filters, loadNow);
                }
            }
        }
    }
    if (typeof (tstucRequirementTaskPanel) != 'undefined' && tstucRequirementTaskPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucRequirementTaskPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucRequirementTaskPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucRequirementTaskPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucRequirementTaskPanel.check_hasData(requirementTasks_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlReqsTasks_id);
                var filters = {};
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.release) {
                    filters[globalFunctions.keyPrefix + 'ReleaseId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucRequirementTaskPanel.load_data(filters, loadNow);
                }
            }
        }
    }
    if (typeof tstuc_cplMainContent_tstAssociationPanel != 'undefined' && tstuc_cplMainContent_tstAssociationPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstuc_cplMainContent_tstAssociationPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstuc_cplMainContent_tstAssociationPanel.set_artifactId(SpiraContext.ArtifactId);
            tstuc_cplMainContent_tstAssociationPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstuc_cplMainContent_tstAssociationPanel.check_hasData(associations_callback);
            if (artifactChanged) {
                tstuc_cplMainContent_tstAssociationPanel.closeAddAssocationPanel();
                var loadNow = typeof pnlAssociations_id == 'undefined' || ($find(tabControl_id).get_selectedTabClientId() == pnlAssociations_id);
                var filters = {};
                filters[globalFunctions.keyPrefix + 'ArtifactId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                filters[globalFunctions.keyPrefix + 'ArtifactType'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactTypeId);
                tstuc_cplMainContent_tstAssociationPanel.load_data(filters, loadNow);
            }
        }
    }
    if (typeof (tstucTestRunPanel) != 'undefined' && tstucTestRunPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucTestRunPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucTestRunPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucTestRunPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucTestRunPanel.check_hasData(testRuns_callback);
            if (artifactChanged) {
                var loadNow = typeof tabControl_id != 'undefined' ? ($find(tabControl_id).get_selectedTabClientId() == pnlTestRuns_id) : true;
                var filters = {};
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testCase) {
                    filters[globalFunctions.keyPrefix + 'TestCaseId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestRunPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testSet) {
                    filters[globalFunctions.keyPrefix + 'TestSetId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestRunPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.release) {
                    filters[globalFunctions.keyPrefix + 'ReleaseId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestRunPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.automationHost) {
                    filters[globalFunctions.keyPrefix + 'AutomationHostId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestRunPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.build) {
                    filters[globalFunctions.keyPrefix + 'BuildId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestRunPanel.load_data(filters, loadNow);
                }
            }
        }
    }
    if (typeof (tstucIncidentPanel) != 'undefined' && tstucIncidentPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucIncidentPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucIncidentPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucIncidentPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucIncidentPanel.check_hasData(incidents_callback);
            if (artifactChanged) {
                var loadNow = typeof tabControl_id != 'undefined' ? ($find(tabControl_id).get_selectedTabClientId() == pnlIncidents_id) : true;
                var filters = {};
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testCase) {
                    filters[globalFunctions.keyPrefix + 'TestCaseId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucIncidentPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testSet) {
                    filters[globalFunctions.keyPrefix + 'TestSetId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucIncidentPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testRun) {
                    filters[globalFunctions.keyPrefix + 'TestRunId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucIncidentPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testStep) {
                    filters[globalFunctions.keyPrefix + 'TestStepId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucIncidentPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.build) {
                    filters[globalFunctions.keyPrefix + 'BuildId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucIncidentPanel.load_data(filters, loadNow);
                }
            }
        }
    }
    if (typeof (tstucTestSetPanel) != 'undefined' && tstucTestSetPanel) {
        if (SpiraContext.Mode == 'update') {
            var artifactChanged = false;
            if (tstucTestSetPanel.get_artifactId() != SpiraContext.ArtifactId) {
                artifactChanged = true;
            }
            tstucTestSetPanel.set_artifactId(SpiraContext.ArtifactId);
            tstucTestSetPanel.set_artifactTypeId(SpiraContext.ArtifactTypeId);
            tstucTestSetPanel.check_hasData(testSets_callback);
            if (artifactChanged) {
                var loadNow = ($find(tabControl_id).get_selectedTabClientId() == pnlTestSets_id);
                var filters = {};
                tstucTestSetPanel.load_data(filters, loadNow);
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testCase) {
                    filters[globalFunctions.keyPrefix + 'TestCaseId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestSetPanel.load_data(filters, loadNow);
                }
                if (SpiraContext.ArtifactTypeId == globalFunctions.artifactTypeEnum.testConfigurationSet) {
                    filters[globalFunctions.keyPrefix + 'TestConfigurationSetId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
                    tstucTestSetPanel.load_data(filters, loadNow);
                }
            }
        }
    }
}
function attachment_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabAttachments', hasData);
}
function history_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabHistory', hasData);
}
function associations_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabAssociations', hasData);
}
function testRuns_callback(hasData) {
    if (typeof tabControl_id != "undefined") {
        $find(tabControl_id).updateHasData('tabTestRuns', hasData);
    }
    else if (typeof pnlTestRuns_id != "undefined") {
        if (!hasData) {
            document.getElementById(pnlTestRuns_id).classList.add("dn");
        }
        else {
            document.getElementById(pnlTestRuns_id).classList.remove("dn");
        }
    }
}
function testSets_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabTestSets', hasData);
}
function incidents_callback(hasData) {
    if (typeof tabControl_id != "undefined") {
        $find(tabControl_id).updateHasData('tabIncidents', hasData);
    }
    else if (typeof pnlIncidents_id != "undefined") {
        if (!hasData) {
            document.getElementById(pnlIncidents_id).classList.add("dn");
        }
        else {
            document.getElementById(pnlIncidents_id).classList.remove("dn");
        }
    }
}
function tasks_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabTasks', hasData);
}
function coverage_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabCoverage', hasData);
}
function releases_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabReleases', hasData);
}
function testCases_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabTestCases', hasData);
}
function requirementTasks_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabTasks', hasData);
}
function baseline_callback(hasData) {
    typeof tabControl_id != "undefined" && $find(tabControl_id).updateHasData('tabBaseline', hasData);
}
//# sourceMappingURL=DetailsPage.js.map