/***************************************************************
**	Insert script for table TST_RISK
***************************************************************/
SET IDENTITY_INSERT TST_RISK ON; 

INSERT INTO TST_RISK
(
RISK_ID, RISK_IMPACT_ID, RISK_STATUS_ID, RISK_PROBABILITY_ID, RISK_TYPE_ID, PROJECT_ID, CREATOR_ID, OWNER_ID, RELEASE_ID, COMPONENT_ID, NAME, DESCRIPTION, IS_DELETED, CREATION_DATE, LAST_UPDATE_DATE, CONCURRENCY_DATE, CLOSED_DATE, IS_ATTACHMENTS
)
VALUES
(
1, 2, 4, 1, 4, 1, 2, 2, 4, NULL, 'The v1.1 release may not be ready in time', '<p>Due to some resourcing issues, there is a possibility that we will not make the expected go-live date.</p>', 0, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -6, SYSUTCDATETIME()), DATEADD(day, -6, SYSUTCDATETIME()), NULL, 0
),
(
2, 1, 4, 4, 1, 1, 2, 2, 1, 2, 'We may not get enough authors to sign up', '<p>We may not get enough authors to sign up to the platform, making it unattractive to potential library systems</p>', 0, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -6, SYSUTCDATETIME()), DATEADD(day, -6, SYSUTCDATETIME()), NULL, 0
),
(
3, 2, 2, 4, 2, 1, 2, 3, 1, NULL, 'The database may not support the volume', '<p>We have chosen a low end database platform for this application and it may not be sufficient to handle the number of queries we may receive.</p>', 0, DATEADD(day, -9, SYSUTCDATETIME()), DATEADD(day, -5, SYSUTCDATETIME()), DATEADD(day, -5, SYSUTCDATETIME()), NULL, 0
),
(
4, 3, 2, 3, 1, 1, 2, 3, 1, 1, 'The book pages may not be easy enough to use', '<p>In our usability testing, there were some usability issues with the book management module, it may result in reduced adoption of the platform</p>', 0, DATEADD(day, -9, SYSUTCDATETIME()), DATEADD(day, -5, SYSUTCDATETIME()), DATEADD(day, -5, SYSUTCDATETIME()), NULL, 0
),
(
5, 3, 3, 4, 3, 1, 2, 2, 1, NULL, 'The software licenses may be too expensive', '<p>Our choice of technology stack may require us to use expensive software licenses which could result in us exceeding the infrastructure budget.</p>', 0, DATEADD(day, -8, SYSUTCDATETIME()), DATEADD(day, -4, SYSUTCDATETIME()), DATEADD(day, -4, SYSUTCDATETIME()), NULL, 0
),
(
6, 2, 3, 5, 4, 1, 2, 2, 1, NULL, 'The client team may not be ready for UAT', '<p>We are required by the contract to do a round of UAT with the customer. We may not have the client team in place in time</p>', 0, DATEADD(day, -8, SYSUTCDATETIME()), DATEADD(day, -4, SYSUTCDATETIME()), DATEADD(day, -4, SYSUTCDATETIME()), NULL, 0
)
GO

SET IDENTITY_INSERT TST_RISK OFF; 

