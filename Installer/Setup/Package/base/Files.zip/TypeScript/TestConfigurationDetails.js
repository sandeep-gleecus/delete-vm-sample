var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var testConfigurationDetails = {
    populateTestConfigurationsPanelId: '',
    grdTestConfigurationsId: '',
    displayPopulatePanel: function (testConfigurationSetId, btnPopulateId) {
        ReactDOM.render(React.createElement(PopulateTestConfigurationsBox, { domId: testConfigurationDetails.populateTestConfigurationsPanelId, projectId: SpiraContext.ProjectId, testConfigurationSetId: testConfigurationSetId, btnPopulateId: btnPopulateId, grdTestConfigurationsId: testConfigurationDetails.grdTestConfigurationsId }), document.getElementById(testConfigurationDetails.populateTestConfigurationsPanelId));
    }
};
var PopulateTestConfigurationsBox = (function (_super) {
    __extends(PopulateTestConfigurationsBox, _super);
    function PopulateTestConfigurationsBox(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            parameters: [],
            maxNumberOfRows: 5,
            ddlTestCaseParameter: null,
            ddlCustomList: null,
            messageBoxId: 'populateTestConfigurations_messageBox'
        };
        _this.addParameter = _this.addParameter.bind(_this);
        _this.populateClick = _this.populateClick.bind(_this);
        _this.closeClick = _this.closeClick.bind(_this);
        _this.populateClick = _this.populateClick.bind(_this);
        _this.populate_success = _this.populate_success.bind(_this);
        _this.removeParameter = _this.removeParameter.bind(_this);
        _this.retrieveParameters_success = _this.retrieveParameters_success.bind(_this);
        _this.retrieveCustomLists_success = _this.retrieveCustomLists_success.bind(_this);
        return _this;
    }
    PopulateTestConfigurationsBox.prototype.componentDidMount = function () {
        this.state.ddlTestCaseParameter = $create(Inflectra.SpiraTest.Web.ServerControls.DropDownList, {
            multiSelectable: false,
            enabledCssClass: 'u-dropdown is-active',
            disabledCssClass: 'u-dropdown disabled'
        }, null, null, document.getElementById('ddlTestCaseParameter'));
        this.state.ddlCustomList = $create(Inflectra.SpiraTest.Web.ServerControls.DropDownList, {
            multiSelectable: false,
            enabledCssClass: 'u-dropdown is-active',
            disabledCssClass: 'u-dropdown disabled'
        }, null, null, document.getElementById('ddlCustomList'));
        this.state.ddlTestCaseParameter.addItem('', resx.Global_PleaseSelect);
        this.state.ddlCustomList.addItem('', resx.Global_PleaseSelect);
        var self = this;
        Inflectra.SpiraTest.Web.Services.Ajax.TestConfigurationService.TestConfiguration_RetrieveParameters(this.props.projectId, self.retrieveParameters_success, self.retrieveParameters_failure);
        Inflectra.SpiraTest.Web.Services.Ajax.TestConfigurationService.TestConfiguration_RetrieveCustomLists(this.props.projectId, self.retrieveCustomLists_success, self.retrieveCustomLists_failure);
    };
    PopulateTestConfigurationsBox.prototype.componentWillUnmount = function () {
        this.state.ddlTestCaseParameter.dispose();
        this.state.ddlCustomList.dispose();
        delete this.state.ddlTestCaseParameter;
        delete this.state.ddlCustomList;
    };
    PopulateTestConfigurationsBox.prototype.closeClick = function (e) {
        e.stopPropagation();
        $("#" + this.props.btnPopulateId).removeClass('disabled');
        ReactDOM.unmountComponentAtNode(document.getElementById(this.props.domId));
    };
    PopulateTestConfigurationsBox.prototype.populateClick = function (e) {
        if (this.state.parameters.length > this.state.maxNumberOfRows) {
            alert(resx.TestConfigurationDetails_TooManyParameters);
            return;
        }
        if (confirm(resx.TestConfigurationDetails_ConfirmPopulation)) {
            var testParameters = {};
            for (var i = 0; i < this.state.parameters.length; i++) {
                var parameterId = this.state.parameters[i].parameterId;
                var customListId = this.state.parameters[i].customListId;
                testParameters[globalFunctions.keyPrefix + parameterId] = customListId;
            }
            globalFunctions.display_spinner();
            var self = this;
            Inflectra.SpiraTest.Web.Services.Ajax.TestConfigurationService.TestConfiguration_Populate(this.props.projectId, this.props.testConfigurationSetId, testParameters, self.populate_success, self.populate_failure);
        }
    };
    PopulateTestConfigurationsBox.prototype.populate_success = function (data) {
        globalFunctions.hide_spinner();
        $("#" + this.props.btnPopulateId).removeClass('disabled');
        ReactDOM.unmountComponentAtNode(document.getElementById(this.props.domId));
        $find(this.props.grdTestConfigurationsId).load_data();
    };
    PopulateTestConfigurationsBox.prototype.populate_failure = function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(this.state.messageBoxId), exception);
    };
    PopulateTestConfigurationsBox.prototype.closeMessageBox = function () {
        document.getElementById(this.state.messageBoxId).className = 'alert alert-hidden';
    };
    PopulateTestConfigurationsBox.prototype.addParameter = function () {
        var parameterId = this.state.ddlTestCaseParameter.get_selectedItem().get_value();
        var parameterName = this.state.ddlTestCaseParameter.get_selectedItem().get_text();
        var customListId = this.state.ddlCustomList.get_selectedItem().get_value();
        var customListName = this.state.ddlCustomList.get_selectedItem().get_text();
        if (!parameterId || parameterId == '' || !customListId || customListId == '') {
            alert(resx.TestConfigurationDetails_NoParameterOrCustomList);
            return;
        }
        if (this.state.parameters.length === this.state.maxNumberOfRows) {
            alert(resx.TestConfigurationDetails_TooManyParameters);
            return;
        }
        var matches = false;
        for (var i = 0; i < this.state.parameters.length; i++) {
            if (this.state.parameters[i].parameterId == parameterId) {
                matches = true;
            }
        }
        if (!matches) {
            var newEntry = {
                parameterId: parameterId,
                parameterName: parameterName,
                customListId: customListId,
                customListName: customListName
            };
            this.setState({
                parameters: this.state.parameters.concat([newEntry])
            });
            this.state.ddlTestCaseParameter.get_selectedItem();
        }
    };
    PopulateTestConfigurationsBox.prototype.removeParameter = function (index) {
        var newParameters = JSON.parse(JSON.stringify(this.state.parameters));
        newParameters.splice(this.state.parameters[index], 1);
        this.setState({
            parameters: newParameters
        });
    };
    PopulateTestConfigurationsBox.prototype.retrieveParameters_success = function (data) {
        this.state.ddlTestCaseParameter.set_dataSource(data);
        this.state.ddlTestCaseParameter.dataBind();
    };
    PopulateTestConfigurationsBox.prototype.retrieveParameters_failure = function (exception) {
        globalFunctions.display_error($get(this.state.messageBoxId), exception);
    };
    PopulateTestConfigurationsBox.prototype.retrieveCustomLists_success = function (data) {
        this.state.ddlCustomList.set_dataSource(data);
        this.state.ddlCustomList.dataBind();
    };
    PopulateTestConfigurationsBox.prototype.retrieveCustomLists_failure = function (exception) {
        globalFunctions.display_error($get(this.state.messageBoxId), exception);
    };
    PopulateTestConfigurationsBox.prototype.render = function () {
        var _this = this;
        var saveButtonClasses = (this.state.parameters.length > 0 && this.state.parameters.length <= this.state.maxNumberOfRows) ? "btn primary-button" : "btn primary-button disabled";
        return (React.createElement("div", null,
            React.createElement("div", { id: this.state.messageBoxId, className: "alert alert-hidden", role: "alert" },
                React.createElement("button", { className: "close", type: "button", "data-hide": "alert", "aria-label": "Close", onClick: this.closeMessageBox },
                    React.createElement("span", null, "\u00D7")),
                React.createElement("span", { id: this.state.messageBoxId + '_text' })),
            React.createElement("div", { className: "bg-off-white p-2 my-3 fs-14 d-flex flex-column" },
                React.createElement("p", { className: "mb3" }, resx.TestConfigurationDetails_PleaseChooseParametersToPopulate),
                React.createElement("div", { className: "" },
                    React.createElement("div", { className: "my-3" },
                        React.createElement("div", { className: "mt0 pa0 mb-3" },
                            React.createElement("label", { htmlFor: "ddlTestCaseParameter", className: "required me-3" },
                                resx.TestConfiguration_TestCaseParameter,
                                ":"),
                            React.createElement("div", { id: "ddlTestCaseParameter" })),
                        React.createElement("div", { className: "mt0 pa0 mb2" },
                            React.createElement("label", { htmlFor: "ddlCustomList", className: "required me-3" },
                                resx.TestConfiguration_CustomList,
                                ":"),
                            React.createElement("div", { id: "ddlCustomList" })),
                        React.createElement("div", { className: "mt0 pa0 mb2" },
                            React.createElement("button", { type: "button", className: "btn primary-button", id: "btnAddParameter", onClick: this.addParameter }, resx.Global_Add)))),
                React.createElement("div", { className: "u-box_3 d-flex flex-column my-3" }, this.state.parameters.map(function (parameter, index) {
                    return React.createElement("div", { className: "" },
                        React.createElement("div", { className: "mt0 pa0 mb2 d-flex align-items-center gap-6" },
                            React.createElement("label", { className: " " },
                                resx.TestConfiguration_TestCaseParameter,
                                ":"),
                            React.createElement("span", { className: "color-inherit" }, parameter.parameterName)),
                        React.createElement("div", { className: "mt0 pa0 mb2 d-flex align-items-center gap-6" },
                            React.createElement("label", { className: " " },
                                resx.TestConfiguration_CustomList,
                                ":"),
                            React.createElement("span", { className: "color-inherit" }, parameter.customListName)),
                        React.createElement("div", { className: "mt0 pa0 mb2" },
                            React.createElement("button", { type: "button", className: "btn primary-button", onClick: _this.removeParameter.bind(null, index) },
                                React.createElement("span", { className: "fas fa-times fa-fw" }),
                                resx.Global_Remove)));
                })),
                React.createElement("div", { className: "d-flex align-items-center gap-2 mt3" },
                    React.createElement("div", { className: saveButtonClasses, onClick: this.populateClick }, resx.Global_Populate),
                    React.createElement("div", { className: "btn secondary-button", onClick: this.closeClick }, resx.Global_Cancel)))));
    };
    return PopulateTestConfigurationsBox;
}(React.Component));
//# sourceMappingURL=TestConfigurationDetails.js.map