-- =====================================================================
-- Author:			Inflectra Corporation
-- =====================================================================
UPDATE [TST_REQUIREMENT_TYPE]
SET NAME = 'Epic' WHERE REQUIREMENT_TYPE_ID = -1
GO
