/***************************************************************
**	Insert script for table TST_DOCUMENT_WORKFLOW_CUSTOM_FIELD
***************************************************************/
INSERT INTO TST_DOCUMENT_WORKFLOW_CUSTOM_FIELD
(
DOCUMENT_WORKFLOW_ID, DOCUMENT_STATUS_ID, WORKFLOW_FIELD_STATE_ID, CUSTOM_PROPERTY_ID
)
VALUES
(
1, 13, 1, 34
),
(
1, 13, 1, 35
)
GO

