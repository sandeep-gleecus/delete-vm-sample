/***************************************************************
**	Insert script for table TST_TEST_CASE_PARAMETER_HIERARCHY_ALREADY_SET
***************************************************************/
INSERT INTO TST_TEST_CASE_PARAMETER_HIERARCHY_ALREADY_SET
(
TEST_CASE_PARAMETER_ID, PROJECT_ID, TEST_CASE_ID, NAME, DEFAULT_VALUE
)
VALUES
(
1, 1, 2, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 3, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 4, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 5, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 8, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 9, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 12, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 16, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 17, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 18, 'url', 'http://www.libraryinformationsystem.com'
),
(
1, 1, 19, 'url', 'http://www.libraryinformationsystem.com'
),
(
2, 1, 2, 'login', NULL
),
(
2, 1, 3, 'login', NULL
),
(
2, 1, 4, 'login', NULL
),
(
2, 1, 5, 'login', NULL
),
(
2, 1, 8, 'login', NULL
),
(
2, 1, 9, 'login', NULL
),
(
2, 1, 12, 'login', NULL
),
(
2, 1, 17, 'login', NULL
),
(
2, 1, 18, 'login', NULL
),
(
2, 1, 19, 'login', NULL
),
(
3, 1, 2, 'password', NULL
),
(
3, 1, 3, 'password', NULL
),
(
3, 1, 4, 'password', NULL
),
(
3, 1, 5, 'password', NULL
),
(
3, 1, 8, 'password', NULL
),
(
3, 1, 9, 'password', NULL
),
(
3, 1, 12, 'password', NULL
),
(
3, 1, 17, 'password', NULL
),
(
3, 1, 18, 'password', NULL
),
(
3, 1, 19, 'password', NULL
),
(
4, 1, 2, 'browserName', 'browser'
),
(
4, 1, 3, 'browserName', 'browser'
),
(
4, 1, 4, 'browserName', 'browser'
),
(
4, 1, 5, 'browserName', 'browser'
),
(
4, 1, 8, 'browserName', 'browser'
),
(
4, 1, 9, 'browserName', 'browser'
),
(
4, 1, 12, 'browserName', 'browser'
),
(
4, 1, 16, 'browserName', 'browser'
),
(
4, 1, 17, 'browserName', 'browser'
),
(
4, 1, 18, 'browserName', 'browser'
),
(
4, 1, 19, 'browserName', 'browser'
),
(
5, 1, 18, 'name', 'Roald Dahl'
),
(
5, 1, 20, 'name', 'Roald Dahl'
),
(
6, 1, 18, 'age', '105'
),
(
6, 1, 20, 'age', '105'
),
(
7, 1, 18, 'name', 'Charlie and the Chocolate Factory'
),
(
7, 1, 19, 'name', 'Charlie and the Chocolate Factory'
),
(
7, 1, 21, 'name', 'Charlie and the Chocolate Factory'
),
(
8, 1, 18, 'author', 'Roald Dahl'
),
(
8, 1, 19, 'author', 'Roald Dahl'
),
(
8, 1, 21, 'author', 'Roald Dahl'
),
(
9, 1, 18, 'genre', 'Fantasy'
),
(
9, 1, 19, 'genre', 'Fantasy'
),
(
9, 1, 21, 'genre', 'Fantasy'
),
(
10, 1, 2, 'operatingSystem', NULL
),
(
10, 1, 3, 'operatingSystem', NULL
),
(
10, 1, 4, 'operatingSystem', NULL
),
(
10, 1, 5, 'operatingSystem', NULL
),
(
10, 1, 8, 'operatingSystem', NULL
),
(
10, 1, 9, 'operatingSystem', NULL
),
(
10, 1, 12, 'operatingSystem', NULL
),
(
10, 1, 16, 'operatingSystem', NULL
),
(
10, 1, 17, 'operatingSystem', NULL
),
(
10, 1, 18, 'operatingSystem', NULL
),
(
10, 1, 19, 'operatingSystem', NULL
)
GO

