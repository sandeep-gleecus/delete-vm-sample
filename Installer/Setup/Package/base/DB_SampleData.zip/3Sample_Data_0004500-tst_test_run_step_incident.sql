/***************************************************************
**	Insert script for table TST_TEST_RUN_STEP_INCIDENT
***************************************************************/
INSERT INTO TST_TEST_RUN_STEP_INCIDENT
(
TEST_RUN_STEP_ID, INCIDENT_ID
)
VALUES
(
26, 1
),
(
13, 2
),
(
3, 7
)
GO

