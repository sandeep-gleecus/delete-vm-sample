var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ReactC3Chart = (function (_super) {
    __extends(ReactC3Chart, _super);
    function ReactC3Chart(props) {
        var _this = _super.call(this, props) || this;
        _this.chart;
        return _this;
    }
    ReactC3Chart.prototype.componentDidMount = function () {
        this._loadChart();
    };
    ReactC3Chart.prototype.componentDidUpdate = function (prevProps) {
        if (this.props.dataSource !== prevProps.dataSource) {
            this._updateChart(this.props.data.columns);
        }
        else {
            this._loadChart();
        }
    };
    ReactC3Chart.prototype._loadChart = function () {
        if (this.props.data.columns && this.props.data.type) {
            this.chart = c3.generate({
                bindto: ReactDOM.findDOMNode(this),
                axis: this.props.axis,
                bar: this.props.bar,
                color: this.props.color,
                data: this.props.data,
                donut: this.props.donut,
                gauge: this.props.gauge,
                legend: this.props.legend,
                tooltip: this.props.tooltip,
                size: this.props.size,
            });
        }
    };
    ReactC3Chart.prototype._updateChart = function (data) {
        if (data) {
            this.chart.load({
                columns: data
            });
        }
    };
    ReactC3Chart.prototype.render = function () {
        return React.createElement("div", { className: this.props.className });
    };
    return ReactC3Chart;
}(React.Component));
//# sourceMappingURL=rct_comp_reactC3Chart.js.map