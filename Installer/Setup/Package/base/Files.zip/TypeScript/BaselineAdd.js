var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var resx = Inflectra.SpiraTest.Web.GlobalResources;
var RctBaselineAdd = (function (_super) {
    __extends(RctBaselineAdd, _super);
    function RctBaselineAdd(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            name: "",
            description: ""
        };
        _this.handleClose = _this.handleClose.bind(_this);
        _this.handleNameChange = _this.handleNameChange.bind(_this);
        _this.handleDescriptionChange = _this.handleDescriptionChange.bind(_this);
        _this.addBaseline = _this.addBaseline.bind(_this);
        _this.addBaselineSuccess = _this.addBaselineSuccess.bind(_this);
        return _this;
    }
    RctBaselineAdd.prototype.componentDidMount = function () {
        document.getElementById(this.props.lnkAddBtnId).classList.add("disabled");
    };
    RctBaselineAdd.prototype.handleClose = function () {
        if (document.getElementById(this.props.domId)) {
            ReactDOM.unmountComponentAtNode(document.getElementById(this.props.domId));
        }
        document.getElementById(this.props.lnkAddBtnId).classList.remove("disabled");
    };
    RctBaselineAdd.prototype.handleNameChange = function (event) {
        this.setState({ name: event.target.value });
    };
    RctBaselineAdd.prototype.handleDescriptionChange = function (event) {
        this.setState({ description: event.target.value });
    };
    RctBaselineAdd.prototype.addBaseline = function (event) {
        if (this.state.name.length > 0) {
            Inflectra.SpiraTest.Web.Services.Ajax.BaselineService.Baseline_Create(SpiraContext.ProjectId, SpiraContext.ArtifactId, this.state.name, this.state.description, this.addBaselineSuccess, this.addBaselineFailure);
        }
    };
    RctBaselineAdd.prototype.addBaselineSuccess = function () {
        $find(this.props.gridId).load_data();
        this.handleClose();
    };
    RctBaselineAdd.prototype.addBaselineFailure = function () {
    };
    RctBaselineAdd.prototype.render = function () {
        return (React.createElement("div", { className: " clearfix" },
            React.createElement("div", { className: "u-box_3 w-100 mw720" },
                React.createElement("ul", { className: "u-box_list pl0" },
                    React.createElement("li", { className: "mb-3 d-flex align-items-center" },
                        React.createElement("label", { className: "fs-14 fw-medium required" },
                            resx.Global_Name,
                            ":"),
                        React.createElement("input", { type: "text", className: "u-input is-active", value: this.state.name, onChange: this.handleNameChange })),
                    React.createElement("li", { class: "mb-3 d-flex align-items-center" },
                        React.createElement("label", { className: "fs-14 fw-medium" },
                            resx.Global_Description,
                            ":"),
                        React.createElement("textarea", { type: "text", className: "u-input is-active", value: this.state.description, onChange: this.handleDescriptionChange })),
                    React.createElement("li", { className: "mb-3 ml_u-box-label" },
                        React.createElement("div", { className: "d-flex align-items-center gap-6", role: "group" },
                            React.createElement("button", { className: "btn primary-button", onClick: this.addBaseline, disabled: this.state.name.length === 0, type: "button" }, this.state.name.length === 0 ? resx.Global_NameRequired : resx.Global_Add),
                            React.createElement("button", { className: "btn secondary-button", onClick: this.handleClose, type: "button" }, resx.Global_Cancel)))))));
    };
    return RctBaselineAdd;
}(React.Component));
//# sourceMappingURL=BaselineAdd.js.map