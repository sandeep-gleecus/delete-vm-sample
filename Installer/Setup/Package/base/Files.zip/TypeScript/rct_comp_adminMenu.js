var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var AdminMenu = (function (_super) {
    __extends(AdminMenu, _super);
    function AdminMenu(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            collapsedSubSections: []
        };
        _this.toggleExpanded = _this.toggleExpanded.bind(_this);
        return _this;
    }
    AdminMenu.prototype.componentWillMount = function () {
        this.getCollapsedSubSections(this.props.wrapperId);
    };
    AdminMenu.prototype.compareByIndex = function (a, b) {
        return a.index < b.index ? -1 : a.index > b.index ? 1 : 0;
    };
    AdminMenu.prototype.compareByName = function (a, b) {
        return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
    };
    AdminMenu.prototype.getCollapsedSubSections = function (wrapperId) {
        var localTerms = JSON.parse(localStorage.getItem(wrapperId + "-collapse"));
        if (localTerms && localTerms.length > 0)
            this.setState({ collapsedSubSections: localTerms });
    };
    AdminMenu.prototype.toggleExpanded = function (id) {
        if (!id)
            return;
        var newList = this.state.collapsedSubSections;
        if (this.state.collapsedSubSections.length > 0 && globalFunctions.findItemInArray(this.state.collapsedSubSections, id)) {
            var position = this.state.collapsedSubSections.indexOf(id);
            newList.splice(position, 1);
        }
        else {
            newList.push(id);
        }
        this.setState({ collapsedSubSections: newList });
        localStorage.setItem(this.props.wrapperId + "-collapse", JSON.stringify(newList));
    };
    AdminMenu.prototype.createLinkUrl = function (link, section) {
        var linkSuffix = link && link.url ? (link.url.includes(".aspx") || link.urlIsFromRoot ? link.url : link.url + ".aspx") : "";
        var suffix;
        if (link.urlIsComplete) {
            return linkSuffix;
        }
        if (link.urlIsFromRoot) {
            suffix = linkSuffix;
        }
        else {
            switch (section) {
                case this.props.workspaceEnums.product:
                    var projectSuffixBase = this.props.currentProjectId + "/Administration/";
                    suffix = linkSuffix ? projectSuffixBase + linkSuffix : projectSuffixBase + "Default.aspx";
                    break;
                case this.props.workspaceEnums.program:
                    var programSuffixBase = "pg/" + this.props.currentProgramId + "/Administration/";
                    suffix = linkSuffix ? programSuffixBase + linkSuffix : programSuffixBase + "Default.aspx";
                    break;
                case this.props.workspaceEnums.template:
                    var templateSuffixBase = "pt/" + this.props.currentTemplateId + "/Administration/";
                    suffix = linkSuffix ? templateSuffixBase + linkSuffix : templateSuffixBase + "Default.aspx";
                    break;
                case this.props.workspaceEnums.enterprise:
                default:
                    suffix = linkSuffix ? "Administration/" + linkSuffix : "Administration.aspx";
                    break;
            }
        }
        return SpiraContext.BaseUrl + suffix;
    };
    AdminMenu.prototype.createMenuSection = function (section, wrapperId, sectionType) {
        var wrapperIdBase = wrapperId + "-" + section.id;
        return (React.createElement("h5", { role: "group", className: this.props.sectionClasses ? this.props.sectionClasses : "" },
            !this.props.hideTitle &&
                React.createElement("div", { className: this.props.sectionTitleClasses ? this.props.sectionTitleClasses : "", id: wrapperIdBase }, (typeof section.url != "undefined") ?
                    React.createElement("a", { className: this.props.sectionTitleLinkClasses ? this.props.sectionTitleLinkClasses : "", href: this.createLinkUrl(section.url, sectionType) }, section.name)
                    : React.createElement("span", null, section.name)),
            section.links && this.createLinkList(section.links, wrapperIdBase),
            section.subSections && this.createSubSections(section.subSections, wrapperIdBase, sectionType)));
    };
    AdminMenu.prototype.createSubSections = function (subSections, wrapperId, sectionType) {
        var _this = this;
        if (subSections) {
            var menuItems = this.props.menuItems;
            var allowedsubSections = subSections.filter(function (subSection) {
                if (!subSection.adminPermissions || globalFunctions.isAuthorizedAdminAccess(subSection.adminPermissions, globalFunctions.permissionEnum)) {
                    return subSection;
                }
            });
            var subSectionItems = allowedsubSections.sort(this.compareByIndex).map(function (subSection) {
                subSection.expanded = true;
                var wrapperIdBase = subSection.id && wrapperId ? wrapperId + "-" + subSection.id : "";
                if (globalFunctions.findItemInArray(_this.state.collapsedSubSections, wrapperIdBase)) {
                    subSection.expanded = false;
                }
                var subSectionWithUrls = subSection.links ? subSection.links.map(function (x) {
                    x.finalUrl = _this.createLinkUrl(x, sectionType);
                    return x;
                }) : null;
                var isCurrentArtifact = _this.props.currentLocation && subSection.navigationId && _this.props.currentLocation == subSection.navigationId, currentUrlMatchesToSubSectionurl = subSectionWithUrls.map(function (x) { return x.finalUrl.replace(/s.aspx$/, ""); }).filter(function (x) { return window.location.href.indexOf(x) >= 0; }), isCurrentAdminSubsection = currentUrlMatchesToSubSectionurl.length ? true : false, subSectionClasses = (_this.props.subSectionClasses ? _this.props.subSectionClasses : "") + (isCurrentArtifact || isCurrentAdminSubsection ? "  bg-nav-bg-highlight-subtle br3" : "");
                return (React.createElement("div", { className: subSectionClasses, role: "group", "data-collapsible": "true", id: wrapperIdBase, key: subSection.index },
                    React.createElement("div", { "aria-expanded": subSection.expanded, className: "u-box_header submenu-titlebox", onClick: _this.toggleExpanded.bind(null, wrapperIdBase) },
                        React.createElement("p", { className: "submenu-title m-0 d-flex align-items-center", id: wrapperIdBase + "-heading" }, subSection.name),
                        React.createElement("span", { className: "u-anim u-anim_open submenu-icon fr mr3 mt2" },
                            React.createElement("i", { className: subSection.expanded ? "fas fa-chevron-up pt-10" : "fas fa-chevron-down pt-10" }))),
                    subSection.links && _this.createLinkList(subSectionWithUrls, wrapperIdBase)));
            });
            return (React.createElement("div", { className: this.props.subSectionWrapperClasses ? this.props.subSectionWrapperClasses : "" }, subSectionItems));
        }
    };
    AdminMenu.prototype.componentDidMount = function () {
        var that = this;
        console.log("componentDidMount", this.props);
        if (this.props.system != null && this.props.system.subSections != null) {
            this.props.system.subSections.forEach(function (item) {
                item.links.forEach(function (link) {
                    if (new URL(window.location.href).pathname === new URL(link.finalUrl, window.location.origin).pathname && new URL(window.location.href).search === new URL(link.finalUrl, window.location.origin).search) {
                        that.setHighlightColor("");
                        sessionStorage.setItem("highlightmenu", link.id.toLowerCase());
                    }
                });
            });
        }
        if (this.props.workspaceSecondary != null && this.props.workspaceSecondary.subSections != null) {
            this.props.workspaceSecondary.subSections.forEach(function (item) {
                item.links.forEach(function (link) {
                    if (new URL(window.location.href).pathname === new URL(link.finalUrl, window.location.origin).pathname && new URL(window.location.href).search === new URL(link.finalUrl, window.location.origin).search) {
                        that.setHighlightColor("");
                        sessionStorage.setItem("highlightmenu", link.id.toLowerCase());
                    }
                });
            });
        }
        if (this.props.workspaceMain != null && this.props.workspaceMain.subSections != null) {
            this.props.workspaceMain.subSections.forEach(function (item) {
                item.links.forEach(function (link) {
                    if (new URL(window.location.href).pathname === new URL(link.finalUrl, window.location.origin).pathname && new URL(window.location.href).search === new URL(link.finalUrl, window.location.origin).search) {
                        that.setHighlightColor("");
                        sessionStorage.setItem("highlightmenu", link.id.toLowerCase());
                    }
                });
            });
        }
        this.setHighlightColor("active-side-nav");
        if (window.location.pathname == "/ValidationMaster/Administration.aspx" || window.location.pathname == "/ValidationMaster/" + this.props.currentProjectId + "/Administration/Default.aspx" || window.location.pathname == "/ValidationMaster/pt/" + this.props.currentTemplateId + "/Administration/Default.aspx") {
            this.setHighlightColor("");
        }
    };
    AdminMenu.prototype.componentWillUnmount = function () {
        this.setHighlightColor("");
        sessionStorage.setItem("highlightmenu", null);
        console.log("componentWillUnmount");
    };
    AdminMenu.prototype.setHighlightColor = function (value) {
        var storedUser = sessionStorage.getItem('highlightmenu');
        if (storedUser) {
            var highlight = document.getElementById("show-hightlight" + storedUser);
            if (highlight != null) {
                console.log(storedUser, value, highlight);
                highlight.className = value;
            }
        }
    };
    AdminMenu.prototype.createLinkList = function (links, wrapperId) {
        var _this = this;
        if (links) {
            var listItems = links.sort(this.compareByIndex).map(function (link) {
                return React.createElement("li", { id: "show-hightlight" + (link.id.toLowerCase()), class: new URL(window.location.href).pathname === new URL(link.finalUrl, window.location.origin).pathname && new URL(window.location.href).search === new URL(link.finalUrl, window.location.origin).search ? "active-side-nav" : "", key: link.index },
                    React.createElement("a", { className: _this.props.linkClasses ? _this.props.linkClasses : "", id: link.id && wrapperId ? wrapperId + "-" + link.id : "", href: link.finalUrl }, link.name));
            });
            return (React.createElement("ul", { className: "u-box_list" }, listItems));
        }
    };
    AdminMenu.prototype.render = function () {
        var workspaceMainMenu = this.props.workspaceMain && this.createMenuSection(this.props.workspaceMain, this.props.wrapperId, this.props.workspaceMainType);
        var workspaceSecondaryMenu = this.props.workspaceSecondary && this.createMenuSection(this.props.workspaceSecondary, this.props.wrapperId, this.props.workspaceSecondaryType);
        var systemMenu = this.props.system && this.createMenuSection(this.props.system, this.props.wrapperId, this.props.workspaceEnums.system);
        return (React.createElement("div", { role: "menu", "aria-label": "Administration Menu" },
            workspaceMainMenu,
            workspaceSecondaryMenu,
            systemMenu));
    };
    return AdminMenu;
}(React.Component));
//# sourceMappingURL=rct_comp_adminMenu.js.map