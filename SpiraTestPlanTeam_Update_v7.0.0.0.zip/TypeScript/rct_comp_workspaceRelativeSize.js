var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var WorkspaceRelativeSize = (function (_super) {
    __extends(WorkspaceRelativeSize, _super);
    function WorkspaceRelativeSize(props) {
        var _this = _super.call(this, props) || this;
        _this.LEGEND_HIDE_ABOVE_COUNT = 10;
        _this.state = {
            childrenRQCounts: null,
        };
        return _this;
    }
    WorkspaceRelativeSize.prototype.componentDidMount = function () {
        this.childrenRQCountsSet();
    };
    WorkspaceRelativeSize.prototype.childrenRQCountsSet = function () {
        var countArray = null;
        if (this.props.portfolios && this.props.portfolios.length) {
            countArray = this.props.portfolios.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
        }
        else if (this.props.programs && this.props.programs.length) {
            countArray = this.props.programs.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
        }
        else if (this.props.products && this.props.products.length) {
            countArray = this.props.products.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
        }
        else if (this.props.releases && this.props.releases.length) {
            countArray = this.props.releases.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
            if (this.props.showSprints && this.props.sprints && this.props.sprints.length) {
                var sprintsArray = this.props.sprints.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
                countArray.push.apply(countArray, sprintsArray);
            }
        }
        else if (this.props.sprints && this.props.sprints.length) {
            countArray = this.props.sprints.map(function (x) { return ["".concat(x.workspaceName, " (ID:").concat(x.workspaceId, ")"), x.requirementsAll]; });
        }
        if (countArray) {
            var filteredArray = countArray.filter(function (x) { return x[1] > 0; });
            this.setState({ childrenRQCounts: filteredArray });
        }
    };
    WorkspaceRelativeSize.prototype.render = function () {
        return (React.createElement(React.Fragment, null, this.state.childrenRQCounts && this.state.childrenRQCounts.length > 0 ?
            React.createElement("div", { className: "mw9 df mt4 mx-auto" },
                React.createElement(ReactC3Chart, { data: {
                        columns: this.state.childrenRQCounts,
                        type: "donut",
                    }, donut: {
                        label: {
                            format: function (value, ratio, id) { return value; }
                        }
                    }, legend: {
                        hide: this.state.childrenRQCounts.length > this.LEGEND_HIDE_ABOVE_COUNT
                    } }))
            :
                React.createElement("div", { className: "ma4 alert alert-info", role: "alert" }, resx.Global_NoDataToDisplay)));
    };
    return WorkspaceRelativeSize;
}(React.Component));
//# sourceMappingURL=rct_comp_workspaceRelativeSize.js.map