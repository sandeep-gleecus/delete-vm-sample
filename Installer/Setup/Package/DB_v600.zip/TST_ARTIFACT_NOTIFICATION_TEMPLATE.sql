﻿
INSERT INTO TST_NOTIFICATION_ARTIFACT_TEMPLATE
(
ARTIFACT_TYPE_ID, PROJECT_TEMPLATE_ID, TEMPLATE_TEXT
)
VALUES
(
14, [PROJECT_TEMPLATE_ID], '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A risk has been added / updated</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Risk:</span> ${ID#} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Status:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${RiskStatus}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Type:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${RiskType}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Exposure:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${RiskExposure}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Release:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Release}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;color:#0a0a0a;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Risk''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
)
