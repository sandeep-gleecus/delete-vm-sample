/***************************************************************
**	Insert script for table TST_TEST_RUN
***************************************************************/
SET IDENTITY_INSERT TST_TEST_RUN ON; 

INSERT INTO TST_TEST_RUN
(
TEST_RUN_ID, TEST_CASE_ID, TEST_RUN_TYPE_ID, TESTER_ID, EXECUTION_STATUS_ID, RELEASE_ID, TEST_SET_ID, TEST_SET_TEST_CASE_ID, TEST_RUNS_PENDING_ID, IS_ATTACHMENTS, NAME, DESCRIPTION, ESTIMATED_DURATION, ACTUAL_DURATION, START_DATE, END_DATE, AUTOMATION_HOST_ID, AUTOMATION_ENGINE_ID, BUILD_ID, TEST_RUN_FORMAT_ID, RUNNER_NAME, RUNNER_TEST_NAME, RUNNER_ASSERT_COUNT, RUNNER_MESSAGE, RUNNER_STACK_TRACE, CONCURRENCY_DATE
)
VALUES
(
9, 2, 1, 3, 1, 1, 1, 1, NULL, 1, 'Ability to create new book', 'Tests that the user can create a new book in the system', 10, 75, DATEADD(day, -25, SYSUTCDATETIME()), DATEADD(day, -25, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -211040, SYSUTCDATETIME())
),
(
3, 2, 1, 2, 2, 2, 2, 8, NULL, 0, 'Ability to create new book', 'Tests that the user can create a new book in the system', 10, 90, DATEADD(day, -62, SYSUTCDATETIME()), DATEADD(day, -62, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -211010, SYSUTCDATETIME())
),
(
10, 3, 1, 2, 2, 1, 1, 2, NULL, 0, 'Ability to edit existing book', 'Tests that the user can login, view the details of a book, and then if he/she desires, make the necessary changes', 5, 90, DATEADD(day, -25, SYSUTCDATETIME()), DATEADD(day, -25, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -200930, SYSUTCDATETIME())
),
(
11, 4, 1, 3, 1, 1, 1, 3, NULL, 0, 'Ability to create new author', 'Tests that the user can create a new author record in the system', 60, 90, DATEADD(day, -25, SYSUTCDATETIME()), DATEADD(day, -25, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -196610, SYSUTCDATETIME())
),
(
5, 5, 1, 3, 2, 3, NULL, NULL, NULL, 0, 'Ability to edit existing author', 'Tests that the user can login, view the details of an author and then if he/she desires, make the necessary changes', 5, 90, DATEADD(day, -40, SYSUTCDATETIME()), DATEADD(day, -40, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -202370, SYSUTCDATETIME())
),
(
4, 6, 1, 3, 2, 2, 2, 12, NULL, 0, 'Ability to reassign book to different author', NULL, 8, 90, DATEADD(day, -60, SYSUTCDATETIME()), DATEADD(day, -60, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -208130, SYSUTCDATETIME())
),
(
1, 8, 1, 4, 2, 2, 2, 13, NULL, 0, 'Book management', NULL, 4, 90, DATEADD(day, -90, SYSUTCDATETIME()), DATEADD(day, -90, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -208130, SYSUTCDATETIME())
),
(
8, 9, 1, 4, 2, 3, NULL, NULL, NULL, 0, 'Author management', NULL, 4, 90, DATEADD(day, -26, SYSUTCDATETIME()), DATEADD(day, -26, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -196610, SYSUTCDATETIME())
),
(
12, 3, 1, 2, 6, 1, NULL, NULL, NULL, 0, 'Ability to edit existing book', 'Tests that the user can login, view the details of a book, and then if he/she desires, make the necessary changes', 5, 50, DATEADD(day, -25, SYSUTCDATETIME()), DATEADD(day, -25, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -200870, SYSUTCDATETIME())
),
(
2, 5, 1, 2, 5, 2, NULL, NULL, NULL, 0, 'Ability to edit existing author', 'Tests that the user can login, view the details of an author and then if he/she desires, make the necessary changes', 5, 95, DATEADD(day, -85, SYSUTCDATETIME()), DATEADD(day, -85, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -202310, SYSUTCDATETIME())
),
(
13, 2, 2, 2, 1, 1, NULL, NULL, NULL, 0, 'Ability to create new book', 'Tests that the user can create a new book in the system', 10, 70, DATEADD(day, -24, SYSUTCDATETIME()), DATEADD(day, -24, SYSUTCDATETIME()), NULL, NULL, NULL, 2, 'NUnit', '_01_TestCreateBook', 1, 'Expected 1 but 2 was found', '<p style="font-weight:bold; font-size:12pt;">Object variable or With block variable not set. </p><p><strong>Description:</strong> An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code.</p> <blockquote>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br />Source Error: <br /><br />Line 215: Response.Write ("&lt;option selected value=""" & MonthCheck(MonthCount) & """&gt;" & MonthCount & "&lt;/option&gt;" & vbCrLf)<br />Line 216:Else<br />Line 217: Response.Write ("&lt;option value=""" & MonthCheck(MonthCount) & """&gt;" & MonthCount & "&lt;/option&gt;" & vbCrLf)<br />Line 218:End If<br />Line 219:<br /></blockquote>', DATEADD(minute, -212470, SYSUTCDATETIME())
),
(
16, 2, 2, 2, 2, 17, NULL, NULL, NULL, 0, 'Ability to create new book', NULL, 2, 70, DATEADD(day, -12, SYSUTCDATETIME()), DATEADD(day, -12, SYSUTCDATETIME()), NULL, NULL, 1, 1, 'JUnit', '_01_TestCreateBook', 0, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code.<br/>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br />Source Error:<br/>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br />Line 216:Else<br />Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br />Line 218:End If<br />Line 219:', DATEADD(minute, -212450, SYSUTCDATETIME())
),
(
15, 3, 2, 2, 2, 17, NULL, NULL, NULL, 0, 'Ability to edit existing book', NULL, 5, 70, DATEADD(day, -14, SYSUTCDATETIME()), DATEADD(day, -14, SYSUTCDATETIME()), NULL, NULL, 1, 1, 'JUnit', '_02_TestEditBook', 0, 'Expected 1 but 2 was found', 'Object variable or With block variable not set.<br/>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br/>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br/>Source Error: <br/>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br/>Line 216:Else<br/>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br/>Line 218:End If<br/>Line 219:', DATEADD(minute, -200950, SYSUTCDATETIME())
),
(
25, 2, 2, 3, 2, 18, NULL, NULL, NULL, 0, 'Ability to create new book', NULL, 2, 70, DATEADD(day, -2, SYSUTCDATETIME()), DATEADD(day, -2, SYSUTCDATETIME()), NULL, NULL, 1, 1, 'TestNG', '_01_TestCreateBook', 0, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br/>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br/>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br/>Source Error: <br/>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br/>Line 216:Else<br/>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br/>Line 218:End If<br/>Line 219:', DATEADD(minute, -211030, SYSUTCDATETIME())
),
(
27, 3, 2, 3, 5, 18, NULL, NULL, NULL, 0, 'Ability to edit existing book', NULL, 5, 70, DATEADD(day, 0, SYSUTCDATETIME()), DATEADD(day, 0, SYSUTCDATETIME()), NULL, NULL, 2, 1, 'TestNG', '_02_TestEditBook', 1, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br>Source Error: <br>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 216:Else<br>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 218:End If<br>Line 219:', DATEADD(minute, -200950, SYSUTCDATETIME())
),
(
26, 4, 2, 3, 6, 18, NULL, NULL, NULL, 0, 'Ability to create new author', NULL, 60, 70, DATEADD(day, -1, SYSUTCDATETIME()), DATEADD(day, -1, SYSUTCDATETIME()), NULL, NULL, 2, 1, 'TestNG', '_03_TestCreateAuthor', 1, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br>Source Error: <br>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 216:Else<br>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 218:End If<br>Line 219:', DATEADD(minute, -196630, SYSUTCDATETIME())
),
(
28, 2, 2, 2, 1, 19, NULL, NULL, NULL, 0, 'Ability to create new book', NULL, 2, 70, DATEADD(day, 0, SYSUTCDATETIME()), DATEADD(day, 0, SYSUTCDATETIME()), 4, 1, 2, 1, 'Selenium', '_01_TestCreateBook', 2, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br>Source Error: <br>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 216:Else<br>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 218:End If<br>Line 219:', DATEADD(minute, -213910, SYSUTCDATETIME())
),
(
29, 3, 2, 2, 1, 19, NULL, NULL, NULL, 0, 'Ability to edit existing book', NULL, 5, 70, DATEADD(day, 0, SYSUTCDATETIME()), DATEADD(day, 0, SYSUTCDATETIME()), 4, 2, 3, 1, 'Selenium', '_02_TestEditBook', 3, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br>Source Error: <br>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 216:Else<br>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 218:End If<br>Line 219:', DATEADD(minute, -200950, SYSUTCDATETIME())
),
(
30, 4, 2, 2, 6, 19, NULL, NULL, NULL, 0, 'Ability to create new author', NULL, 60, 70, DATEADD(day, 0, SYSUTCDATETIME()), DATEADD(day, 0, SYSUTCDATETIME()), 4, 3, 3, 1, 'Selenium', '_03_TestCreateAuthor', 2, 'Expected 1 but 2 was found', 'Object variable or With block variable not set. <br>Description: An unhandled exception occurred during the execution of the current web request. Please review the stack trace for more information about the error and where it originated in the code. <br>Exception Details: System.NullReferenceException: Object variable or With block variable not set.<br>Source Error: <br>Line 215: Response.Write ("<option selected value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 216:Else<br>Line 217: Response.Write ("<option value=""" & MonthCheck(MonthCount) & """>" & MonthCount & "</option>" & vbCrLf)<br>Line 218:End If<br>Line 219:', DATEADD(minute, -198070, SYSUTCDATETIME())
),
(
17, 4, 1, 2, 1, 7, NULL, NULL, NULL, 0, 'Ability to create new author', 'Tests that the user can create a new author record in the system', 30, 55, DATEADD(day, -12, SYSUTCDATETIME()), DATEADD(day, -12, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -12267, SYSUTCDATETIME())
),
(
18, 2, 1, 3, 2, 7, NULL, NULL, NULL, 0, 'Ability to create new book', 'Tests that the user can create a new book in the system', 2, 70, DATEADD(day, -11, SYSUTCDATETIME()), DATEADD(day, -11, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -12096, SYSUTCDATETIME())
),
(
19, 5, 1, 2, 6, 7, NULL, NULL, NULL, 0, 'Ability to edit existing author', 'Tests that the user can login, view the details of an author and then if he/she desires, make the necessary changes', 50, 65, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -10, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -10796, SYSUTCDATETIME())
),
(
20, 3, 1, 2, 2, 7, NULL, NULL, NULL, 0, 'Ability to edit existing book', 'Tests that the user can login, view the details of a book, and then if he/she desires, make the necessary changes', 65, 70, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -10, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -10724, SYSUTCDATETIME())
),
(
24, 9, 1, 3, 2, 7, NULL, NULL, NULL, 0, 'Author management', NULL, 40, 75, DATEADD(day, -9, SYSUTCDATETIME()), DATEADD(day, -9, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -10634, SYSUTCDATETIME())
),
(
21, 8, 1, 2, 1, 7, NULL, NULL, NULL, 0, 'Book management', NULL, 65, 60, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -10, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
),
(
7, 13, 1, 2, 2, 8, NULL, NULL, NULL, 1, 'Adding new book and author to library', NULL, NULL, 0, DATEADD(day, -38, SYSUTCDATETIME()), DATEADD(day, -38, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
),
(
6, 3, 1, 2, 2, 8, NULL, NULL, NULL, 2, 'Ability to edit existing book', 'Tests that the user can login, view the details of a book, and then if he/she desires, make the necessary changes', 5, 0, DATEADD(day, -40, SYSUTCDATETIME()), DATEADD(day, -40, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
),
(
14, 13, 1, 2, 2, 17, NULL, NULL, NULL, 3, 'Adding new book and author to library', NULL, NULL, 1, DATEADD(day, -15, SYSUTCDATETIME()), DATEADD(day, -15, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
),
(
22, 4, 1, 2, 2, 17, NULL, NULL, NULL, 4, 'Ability to create new author', 'Tests that the user can create a new author record in the system', 30, 30, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -10, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
),
(
23, 8, 1, 2, 2, 17, NULL, NULL, NULL, 5, 'Book management', NULL, 4, 0, DATEADD(day, -10, SYSUTCDATETIME()), DATEADD(day, -10, SYSUTCDATETIME()), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATEADD(minute, -9487, SYSUTCDATETIME())
)
GO

SET IDENTITY_INSERT TST_TEST_RUN OFF; 

