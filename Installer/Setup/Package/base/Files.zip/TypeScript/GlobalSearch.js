var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var globalSearch = {
    msgBoxId: '',
    searchKeywords: '',
    currentProjectId: 0,
    searchResultData: [],
    searchInit: function (keywords, searchService) {
        globalSearch.searchKeywords = keywords;
        var pageIndex = 0, pageSize = 250, msgBoxId = this.msgBoxId;
        globalFunctions.display_spinner();
        searchService.RetrieveResults(keywords, pageIndex, pageSize, globalSearch.searchSuccess, globalSearch.searchFailure);
    },
    searchSuccess: function (res) {
        globalFunctions.hide_spinner();
        globalSearch.searchResultData = res.Values;
        globalFunctions.dlgGlobalDynamicClear();
        globalSearch.showResults();
    },
    searchFailure: function (error) {
        globalFunctions.hide_spinner();
        var messageBox = document.getElementById(globalSearch.msgBoxId);
        globalFunctions.display_error(messageBox, error);
    },
    showResults: function () {
        ReactDOM.render(React.createElement(SearchBox, null), document.getElementById('dlgGlobalDynamic'));
    }
};
var SearchBox = (function (_super) {
    __extends(SearchBox, _super);
    function SearchBox(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            data: globalSearch.searchResultData,
            keyword: globalSearch.searchKeywords,
            sortedByRank: true,
            artifactFilter: 0,
            projectFilter: 0,
            projectFilterList: [
                {
                    name: resx.Global_AllProjects,
                    id: 0,
                    count: globalSearch.searchResultData.length,
                    countFiltered: globalSearch.searchResultData.length
                },
                {
                    name: resx.Global_CurrentProject,
                    id: globalSearch.currentProjectId,
                    count: globalSearch.searchResultData.map(function (item) { return item.ProjectId; }).filter(function (item) { return item === globalSearch.currentProjectId; }).length,
                    countFiltered: 0
                }
            ],
            isOpen: false
        };
        _this.sortListRank = _this.sortListRank.bind(_this);
        _this.sortListDate = _this.sortListDate.bind(_this);
        _this.filterArtifactListClick = _this.filterArtifactListClick.bind(_this);
        _this.filterProjectListClick = _this.filterProjectListClick.bind(_this);
        _this.closeClick = _this.closeClick.bind(_this);
        _this.SortDropdown = _this.SortDropdown.bind(_this);
        return _this;
    }
    SearchBox.prototype.componentWillMount = function () {
        this.setState({
            isOpen: true
        });
    };
    SearchBox.prototype.SortDropdown = function (e) {
        this.setState({ value: e.target.value });
    };
    SearchBox.prototype.sortListRank = function (e) {
        if (!this.state.sortedByRank) {
            this.setState({
                data: this.state.data.sort(function (a, b) {
                    return parseInt(b.Rank) - parseInt(a.Rank);
                }),
                sortedByRank: true
            });
        }
    };
    SearchBox.prototype.sortListDate = function (e) {
        if (this.state.sortedByRank) {
            this.setState({
                data: this.state.data.sort(function (a, b) {
                    return +new Date(b.LastUpdateDate) - +new Date(a.LastUpdateDate);
                }),
                sortedByRank: false
            });
        }
    };
    SearchBox.prototype.filterArtifactListClick = function (artifactFilter, isClickable, e) {
        if (isClickable && artifactFilter >= 0) {
            var val;
            if (artifactFilter != 0) {
                val = globalSearch.searchResultData.filter(function (res) { return res.ArtifactTypeId == artifactFilter; });
            }
            else {
                val = globalSearch.searchResultData;
            }
            this.setState({
                artifactFilter: artifactFilter,
                data: val
            });
        }
    };
    SearchBox.prototype.filterProjectListClick = function (projectFilter, isClickable, e) {
        var _this = this;
        if (isClickable && projectFilter >= 0) {
            var val;
            if (projectFilter == 0) {
                if (this.state.artifactFilter != 0) {
                    val = globalSearch.searchResultData.filter(function (res) { return res.ArtifactTypeId == _this.state.artifactFilter; });
                }
                else {
                    val = globalSearch.searchResultData;
                }
            }
            else {
                val = this.state.data.filter(function (res) { return res.ProjectId == globalSearch.currentProjectId; });
            }
            this.setState({
                projectFilter: projectFilter,
                data: val
            });
        }
    };
    SearchBox.prototype.closeClick = function (e) {
        this.setState({
            isOpen: e ? false : true
        });
        globalSearch.searchKeywords = "";
        globalSearch.searchResultData.splice(0, globalSearch.searchResultData.length);
        globalFunctions.dlgGlobalDynamicClear();
    };
    SearchBox.prototype.render = function () {
        var resLength = this.state.data.length;
        var panelClasses = this.state.isOpen ? "mt-4 u-popup u-popup_down w-75 is-open" : "mt-4 u-popup u-popup_down w-75";
        var typesAll = { count: resLength, id: 0, name: resx.Global_AllArtifacts };
        var artifactFilter = this.state.artifactFilter, projectFilter = this.state.projectFilter;
        var returnedTypes = globalFunctions.listUniquesInArray(globalSearch.searchResultData, 'ArtifactTypeId'), returnedTypesCount = returnedTypes.length, returnedTypesLong = this.state.data.map(function (item) { return item.ArtifactTypeId; }), returnedTypesFilteredByProject = globalSearch.searchResultData
            .filter(function (item) {
            return projectFilter === 0 || projectFilter === item.ProjectId;
        })
            .map(function (item) { return item.ArtifactTypeId; }), returnedTypesInfo = globalFunctions.filterArrayByList(globalFunctions.getArtifactTypes(), returnedTypes, 'id')
            .map(function (item) {
            var count = 0, countFiltered = 0;
            for (var i = 0; i < resLength; i++) {
                if (item.id === returnedTypesLong[i]) {
                    count++;
                }
                ;
                if (i < returnedTypesFilteredByProject.length) {
                    if (item.id === returnedTypesFilteredByProject[i]) {
                        countFiltered++;
                    }
                    ;
                }
            }
            item.count = count;
            item.countFiltered = countFiltered;
            return item;
        });
        returnedTypesInfo.unshift(typesAll);
        var returnedTypesFilteredByArtifact = this.state.data
            .filter(function (item) {
            return artifactFilter === 0 || artifactFilter === item.ArtifactTypeId;
        })
            .map(function (item) { return item.ProjectId; }), projectFilterList = this.state.projectFilterList.map(function (item) {
            if (item.id > 0) {
                var countFiltered = 0;
                for (var i = 0; i < returnedTypesFilteredByArtifact.length; i++) {
                    if (returnedTypesFilteredByArtifact[i] === item.id) {
                        countFiltered++;
                    }
                }
                item.countFiltered = countFiltered;
            }
            return item;
        });
        var artifactFilterDetails = returnedTypesInfo.filter(function (item) {
            return item.id === artifactFilter;
        })[0];
        var projectFilterDetails = projectFilterList.filter(function (item) {
            return item.id === projectFilter;
        })[0];
        return (React.createElement("div", { className: panelClasses },
            React.createElement("span", { onClick: this.closeClick, className: "ti ti-x bg-border text-dark rounded-circle  pointer fr p-1 mtn4 mrn4 fade70 position-absolute search-close-style r-10px" }),
            React.createElement("div", { class: "  rounded-2 bg-border ", id: "global-search-all-lg" },
                React.createElement("div", { class: "border-0 border-bottom vm-midgreylight-bg 1" },
                    React.createElement(Header, { keyword: this.state.keyword, total: resLength, sortedByRank: this.state.sortedByRank, sortListRank: this.sortListRank, sortListDate: this.sortListDate, artifactsList: returnedTypesInfo, filterArtifactListClick: this.filterArtifactListClick, projectFilter: this.state.projectFilter, artifactFilter: this.state.artifactFilter, filterProjectListClick: this.filterProjectListClick, projectFilterDetails: projectFilterDetails, projectFilterList: this.state.projectFilterList })),
                this.state.data.length > 0 ?
                    React.createElement("div", { class: "pad-y-10 px-3 border-0 bg-white global-search" },
                        React.createElement("div", { class: "fs-12 fw-medium mb-2" }, "Total Results"),
                        React.createElement(ResultList, { data: this.state.data, artifactFilter: this.state.artifactFilter, projectFilter: this.state.projectFilter })) :
                    React.createElement("div", { class: "pad-y-10 px-3 border-0 bg-white global-search h-15rem" },
                        React.createElement("div", null,
                            React.createElement("div", null,
                                React.createElement("div", { class: "fs-14 fw-midgrey" }, "No results")),
                            React.createElement("div", { class: "d-flex flex-column justify-content-center my-5 text-center" },
                                React.createElement("div", { class: "fs-16  fw-bold mb-2" },
                                    "No results for \"",
                                    this.state.keyword,
                                    "\""),
                                React.createElement("div", { class: "fs-14 fw-normal vm-darkgrey" }, "You may want to try using different keywords")))))));
    };
    return SearchBox;
}(React.Component));
function Header(props) {
    var rankClass = props.sortedByRank ? 'btn btn-default active' : 'btn btn-default ', dateClass = props.sortedByRank ? 'btn btn-default ' : 'btn btn-default  active';
    function handleChange(event) {
        var value = event.target.value;
        var filterArtifactListClick = props.filterArtifactListClick.bind(null, value, true);
        filterArtifactListClick();
    }
    function handleSortChange(event) {
        var value = event.target.value;
        if (value == "1") {
            var Rank = props.sortListRank.bind();
            Rank();
        }
        else if (value == "2") {
            var Date = props.sortListDate.bind();
            Date();
        }
    }
    function handleProjectChange(event) {
        var value = event.target.checked ? 1 : 0;
        var filterProjectListClick = props.filterProjectListClick.bind(null, value, true);
        filterProjectListClick();
    }
    return (React.createElement("div", null,
        React.createElement("div", { class: "pad-y-12 ps-3 pe-5 border-0 border-bottom d-flex align-items-center justify-content-between vm-midgreylight-bg 2" },
            React.createElement("div", { class: "d-flex align-items-center " },
                React.createElement("div", { class: "form-check form-switch m-0" },
                    React.createElement("input", { class: "form-check-input", type: "checkbox", role: "switch", id: "flexSwitchCheckChecked", onChange: handleProjectChange })),
                React.createElement("div", { class: "fs-12 fw-medium vm-midgrey-8" }, "Current Project")),
            React.createElement("div", { class: "d-flex align-items-center gap-2" },
                React.createElement("select", { name: "country", class: "form-select fs-10 form-control p-6", "aria-label": "Default select example", onChange: handleChange }, props.artifactsList.map(function (item, key) {
                    return React.createElement(FilterListItem, { countFiltered: item.countFiltered, countFull: item.count, filter: props.artifactFilter, id: item.id, key: item.id, name: item.name });
                })),
                React.createElement("div", { class: "fs-12 fw-medium vm-midgrey-8" }, "Sort"),
                React.createElement("select", { class: "form-select fs-10 form-control p-6", "aria-label": "Default select example", onChange: handleSortChange },
                    React.createElement("option", { value: "1" },
                        React.createElement("span", null, resx.Global_Search_SortByRelevance)),
                    React.createElement("option", { value: "2" },
                        React.createElement("span", { className: dateClass, onClick: props.sortListDate }, resx.Global_Search_SortByDate)))))));
}
function FilterBox(props) {
    var filterArtifactListClick = props.filterArtifactListClick, filterProjectListClick = props.filterProjectListClick, artifactFilter = props.artifactFilter, artifactFilterClass = props.artifactFilter != 0 ? "font-bold" : "", projectFilter = props.projectFilter, projectFilterClass = props.projectFilter != 0 ? "font-bold" : "";
    var filterArtifactNodes = props.artifactsList.map(function (item) {
        return (React.createElement(FilterItem, { clickFunction: filterArtifactListClick, countFiltered: item.countFiltered, countFull: item.count, filter: artifactFilter, id: item.id, key: item.id, name: item.name }));
    });
    var filterProjectNodes = props.projectFilterList.map(function (item) {
        return (React.createElement("li", null,
            React.createElement(FilterItem, { clickFunction: filterProjectListClick, countFiltered: item.countFiltered, countFull: item.count, filter: projectFilter, id: item.id, key: item.id, name: item.name })));
    });
    return (React.createElement("div", null,
        resx.Global_Filter,
        ":",
        React.createElement("div", { className: "btn-group" },
            React.createElement("div", { className: "dropdown-down" },
                React.createElement("button", { type: "button", className: "btn btn-flat dropdown-toggle", "data-bs-toggle": "dropdown", id: "dropdownMenuButton", "aria-haspopup": "true", "aria-expanded": "false" },
                    props.artifactFilterDetails.name,
                    " ",
                    React.createElement("span", { className: "caret" })),
                React.createElement("ul", { className: "dropdown-menu", "aria-labelledby": "dropdownMenuButton" }, filterArtifactNodes))),
        React.createElement("div", { className: "btn-group" },
            React.createElement("button", { type: "button", className: "btn btn-flat dropdown-toggle", "data-bs-toggle": "dropdown", id: "dropdownMenuButton1", "aria-haspopup": "true", "aria-expanded": "false" },
                props.projectFilterDetails.name,
                " ",
                React.createElement("span", { className: "caret" })),
            React.createElement("ul", { className: "dropdown-menu", "aria-labelledby": "dropdownMenuButton1" }, filterProjectNodes))));
}
function FilterList(props) {
    var filterArtifactListClick = props.filterArtifactListClick, filterProjectListClick = props.filterProjectListClick, artifactFilter = props.artifactFilter, artifactFilterClass = props.artifactFilter != 0 ? "font-bold" : "", projectFilter = props.projectFilter, projectFilterClass = props.projectFilter != 0 ? "font-bold" : "";
    return (React.createElement(React.Fragment, null, props.artifactsList.map(function (item) {
        React.createElement(FilterItem, { clickFunction: filterArtifactListClick, countFiltered: item.countFiltered, countFull: item.count, filter: artifactFilter, id: item.id, key: item.id, name: item.name });
    })));
}
function FilterItem(props) {
    var isActive = props.filter === props.id, isNone = props.countFiltered === 0, isActiveClass = isActive ? " active" : "", isDisabled = isNone ? "disabled" : "", isClickable = !isActive && !isNone, showBadge = props.countFull ? true : false;
    var classes = (props.classes ? props.classes : "") + isActiveClass;
    return (React.createElement("a", { href: "#", className: classes, disabled: isDisabled, onClick: props.clickFunction.bind(null, props.id, isClickable) },
        props.name,
        showBadge ?
            React.createElement("span", { className: "ml2 badge font-70" }, props.countFull)
            :
                null));
}
function FilterListItem(props) {
    var isActive = props.filter === props.id, isNone = props.countFiltered === 0, isActiveClass = isActive ? " active" : "", isDisabled = isNone ? "disabled" : "", isClickable = !isActive && !isNone, showBadge = props.countFull ? true : false;
    var classes = (props.classes ? props.classes : "") + isActiveClass;
    return (React.createElement("option", { value: props.id },
        props.name,
        React.createElement("span", { className: "ml2 badge font-70" }, props.countFull)));
}
function ResultList(props) {
    var artifactFilter = props.artifactFilter, projectFilter = props.projectFilter;
    console.log(props.data);
    var listNodes = props.data.map(function (item) {
        return (React.createElement(ResultItem, { artifactFilter: artifactFilter, artifactTypeId: item.ArtifactTypeId, date: item.LastUpdateDate, description: item.Description, icon: item.Icon, key: item.Token, project: item.ProjectName, projectFilter: projectFilter, projectId: item.ProjectId, rank: item.Rank, title: item.Title, token: item.Token, type: item.IconAlt, url: item.Url }));
    });
    return (React.createElement("div", { className: "" }, listNodes));
}
function ResultItem(props) {
    var showArtifact = props.artifactFilter === 0 || props.artifactFilter === props.artifactTypeId, showProject = props.projectFilter === 0 || props.projectFilter === props.projectId, classes = showArtifact && showProject ? "result-item" : "result-item hide";
    return (React.createElement("div", { class: "border-0 bg-white mb-3" },
        React.createElement("div", { class: "d-flex align-items-center justify-content-between mb-1" },
            React.createElement("div", { class: "d-flex align-items-center gap-2" },
                React.createElement("img", { src: "/ValidationMaster/App_Themes/ValidationMasterTheme/Images/" + props.icon, alt: "" }),
                React.createElement("div", { class: "fs-12 fw-medium vm-primary" },
                    React.createElement("a", { href: props.url, className: "link-no-decoration" },
                        React.createElement("strong", null, props.token),
                        " - ",
                        props.title))),
            React.createElement("div", { class: "rounded-pill vm-lightgrey4-bg px-2 py-1 fs-10 fw-normal" }, props.project)),
        React.createElement("div", { class: "fs-12 vm-midgrey-8 fw-medium mb-1" }, props.description),
        React.createElement("div", { class: "fs-10 vm-midgrey fw-medium d-flex align-items-center gap-1" },
            React.createElement("img", { src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/2ndImg.svg", alt: "", class: "h-w-12" }),
            React.createElement("span", { class: "mt-15px" }, props.date))));
}
//# sourceMappingURL=GlobalSearch.js.map