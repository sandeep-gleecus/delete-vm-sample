/***************************************************************
**	Insert script for table TST_PROJECT_ARTIFACT_SHARING
***************************************************************/
INSERT INTO TST_PROJECT_ARTIFACT_SHARING
(
SOURCE_PROJECT_ID, DEST_PROJECT_ID, ARTIFACT_TYPE_ID
)
VALUES
(
1, 2, 1
),
(
1, 2, 2
),
(
1, 3, 1
),
(
1, 3, 2
),
(
1, 3, 3
),
(
1, 2, 13
),
(
1, 2, 6
)
GO

