/***************************************************************
**	Insert script for table TST_NOTIFICATION_ARTIFACT_USER_TYPE
***************************************************************/
INSERT INTO TST_NOTIFICATION_ARTIFACT_USER_TYPE
(
NAME, ACTIVE_YN
)
VALUES
(
'Creator', 'Y'
),
(
'Owner', 'Y'
)
GO

