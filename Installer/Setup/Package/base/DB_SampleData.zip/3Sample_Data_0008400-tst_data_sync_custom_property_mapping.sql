/***************************************************************
**	Insert script for table TST_DATA_SYNC_CUSTOM_PROPERTY_MAPPING
***************************************************************/
INSERT INTO TST_DATA_SYNC_CUSTOM_PROPERTY_MAPPING
(
DATA_SYNC_SYSTEM_ID, PROJECT_ID, CUSTOM_PROPERTY_ID, EXTERNAL_KEY
)
VALUES
(
1, 1, 6, '10010'
),
(
1, 1, 7, '10000'
),
(
2, 1, 7, 'operatingsystem'
)
GO

