/***************************************************************
**	Insert script for table TST_DATA_SYNC_STATUS
***************************************************************/
INSERT INTO TST_DATA_SYNC_STATUS
(
NAME, ACTIVE_YN
)
VALUES
(
'Success', 'Y'
),
(
'Failure', 'Y'
),
(
'Warning', 'Y'
),
(
'Not Run', 'Y'
)
GO

