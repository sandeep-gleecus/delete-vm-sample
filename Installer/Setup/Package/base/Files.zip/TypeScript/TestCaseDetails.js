Type.registerNamespace('Inflectra.SpiraTest.Web');
Inflectra.SpiraTest.Web.TestCaseDetails = function () {
    this._currentTestStepId = null;
    this._radAttached = $get(radAttached_id);
    this._radLinked = $get(radLinked_id);
    this._radRepository = $get(radRepository_id);
    this._lblAttached = $get(lblAttached_id);
    this._lblLinked = $get(lblLinked_id);
    this._lblRepository = $get(lblRepository_id);
    this._txtAutomationScript = $get(txtAutomationScript_id);
    this._lnkAutomationDocument = $get(lnkAutomationDocument_id);
    this._lblParameterMessage = $get(lblParameterMessage_id);
    this._lblTestStepMessages = $get(lblTestStepMessages_id);
    this._msgInsertTestLinkMessages = $get(msgInsertTestLinkMessages_id);
    this._msgImportTestCaseMessages = $get(msgImportTestCaseMessages_id);
    this._ajxFormManager = null;
    this._lstComments = null;
    this._self = this;
    this._testCaseParametersViewModel = null;
    this._testStepParametersViewModel = null;
    this._insertLinkParametersViewModel = null;
    this._insertNewLinkParametersViewModel = null;
    this._testFolders = null;
    this._testFolders2 = null;
    this._testFolders3 = null;
    Inflectra.SpiraTest.Web.TestCaseDetails.initializeBase(this);
};
Inflectra.SpiraTest.Web.TestCaseDetails.prototype =
    {
        initialize: function () {
            Inflectra.SpiraTest.Web.TestCaseDetails.callBaseMethod(this, 'initialize');
        },
        dispose: function () {
            delete this._txtAutomationScript;
            delete this._lnkAutomationDocument;
            delete this._ajxFormManager;
            delete this._lstComments;
            delete this._lblAttached;
            delete this._lblLinked;
            delete this._lblRepository;
            delete this._radAttached;
            delete this._radLinked;
            delete this._radRepository;
            delete this._lblParameterMessage;
            delete this._lblTestStepMessages;
            delete this._msgInsertTestLinkMessages;
            Inflectra.SpiraTest.Web.TestCaseDetails.callBaseMethod(this, 'dispose');
        },
        get_ajxFormManager: function () {
            if (!this._ajxFormManager) {
                this._ajxFormManager = $find(ajxFormManager_id);
            }
            return this._ajxFormManager;
        },
        get_lstComments: function () {
            if (!this._lstComments) {
                this._lstComments = $find(lstComments_id);
            }
            return this._lstComments;
        },
        updateAutomationScriptRadios: function () {
            if (this._radAttached.checked) {
                this._lblAttached.setAttribute('data-checked', 'checked');
                this._lblLinked.setAttribute('data-checked', '');
                this._lblRepository.setAttribute('data-checked', '');
            }
            else if (this._radLinked.checked) {
                this._lblAttached.setAttribute('data-checked', '');
                this._lblLinked.setAttribute('data-checked', 'checked');
                this._lblRepository.setAttribute('data-checked', '');
            }
            else if (this._radRepository.checked) {
                this._lblAttached.setAttribute('data-checked', '');
                this._lblLinked.setAttribute('data-checked', '');
                this._lblRepository.setAttribute('data-checked', 'checked');
            }
        },
        automationScript_changed: function (evt) {
            this.updateAutomationScriptRadios();
            var dataItem = this.get_ajxFormManager().get_dataItem();
            var automationTypeField = dataItem.Fields.AutomationType;
            if (this._radAttached.checked) {
                automationScriptSection.style.display = '';
                this._txtAutomationScript.style.display = 'inline';
                this._txtAutomationScript.readOnly = false;
                this._lnkAutomationDocument.style.display = '';
                automationTypeField.textValue = 'attached';
            }
            else if (this._radLinked.checked) {
                automationScriptSection.style.display = 'none';
                this._txtAutomationScript.style.display = 'none';
                this._txtAutomationScript.readOnly = true;
                this._lnkAutomationDocument.style.display = '';
                automationTypeField.textValue = 'linked';
            }
            else if (this._radRepository.checked) {
                automationScriptSection.style.display = '';
                this._txtAutomationScript.style.display = 'inline';
                this._txtAutomationScript.readOnly = true;
                this._lnkAutomationDocument.style.display = 'none';
                automationTypeField.textValue = 'repository';
            }
        },
        loadAutomationInfo: function (dontClearMessages) {
            var dataItem = this.get_ajxFormManager().get_dataItem();
            if (this._radAttached && this._radLinked && this._radRepository && dataItem) {
                var automationTypeField = dataItem.Fields.AutomationType;
                if (automationTypeField) {
                    var automationType = automationTypeField.textValue;
                    this._radAttached.checked = false;
                    this._radLinked.checked = false;
                    this._radRepository.checked = false;
                    if (automationType == 'attached') {
                        this._radAttached.checked = true;
                        this._lnkAutomationDocument.style.display = '';
                    }
                    else if (automationType == 'linked') {
                        this._radLinked.checked = true;
                        this._lnkAutomationDocument.style.display = '';
                    }
                    else if (automationType == 'repository') {
                        this._radRepository.checked = true;
                        this._lnkAutomationDocument.style.display = 'none';
                    }
                    this.updateAutomationScriptRadios();
                    ddlAutomationEngine_selected();
                    if (automationType == 'attached') {
                        this._lblRepository.setAttribute('disabled', 'disabled');
                        this._radRepository.disabled = true;
                    }
                    else if (automationType == 'linked') {
                        this._lblRepository.setAttribute('disabled', 'disabled');
                        this._radRepository.disabled = true;
                    }
                    else if (automationType == 'repository') {
                        this._lblLinked.setAttribute('disabled', 'disabled');
                        this._lblAttached.setAttribute('disabled', 'disabled');
                        this._radLinked.disabled = true;
                        this._radAttached.disabled = true;
                    }
                }
            }
        },
        ajxWorkflowOperations_operationExecuted: function (transitionId, isStatusOpen) {
        },
        ajxFormManager_operationReverted: function (statusId, isStatusOpen) {
        },
        displayEditParameters: function (evt) {
            globalFunctions.clear_errors(this._lblParameterMessage);
            $get(txtNewParameter_id).value = '';
            $get(txtNewParameterDefaultValue_id).value = '';
            this.load_testCaseParameters();
            var pnlEditParameters = $find(pnlEditParameters_id);
            pnlEditParameters.display(evt);
        },
        load_testCaseParameters: function () {
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.RetrieveParameters(SpiraContext.ArtifactId, false, false, AspNetAjax$Function.createDelegate(this, this.load_testCaseParameters_success), AspNetAjax$Function.createDelegate(this, this.load_testCaseParameters_failure));
        },
        load_testCaseParameters_success: function (data) {
            globalFunctions.hide_spinner();
            if (data) {
                for (var item in data) {
                    data[item].editable = false;
                    if (!data[item].Fields.DefaultValue.textValue) {
                        data[item].Fields.DefaultValue.textValue = '';
                    }
                }
            }
            if (this._testCaseParametersViewModel) {
                ko.mapping.fromJS(data, this._testCaseParametersViewModel);
            }
            else {
                this._testCaseParametersViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(this._testCaseParametersViewModel, $get('tblTestCaseParameters'));
            }
        },
        load_testCaseParameters_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._lblParameterMessage, exception);
        },
        testCaseParameters_storeFocusElement: function () {
            this._focusedElement = document.activeElement;
        },
        testCaseParameters_insertAtCursor: function (token, evt) {
            if (this._focusedElement) {
                if (this._focusedElement.title && this._focusedElement.tagName == 'IFRAME') {
                    var controlId = this._focusedElement.title.replace('Rich Text Editor, ', '');
                    if (controlId.indexOf(',') > 0) {
                        controlId = controlId.split(',')[0];
                    }
                    var editor = CKEDITOR.instances[controlId];
                    if (editor && editor.insertHtml) {
                        editor.insertHtml(token);
                    }
                }
                else {
                    this._focusedElement.focus();
                    $(this._focusedElement).insertAtCaret(token);
                }
            }
        },
        testCaseParameters_delete: function (testCaseParameter) {
            if (this._testCaseParametersViewModel) {
                for (var i = 0; i < this._testCaseParametersViewModel().length; i++) {
                    if (this._testCaseParametersViewModel()[i] == testCaseParameter) {
                        this._testCaseParametersViewModel.remove(this._testCaseParametersViewModel()[i]);
                    }
                }
            }
        },
        testCaseParameters_add: function () {
            globalFunctions.clear_errors(this._lblParameterMessage);
            var parameterName = $get(txtNewParameter_id).value.trim();
            var defaultValue = $get(txtNewParameterDefaultValue_id).value.trim();
            if (parameterName == '') {
                globalFunctions.display_error(this._lblParameterMessage, resx.TestCaseDetails_ParameterNameRequired);
            }
            else if (parameterName.indexOf('\'') >= 0 || parameterName.indexOf('\\') >= 0 || parameterName.indexOf(' ') >= 0) {
                globalFunctions.display_error(this._lblParameterMessage, resx.TestCaseDetails_ParameterNameInvalid);
            }
            else if (parameterName.indexOf('$') >= 0 || parameterName.indexOf('{') >= 0 || parameterName.indexOf('}') >= 0) {
                globalFunctions.display_error(this._lblParameterMessage, resx.TestCaseDetails_ParameterNameInvalid2);
            }
            else {
                var testCaseParameter = {
                    __type: globalFunctions.dataType_DataItem,
                    Fields: {
                        Name: {
                            __type: globalFunctions.dataType_DataItemField,
                            fieldName: "Name",
                            textValue: parameterName
                        },
                        DefaultValue: {
                            __type: globalFunctions.dataType_DataItemField,
                            fieldName: "DefaultValue",
                            textValue: defaultValue
                        },
                        Token: {
                            __type: globalFunctions.dataType_DataItemField,
                            fieldName: "Token",
                            textValue: '${' + parameterName + '}'
                        }
                    }
                };
                var match = false;
                for (var i = 0; i < this._testCaseParametersViewModel().length; i++) {
                    if (this._testCaseParametersViewModel()[i].Fields.Name.textValue() == parameterName) {
                        match = true;
                        break;
                    }
                }
                if (!match) {
                    var observable = ko.mapping.fromJS(testCaseParameter);
                    observable.editable = ko.observable(false);
                    this._testCaseParametersViewModel.push(observable);
                }
            }
        },
        testCaseParameters_edit: function (testCaseParameter) {
            var editable = testCaseParameter.editable();
            testCaseParameter.editable(!editable);
            testCaseParameter.Fields.Token.textValue('${' + testCaseParameter.Fields.Name.textValue() + '}');
        },
        testCaseParameters_save: function () {
            var newParam = $get(txtNewParameter_id).value.trim();
            if (newParam.length > 0) {
                this.testCaseParameters_add();
            }
            var mapping = {
                'ignore': ['editable']
            };
            var parameters = ko.mapping.toJS(this._testCaseParametersViewModel, mapping);
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.SaveParameters(SpiraContext.ProjectId, SpiraContext.ArtifactId, parameters, AspNetAjax$Function.createDelegate(this, this.testCaseParameters_save_success), AspNetAjax$Function.createDelegate(this, this.testCaseParameters_save_failure));
        },
        testCaseParameters_save_success: function () {
            globalFunctions.hide_spinner();
            var pnlEditParameters = $find(pnlEditParameters_id);
            pnlEditParameters.close();
        },
        testCaseParameters_save_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._lblParameterMessage, exception);
        },
        txtAutomationScript_changed: function (evt) {
            var hdnTestScriptChanged = $get(hdnTestScriptChanged_id);
            hdnTestScriptChanged.value = 'true';
        },
        grdTestSteps_rowEditAlternate: function (dataItem, evt) {
            if (evt) {
                globalFunctions.clear_errors(this._lblTestStepMessages);
                $get('divHasParameters').style.display = 'none';
                $get('divNoParameters').style.display = 'none';
                var testStepId = dataItem.primaryKey;
                var linkedTestCaseId = dataItem.alternateKey;
                this._currentTestStepId = testStepId;
                globalFunctions.display_spinner();
                Inflectra.SpiraTest.Web.Services.Ajax.TestStepService.RetrieveParameters(testStepId, linkedTestCaseId, AspNetAjax$Function.createDelegate(this, this.grdTestSteps_rowEditAlternate_success), AspNetAjax$Function.createDelegate(this, this.grdTestSteps_rowEditAlternate_failure));
                var pnlEditTestLink = $find(pnlEditTestLink_id);
                pnlEditTestLink.display(evt);
            }
        },
        grdTestSteps_rowEditAlternate_success: function (data) {
            globalFunctions.hide_spinner();
            if (data && data.length > 0) {
                $get('divHasParameters').style.display = 'block';
            }
            else {
                $get('divNoParameters').style.display = 'block';
            }
            if (this._testStepParametersViewModel) {
                ko.mapping.fromJS(data, this._testStepParametersViewModel);
            }
            else {
                this._testStepParametersViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(this._testStepParametersViewModel, $get('tblTestStepParametersEdit'));
            }
        },
        grdTestSteps_rowEditAlternate_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._lblTestStepMessages, exception);
        },
        pnlEditTestLink_tblTestStepParametersEdit_keydown: function (data, evt) {
            var keynum = evt.keyCode | evt.which;
            if (keynum == 13) {
                evt.preventDefault();
                evt.stopPropagation();
                this.pnlEditTestLink_lnkTestLinkUpdate_click(evt);
                return false;
            }
            return true;
        },
        pnlEditTestLink_lnkTestLinkUpdate_click: function (evt) {
            var testStepId = this._currentTestStepId;
            var parameterValues = ko.mapping.toJS(this._testStepParametersViewModel);
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestStepService.UpdateParameters(SpiraContext.ProjectId, testStepId, parameterValues, AspNetAjax$Function.createDelegate(this, this.tblTestStepParametersUpdate_success), AspNetAjax$Function.createDelegate(this, this.tblTestStepParametersUpdate_failure));
        },
        tblTestStepParametersUpdate_success: function () {
            globalFunctions.hide_spinner();
            var pnlEditTestLink = $find(pnlEditTestLink_id);
            pnlEditTestLink.close();
            $find(grdTestSteps_id).load_data();
        },
        tblTestStepParametersUpdate_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._lblTestStepMessages, exception);
        },
        lnkInsertLink_click: function (evt) {
            var grdTestSteps = $find(grdTestSteps_id);
            var items = grdTestSteps._get_selected_items();
            if (items.length <= 1) {
                var pnlInsertTestLink = $find(pnlInsertTestLink_id);
                pnlInsertTestLink.display(evt);
                if (!this._testFolders) {
                    globalFunctions.display_spinner();
                    Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.RetrieveTestFolders(SpiraContext.ProjectId, AspNetAjax$Function.createDelegate(this, this.load_linkedTestCaseFolders_success), AspNetAjax$Function.createDelegate(this, this.load_linkedTestCaseFolders_failure));
                }
            }
            else {
                globalFunctions.globalAlert(resx.Global_SelectOneCheckBoxForInsert);
            }
        },
        radLinkType_clicked: function () {
            var val = $('input:radio[name=radLinkType]:checked').val();
            if (val == 'link-existing') {
                $('label.btn[for=radLinkNew]').removeClass('active');
                $('label.btn[for=radLinkExisting]').addClass('active');
                $('#section-link-existing').css('display', 'block');
                $('#section-link-new').css('display', 'none');
                $('#radLinkExistinglabel').addClass('btn primary-button');
                $('#radLinkNewlabel').removeClass('btn secondary-button');
            }
            if (val == 'link-create-new') {
                $('label.btn[for=radLinkExisting]').removeClass('active');
                $('label.btn[for=radLinkNew]').addClass('active');
                $('#section-link-existing').css('display', 'none');
                $('#section-link-new').css('display', 'block');
                $('#radLinkExistinglabel').removeClass('active');
                $('#radLinkNewlabel').addClass('active');
                if (!this._testFolders3) {
                    globalFunctions.display_spinner();
                    Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.RetrieveTestFolders(SpiraContext.ProjectId, AspNetAjax$Function.createDelegate(this, this.load_newLinkedTestCaseFolders_success), AspNetAjax$Function.createDelegate(this, this.load_newLinkedTestCaseFolders_failure));
                }
                this.tblNewLinkedTestCaseParameters_dataBind();
            }
        },
        load_linkedTestCaseFolders_success: function (data) {
            globalFunctions.hide_spinner();
            this._testFolders = data;
            var ddlLinkedTestCaseFolders = $find(ddlLinkedTestCaseFolders_id);
            ddlLinkedTestCaseFolders.set_dataSource(data);
            ddlLinkedTestCaseFolders.dataBind();
        },
        load_linkedTestCaseFolders_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgInsertTestLinkMessages, exception);
        },
        ddlLinkedTestCaseFolders_changed: function (item) {
            var ajxLinkedTestCaseSelector = $find(ajxLinkedTestCaseSelector_id);
            var folderId = item.get_value();
            if (folderId && folderId != '') {
                var standardFilters = { TestCaseFolderId: globalFunctions.serializeValueInt(folderId) };
                ajxLinkedTestCaseSelector.set_standardFilters(standardFilters);
            }
            else {
                ajxLinkedTestCaseSelector.set_standardFilters(null);
            }
            ajxLinkedTestCaseSelector.load_data();
        },
        execute_test_case: function () {
            Inflectra.SpiraTest.Web.Services.Ajax.TestRunService.RetrievePendingByUserIdAndTestCase(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.retrieveExistingPending_success), AspNetAjax$Function.createDelegate(this, this.execute_test_case_process));
        },
        retrieveExistingPending_success: function (data) {
            if (data && data.length) {
                globalFunctions.dlgGlobalDynamicClear();
                ReactDOM.render(React.createElement(RctTestRunsPendingExecuteNewOrExisting, {
                    data: data,
                    newTestName: resx.TestCaseList_ExecuteTestCase,
                    executeFunction: this.execute_test_case_process
                }, null), document.getElementById('dlgGlobalDynamic'));
            }
            else {
                this.execute_test_case_process();
            }
        },
        execute_test_case_process: function (testRunsPendingId) {
            if (!testRunsPendingId) {
                var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
                ajxBackgroundProcessManager.display(SpiraContext.ProjectId, 'TestCase_Execute', resx.TestCaseList_ExecuteTestCase, resx.TestCaseList_ExecuteTestCaseDesc, SpiraContext.ArtifactId);
            }
            else {
                window.open(globalFunctions.getArtifactDefaultUrl(SpiraContext.BaseUrl, SpiraContext.ProjectId, "TestExecute", testRunsPendingId), "_self");
            }
        },
        ajxBackgroundProcessManager_success: function (msg, returnCode) {
            if (returnCode && returnCode > 0) {
                var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
                var baseUrl = msg === "testcase_executeexploratory" ? urlTemplate_testRunsPendingExploratory : urlTemplate_testRunsPending;
                var url = baseUrl.replace(globalFunctions.artifactIdToken, returnCode).replace(globalFunctions.projectIdToken, SpiraContext.ProjectId);
                window.location.href = url;
            }
        },
        pnlInsertTestLink_ajxLinkedTestCaseSelector_loaded: function () {
            var divTestStepParametersAdd = $get('divTestStepParametersAdd');
            divTestStepParametersAdd.style.display = 'none';
        },
        pnlInsertTestLink_ajxLinkedTestCaseSelector_selected: function (testCaseId) {
            if (testCaseId == SpiraContext.ArtifactId) {
                globalFunctions.display_error_message(this._msgInsertTestLinkMessages, resx.TestCaseDetails_CannotLinkToSelf);
                lnkAddTestLink.disabled = true;
            }
            else {
                $get('divHasParametersAdd').style.display = 'none';
                $get('divNoParametersAdd').style.display = 'none';
                lnkAddTestLink.disabled = false;
                var divTestStepParametersAdd = $get('divTestStepParametersAdd');
                divTestStepParametersAdd.style.display = 'block';
                globalFunctions.display_spinner();
                Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.RetrieveParameters(testCaseId, true, false, AspNetAjax$Function.createDelegate(this, this.tblTestStepParametersAdd_success), AspNetAjax$Function.createDelegate(this, this.tblTestStepParametersAdd_failure));
            }
        },
        tblTestStepParametersAdd_success: function (data) {
            if (data) {
                for (var item in data) {
                    if (!data[item].Fields.DefaultValue.textValue) {
                        data[item].Fields.DefaultValue.textValue = '';
                    }
                }
            }
            globalFunctions.hide_spinner();
            if (this._insertLinkParametersViewModel) {
                ko.mapping.fromJS(data, this._insertLinkParametersViewModel);
            }
            else {
                this._insertLinkParametersViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(this._insertLinkParametersViewModel, $get('tblTestStepParametersAdd'));
            }
            if (data && data.length > 0) {
                $get('divHasParametersAdd').style.display = 'block';
            }
            else {
                $get('divNoParametersAdd').style.display = 'block';
            }
        },
        tblTestStepParametersAdd_failure: function (exception) {
            globalFunctions.hide_spinner();
            if (exception.get_exceptionType() == 'Inflectra.SpiraTest.Business.EntityInfiniteRecursionException') {
                globalFunctions.display_error_message(this._msgInsertTestLinkMessages, resx.TestCaseDetails_CannotLinkToParent);
            }
            else {
                globalFunctions.display_error(this._msgInsertTestLinkMessages, exception);
            }
        },
        pnlInsertTestLink_lnkAddTestLink_click: function () {
            var val = $('input:radio[name=radLinkType]:checked').val();
            if (val == 'link-existing') {
                var ajxLinkedTestCaseSelector = $find(ajxLinkedTestCaseSelector_id);
                var testCaseIds = ajxLinkedTestCaseSelector.get_selectedItems();
                if (testCaseIds && testCaseIds.length > 0) {
                    var grdTestSteps = $find('cplMainContent_grdTestSteps');
                    var existingFilters = grdTestSteps.get_standardFilters();
                    var testCaseId = testCaseIds[0];
                    if (testCaseId != SpiraContext.ArtifactId) {
                        var filterPrefix = 'TestStepParameter_';
                        for (var i = 0; i < this._insertLinkParametersViewModel().length; i++) {
                            var dataItem = this._insertLinkParametersViewModel()[i];
                            if (dataItem.Fields.DefaultValue.textValue() && dataItem.Fields.DefaultValue.textValue() != '') {
                                var parameterAttribute = dataItem.Fields.Name.textValue();
                                existingFilters[filterPrefix + parameterAttribute] = globalFunctions.serializeValueString(dataItem.Fields.DefaultValue.textValue());
                            }
                        }
                        existingFilters['LinkedTestCaseId'] = globalFunctions.serializeValueInt(testCaseId);
                        grdTestSteps.insert_item('Link');
                        existingFilters['LinkedTestCaseId'] = '';
                        for (var i = 0; i < this._insertLinkParametersViewModel().length; i++) {
                            var dataItem = this._insertLinkParametersViewModel()[i];
                            if (dataItem.Fields.DefaultValue.textValue() && dataItem.Fields.DefaultValue.textValue() != '') {
                                var parameterAttribute = dataItem.Fields.Name.textValue();
                                existingFilters[filterPrefix + parameterAttribute] = '';
                            }
                        }
                        var pnlInsertTestLink = $find(pnlInsertTestLink_id);
                        pnlInsertTestLink.close();
                    }
                }
                else {
                    globalFunctions.globalAlert(resx.TestCaseDetails_SelectTestCaseFirst);
                }
            }
            if (val == 'link-create-new') {
                if (!SpiraContext.uiState) {
                    SpiraContext.uiState = {};
                }
                SpiraContext.uiState.testCaseDetails = {};
                var pageState = SpiraContext.uiState.testCaseDetails;
                pageState.testCaseName = globalFunctions.trim($get(txtNewLinkedTestCase_id).value);
                if (pageState.testCaseName && pageState.testCaseName.length > 0) {
                    pageState.folderId = null;
                    var item = $find(ddlNewLinkedTestCaseFolders_id).get_selectedItem();
                    if (item && item.get_value() && item.get_value() != '') {
                        pageState.folderId = item.get_value();
                    }
                    pageState.testStepId = null;
                    var grdTestSteps = $find(grdTestSteps_id);
                    var items = grdTestSteps._get_selected_items();
                    if (items.length > 0) {
                        pageState.testStepId = items[0];
                    }
                    pageState.parameters = ko.mapping.toJS(this._insertNewLinkParametersViewModel.parameters);
                    pageState.thisRef = this;
                    var grdTestStepsMain = $find('cplMainContent_grdTestSteps');
                    if (grdTestStepsMain._isInEdit) {
                        grdTestStepsMain._onUpdateClick(this.pnlInsertTestLink_lnkAddNewTestAsLink, null);
                    }
                    else {
                        this.pnlInsertTestLink_lnkAddNewTestAsLink();
                    }
                }
                else {
                    globalFunctions.globalAlert(resx.TestCaseDetails_EnterTestCaseNameForNewLink);
                }
            }
        },
        pnlInsertTestLink_lnkAddNewTestAsLink: function () {
            var localState = SpiraContext.uiState.testCaseDetails;
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestStepService.TestStep_CreateNewLinkedTestCase(SpiraContext.ProjectId, SpiraContext.ArtifactId, localState.testStepId, localState.folderId, localState.testCaseName, localState.parameters, AspNetAjax$Function.createDelegate(localState.thisRef, localState.thisRef.pnlInsertTestLink_createNewLinkedTestCase_success), AspNetAjax$Function.createDelegate(localState.thisRef, localState.thisRef.pnlInsertTestLink_createNewLinkedTestCase_failure));
            SpiraContext.uiState.testCaseDetails = {};
        },
        pnlInsertTestLink_rptTestStepParameters_keydown: function (data, evt) {
            var keynum = evt.keyCode | evt.which;
            if (keynum == 13) {
                evt.preventDefault();
                evt.stopPropagation();
                this.pnlInsertTestLink_lnkAddTestLink_click();
                return false;
            }
            return true;
        },
        displayImportStepsDialog: function (evt) {
            var grdTestSteps = $find(grdTestSteps_id);
            var items = grdTestSteps._get_selected_items();
            if (items.length <= 1) {
                var pnlImportTestCase = $find(pnlImportTestCase_id);
                pnlImportTestCase.display(evt);
                if (!this._testFolders2) {
                    globalFunctions.display_spinner();
                    Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService.RetrieveTestFolders(SpiraContext.ProjectId, AspNetAjax$Function.createDelegate(this, this.load_importTestCaseFolders_success), AspNetAjax$Function.createDelegate(this, this.load_importTestCaseFolders_failure));
                }
            }
            else {
                globalFunctions.globalAlert(resx.Global_SelectOneCheckBoxForImport);
            }
        },
        load_importTestCaseFolders_success: function (data) {
            globalFunctions.hide_spinner();
            this._testFolders2 = data;
            var ddlImportTestCaseFolders = $find(ddlImportTestCaseFolders_id);
            ddlImportTestCaseFolders.set_dataSource(data);
            ddlImportTestCaseFolders.dataBind();
        },
        load_importTestCaseFolders_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgImportTestCaseMessages, exception);
        },
        ddlImportTestCaseFolders_changed: function (item) {
            var folderId = item.get_value();
            var ajxImportTestCaseSelector = $find(ajxImportTestCaseSelector_id);
            if (folderId && folderId != '') {
                var standardFilters = { TestCaseFolderId: globalFunctions.serializeValueInt(folderId) };
                ajxImportTestCaseSelector.set_standardFilters(standardFilters);
            }
            else {
                ajxImportTestCaseSelector.set_standardFilters(null);
            }
            ajxImportTestCaseSelector.load_data();
        },
        pnlImportTestCase_ajxImportTestCaseSelector_selected: function (testCaseId) {
            if (testCaseId == SpiraContext.ArtifactId) {
                globalFunctions.display_error_message(this._msgImportTestCaseMessages, resx.TestCaseDetails_CannotImportSelf);
                $('#btnImportTestCase').prop('disabled', true);
            }
            else {
                $('#btnImportTestCase').prop('disabled', false);
            }
        },
        pnlImportTestCase_btnImportTestCase_click: function () {
            var ajxImportTestCaseSelector = $find(ajxImportTestCaseSelector_id);
            var testCaseIds = ajxImportTestCaseSelector.get_selectedItems();
            if (testCaseIds && testCaseIds.length > 0) {
                var grdTestSteps = $find('cplMainContent_grdTestSteps');
                var testCaseToImportId = testCaseIds[0];
                var testStepId = null;
                var grdTestSteps = $find(grdTestSteps_id);
                var items = grdTestSteps._get_selected_items();
                if (items.length > 0) {
                    testStepId = items[0];
                }
                globalFunctions.display_spinner();
                Inflectra.SpiraTest.Web.Services.Ajax.TestStepService.TestStep_ImportTestCase(SpiraContext.ProjectId, SpiraContext.ArtifactId, testCaseToImportId, testStepId, AspNetAjax$Function.createDelegate(this, this.pnlImportTestCase_btnImportTestCase_success), AspNetAjax$Function.createDelegate(this, this.pnlImportTestCase_btnImportTestCase_failure));
            }
        },
        pnlImportTestCase_btnImportTestCase_success: function () {
            globalFunctions.hide_spinner();
            var pnlImportTestCase = $find(pnlImportTestCase_id);
            pnlImportTestCase.close();
            $find(grdTestSteps_id).load_data();
        },
        pnlImportTestCase_btnImportTestCase_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgImportTestCaseMessages, exception);
        },
        load_newLinkedTestCaseFolders_success: function (data) {
            globalFunctions.hide_spinner();
            this._testFolders3 = data;
            var ddlNewLinkedTestCaseFolders = $find(ddlNewLinkedTestCaseFolders_id);
            ddlNewLinkedTestCaseFolders.set_dataSource(data);
            ddlNewLinkedTestCaseFolders.dataBind();
        },
        load_newLinkedTestCaseFolders_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgInsertTestLinkMessages, exception);
        },
        tblNewLinkedTestCaseParameters_dataBind: function () {
            if (!this._insertNewLinkParametersViewModel) {
                this._insertNewLinkParametersViewModel = {
                    parameters: new ko.observableArray()
                };
                ko.applyBindings(this._insertNewLinkParametersViewModel, $get('tblNewLinkedTestCaseParameters'));
            }
            else {
                this._insertNewLinkParametersViewModel.parameters.removeAll();
            }
            var testCaseParameter = {
                __type: globalFunctions.dataType_DataItem,
                Fields: {
                    Name: {
                        __type: globalFunctions.dataType_DataItemField,
                        fieldName: "Name",
                        textValue: ''
                    },
                    Value: {
                        __type: globalFunctions.dataType_DataItemField,
                        fieldName: "Value",
                        textValue: ''
                    }
                }
            };
            this._insertNewLinkParametersViewModel.parameters.push(testCaseParameter);
        },
        tblNewLinkedTestCaseParameters_keyup: function (data, evt) {
            var newParamNeeded = true;
            for (var i = 0; i < this._insertNewLinkParametersViewModel.parameters().length; i++) {
                if (this._insertNewLinkParametersViewModel.parameters()[i].Fields.Name.textValue == '') {
                    newParamNeeded = false;
                    break;
                }
            }
            if (newParamNeeded) {
                var testCaseParameter = {
                    __type: globalFunctions.dataType_DataItem,
                    Fields: {
                        Name: {
                            __type: globalFunctions.dataType_DataItemField,
                            fieldName: "Name",
                            textValue: ''
                        },
                        Value: {
                            __type: globalFunctions.dataType_DataItemField,
                            fieldName: "Value",
                            textValue: ''
                        }
                    }
                };
                this._insertNewLinkParametersViewModel.parameters.push(testCaseParameter);
            }
        },
        pnlInsertTestLink_createNewLinkedTestCase_success: function () {
            $get(txtNewLinkedTestCase_id).value = '';
            this.tblNewLinkedTestCaseParameters_dataBind();
            globalFunctions.hide_spinner();
            var pnlInsertTestLink = $find(pnlInsertTestLink_id);
            pnlInsertTestLink.close();
            $find(grdTestSteps_id).load_data();
        },
        pnlInsertTestLink_createNewLinkedTestCase_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgInsertTestLinkMessages, exception);
        },
    };
//# sourceMappingURL=TestCaseDetails.js.map