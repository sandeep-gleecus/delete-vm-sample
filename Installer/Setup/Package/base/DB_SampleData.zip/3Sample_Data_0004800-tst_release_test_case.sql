/***************************************************************
**	Insert script for table TST_RELEASE_TEST_CASE
***************************************************************/
INSERT INTO TST_RELEASE_TEST_CASE
(
RELEASE_ID, TEST_CASE_ID, EXECUTION_STATUS_ID, EXECUTION_DATE, ACTUAL_DURATION
)
VALUES
(
1, 2, 1, DATEADD(day, -24, SYSUTCDATETIME()), 70
),
(
1, 3, 6, DATEADD(day, -25, SYSUTCDATETIME()), 50
),
(
1, 4, 1, DATEADD(day, -25, SYSUTCDATETIME()), 90
),
(
1, 5, 2, DATEADD(day, -40, SYSUTCDATETIME()), 90
),
(
1, 6, 2, DATEADD(day, -60, SYSUTCDATETIME()), 90
),
(
1, 8, 2, DATEADD(day, -88, SYSUTCDATETIME()), 90
),
(
1, 9, 2, DATEADD(day, -26, SYSUTCDATETIME()), 90
),
(
2, 2, 2, DATEADD(day, -61, SYSUTCDATETIME()), 90
),
(
2, 3, 3, NULL, NULL
),
(
2, 4, 3, NULL, NULL
),
(
2, 5, 5, DATEADD(day, -85, SYSUTCDATETIME()), 95
),
(
2, 6, 2, DATEADD(day, -60, SYSUTCDATETIME()), 90
),
(
2, 8, 2, DATEADD(day, -90, SYSUTCDATETIME()), 90
),
(
2, 9, 3, NULL, NULL
),
(
3, 5, 2, DATEADD(day, -40, SYSUTCDATETIME()), 90
),
(
3, 9, 2, DATEADD(day, -26, SYSUTCDATETIME()), 90
),
(
4, 2, 1, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
4, 3, 1, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
4, 4, 6, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
4, 5, 6, DATEADD(day, -10, SYSUTCDATETIME()), 65
),
(
4, 6, 3, NULL, NULL
),
(
4, 8, 2, DATEADD(day, -10, SYSUTCDATETIME()), 0
),
(
4, 9, 2, DATEADD(day, -9, SYSUTCDATETIME()), 75
),
(
4, 12, 3, NULL, NULL
),
(
4, 13, 2, DATEADD(day, -15, SYSUTCDATETIME()), 1
),
(
5, 4, 3, NULL, NULL
),
(
5, 5, 3, NULL, NULL
),
(
5, 6, 3, NULL, NULL
),
(
5, 8, 3, NULL, NULL
),
(
5, 9, 3, NULL, NULL
),
(
5, 12, 3, NULL, NULL
),
(
5, 13, 3, NULL, NULL
),
(
6, 3, 3, NULL, NULL
),
(
6, 4, 3, NULL, NULL
),
(
6, 5, 3, NULL, NULL
),
(
6, 6, 3, NULL, NULL
),
(
6, 9, 3, NULL, NULL
),
(
6, 12, 3, NULL, NULL
),
(
6, 13, 3, NULL, NULL
),
(
8, 3, 2, DATEADD(day, -40, SYSUTCDATETIME()), 0
),
(
8, 13, 2, DATEADD(day, -38, SYSUTCDATETIME()), 0
),
(
17, 2, 2, DATEADD(day, -12, SYSUTCDATETIME()), 70
),
(
17, 3, 2, DATEADD(day, -14, SYSUTCDATETIME()), 70
),
(
17, 4, 2, DATEADD(day, -10, SYSUTCDATETIME()), 30
),
(
17, 8, 2, DATEADD(day, -10, SYSUTCDATETIME()), 0
),
(
18, 2, 2, DATEADD(day, -2, SYSUTCDATETIME()), 70
),
(
18, 3, 5, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
18, 4, 6, DATEADD(day, -1, SYSUTCDATETIME()), 70
),
(
19, 2, 1, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
19, 3, 1, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
19, 4, 6, DATEADD(day, 0, SYSUTCDATETIME()), 70
),
(
19, 5, 3, NULL, NULL
)
GO

