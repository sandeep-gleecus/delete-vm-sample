var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ReactGantt = (function (_super) {
    __extends(ReactGantt, _super);
    function ReactGantt(props) {
        var _this = _super.call(this, props) || this;
        _this.scaleConfigs = [
            {
                scales: [
                    { subscale_unit: "minute", unit: "hour", step: 1, format: "%H" },
                    { unit: "minute", step: 1, format: "%H:%i" }
                ]
            },
            {
                scales: [
                    { subscale_unit: "hour", unit: "day", step: 1, format: "%j %M" },
                    { unit: "hour", step: 1, format: "%H:%i" }
                ]
            },
            {
                scales: [
                    { subscale_unit: "day", unit: "month", step: 1, format: "%F" },
                    { unit: "day", step: 1, format: "%j" }
                ]
            },
            {
                scales: [
                    { subscale_unit: "week", unit: "month", step: 1, date: "%F" },
                    {
                        unit: "week", step: 1, template: function (date) {
                            var dateToStr = gantt.date.date_to_str("%d %M");
                            var endDate = gantt.date.add(gantt.date.add(date, 1, "week"), -1, "day");
                            return dateToStr(date) + " - " + dateToStr(endDate);
                        }
                    }
                ]
            },
            {
                scales: [
                    { subscale_unit: "month", unit: "year", step: 1, format: "%Y" },
                    { unit: "month", step: 1, format: "%M" }
                ]
            },
            {
                scales: [
                    { subscale_unit: "month", unit: "year", step: 3, format: "%Y" },
                    {
                        unit: "month", step: 3, template: function (date) {
                            var dateToStr = gantt.date.date_to_str("%M");
                            var endDate = gantt.date.add(gantt.date.add(date, 3, "month"), -1, "day");
                            return dateToStr(date) + " - " + dateToStr(endDate);
                        }
                    }
                ]
            },
            {
                scales: [
                    { subscale_unit: "year", unit: "year", step: 1, date: "%Y" },
                    {
                        unit: "year", step: 5, template: function (date) {
                            var dateToStr = gantt.date.date_to_str("%Y");
                            var endDate = gantt.date.add(gantt.date.add(date, 5, "year"), -1, "day");
                            return dateToStr(date) + " - " + dateToStr(endDate);
                        }
                    }
                ]
            },
            {
                scales: [
                    {
                        subscale_unit: "year", unit: "year", step: 10, template: function (date) {
                            var dateToStr = gantt.date.date_to_str("%Y");
                            var endDate = gantt.date.add(gantt.date.add(date, 10, "year"), -1, "day");
                            return dateToStr(date) + " - " + dateToStr(endDate);
                        }
                    },
                    {
                        unit: "year", step: 100, template: function (date) {
                            var dateToStr = gantt.date.date_to_str("%Y");
                            var endDate = gantt.date.add(gantt.date.add(date, 100, "year"), -1, "day");
                            return dateToStr(date) + " - " + dateToStr(endDate);
                        }
                    }
                ]
            }
        ];
        return _this;
    }
    ReactGantt.prototype.componentDidMount = function () {
        this._updateChart();
    };
    ReactGantt.prototype.componentDidUpdate = function () {
        this._updateChart();
    };
    ReactGantt.prototype._updateChart = function () {
        if (this.props.tasks && this.props.tasks.data && this.props.tasks.data.length) {
            gantt.config.xml_date = this.props.config.xml_date;
            gantt.config.readonly = this.props.config.readonly;
            gantt.config.root_id = this.props.config.root_id;
            gantt.config.columns = this.props.config.columns;
            gantt.templates.grid_row_class = this.props.templateGridRowClass;
            if (this.props.isCustomTaskClass) {
                gantt.templates.task_class = function (start, end, task) { return task.taskBgClass || ""; };
            }
            gantt.templates.grid_folder = function (item) {
                return "<div class='gantt_tree_icon " + (item.iconClass ? "workspace-" + item.iconClass : (item.$open ? " gantt_folder_open" : "gantt_folder_closed")) + "'></div>";
            };
            gantt.templates.grid_file = function (item) {
                return "<div class='gantt_tree_icon " + (item.iconClass ? "workspace-" + item.iconClass : "gantt_file") + "'></div>";
            };
            gantt.init(this.ganttContainer);
            gantt.parse(this.props.tasks);
            gantt.attachEvent("onBeforeLightbox", function (task_id) {
                return this.props.isLightboxEnabled ? true : false;
            });
            if (this.props.zoomToFit)
                this.zoomToFit();
        }
    };
    ReactGantt.prototype.applyConfig = function (config, dates) {
        if (config.scales[0].date) {
            gantt.templates.date_scale = null;
        }
        else {
            gantt.templates.date_scale = config.scales[0].template;
        }
        gantt.config.scales = config.scales;
        if (dates && dates.start_date && dates.start_date) {
            gantt.config.start_date = gantt.date.add(dates.start_date, -1, config.scales[0].subscale_unit);
            gantt.config.end_date = gantt.date.add(gantt.date[config.scales[0].subscale_unit + "_start"](dates.end_date), 2, config.scales[0].subscale_unit);
        }
        else {
            gantt.config.start_date = gantt.config.end_date = null;
        }
    };
    ReactGantt.prototype.zoomToFit = function () {
        var project = gantt.getSubtaskDates(), areaWidth = gantt.$task.offsetWidth;
        for (var i = 0; i < this.scaleConfigs.length; i++) {
            var columnCount = this.getUnitsBetween(project.start_date, project.end_date, this.scaleConfigs[i].scales[0].subscale_unit, this.scaleConfigs[i].scales[0].step);
            if ((columnCount + 2) * gantt.config.min_column_width <= areaWidth) {
                break;
            }
        }
        if (i == this.scaleConfigs.length) {
            i--;
        }
        this.applyConfig(this.scaleConfigs[i], project);
        gantt.render();
    };
    ReactGantt.prototype.getUnitsBetween = function (from, to, unit, step) {
        var start = new Date(from), end = new Date(to);
        var units = 0;
        while (start.valueOf() < end.valueOf()) {
            units++;
            start = gantt.date.add(start, step, unit);
        }
        return units;
    };
    ReactGantt.prototype.render = function () {
        var _this = this;
        return (React.createElement("div", { ref: function (input) { _this.ganttContainer = input; }, style: { width: '100%', height: '100%' } }));
    };
    return ReactGantt;
}(React.Component));
//# sourceMappingURL=rct_comp_reactGantt.js.map