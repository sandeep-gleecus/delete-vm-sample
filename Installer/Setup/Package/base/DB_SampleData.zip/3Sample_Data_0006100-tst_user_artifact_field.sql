/***************************************************************
**	Insert script for table TST_USER_ARTIFACT_FIELD
***************************************************************/
INSERT INTO TST_USER_ARTIFACT_FIELD
(
ARTIFACT_FIELD_ID, PROJECT_ID, USER_ID, IS_VISIBLE, LIST_POSITION
)
VALUES
(
13, 1, 2, 0, NULL
),
(
14, 1, 2, 1, NULL
),
(
17, 1, 2, 0, NULL
),
(
35, 1, 2, 0, NULL
),
(
36, 1, 2, 0, NULL
),
(
94, 1, 2, 1, 21
)
GO

