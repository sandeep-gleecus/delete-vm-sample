INSERT INTO [TST_GLOBAL_FILETYPES] ([FILETYPE_MIME], [FILETYPE_ICON], [FILE_EXTENSION], [FILE_DESCRIPTION]) VALUES
	('text/x-yaml', 'Text.svg', 'yml', 'YAML File'),
	('text/x-yaml', 'Text.svg', 'yaml', 'YAML File'),
	('text/x-typescript','VBScript.svg','ts','TypeScript File'),
	('text/x-typescript','VBScript.svg','tsx','TypeScript File'),
	('application/x-bat','Text.svg','bat','Windows Batch File'),
	('image/svg+xml','TIFF-Image.svg','svg','Scalable Vector Graphics'),
	('text/x-feature','Text.svg','feature','Gherkin Feature File'),
	('text/markdown','Text.svg','md','Markdown File'),
	('text/markdown','Text.svg','markdown','Markdown File');