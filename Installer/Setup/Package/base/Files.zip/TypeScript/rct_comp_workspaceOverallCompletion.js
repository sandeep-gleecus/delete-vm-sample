var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var WorkspaceOverallCompletion = (function (_super) {
    __extends(WorkspaceOverallCompletion, _super);
    function WorkspaceOverallCompletion(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            requirementsDone: Math.round(_this.props.workspace.percentComplete / 100 * _this.props.workspace.requirementsAll),
            thresholds: SpiraContext.dashboard.completionBars.map(function (x) { return x.gaugeThreshold / 100 * _this.props.workspace.requirementsAll; }),
            legendActive: _this.setLegend(SpiraContext.dashboard.completionBars, _this.props.workspace.percentComplete, "gaugeThreshold")
        };
        return _this;
    }
    WorkspaceOverallCompletion.prototype.componentDidMount = function () {
    };
    WorkspaceOverallCompletion.prototype.setLegend = function (legends, value, key) {
        var legendsArray = legends
            .filter(function (x) { return x[key] !== undefined && x[key] > value; })
            .reduce(function (previous, current) { return (previous[key] < current[key]) ? previous : current; });
        return legendsArray || null;
    };
    WorkspaceOverallCompletion.prototype.render = function () {
        return (React.createElement("div", { className: "df flex-column d-flex" }, this.props.workspace.requirementsAll > 0 ?
            React.createElement(React.Fragment, null,
                React.createElement("div", { className: "w9 self-center mb4" },
                    React.createElement(ReactC3Chart, { data: {
                            columns: [[this.state.legendActive ? this.state.legendActive.label : "", this.state.requirementsDone]],
                            type: "gauge",
                        }, color: {
                            pattern: SpiraContext.dashboard.completionBars.filter(function (x) { return x.gaugeThreshold != "undefined"; }).map(function (x) { return x.color; }),
                            threshold: {
                                values: this.state.thresholds
                            }
                        }, legend: { show: false }, tooltip: { show: false }, gauge: {
                            label: {
                                show: true,
                                format: function (value, ratio) {
                                    return ratio ? Math.floor(ratio * 100) + "%" : "";
                                }
                            },
                            min: 0,
                            max: this.props.workspace.requirementsAll
                        } }),
                    React.createElement("div", { className: "flex items-center m-x-10 mt-3 d-flex justify-content-center gap-2" }, SpiraContext.dashboard.completionBars.filter(function (x) { return x.gaugeThreshold !== undefined; }).map(function (x) { return (React.createElement("div", { class: "d-flex align-items-center" },
                        console.log(x),
                        React.createElement("div", { class: "me-2", style: { backgroundColor: x.key === "complete" ? "#60B099" : x.key === "inProgress" ? "#138493" : x.color, width: "12px", height: "12px" } }),
                        React.createElement("div", null, x.label))); }))))
            :
                React.createElement("div", { className: "ma4 alert alert-info", role: "alert" }, resx.Global_NoDataToDisplay)));
    };
    return WorkspaceOverallCompletion;
}(React.Component));
//# sourceMappingURL=rct_comp_workspaceOverallCompletion.js.map