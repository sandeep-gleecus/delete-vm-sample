/***************************************************************
**	Insert script for table TST_TEMPLATE_OUTTYPE
***************************************************************/
SET IDENTITY_INSERT TST_TEMPLATE_OUTTYPE ON; 

INSERT INTO TST_TEMPLATE_OUTTYPE
(
OUTPUTTYPEID, TEMPLATEID, TYPEDESCRIPTION
)
VALUES
(
3217, 3098, 'Word'
),
(
3218, 3099, 'Word'
),
(
3219, 3100, 'Word'
),
(
3220, 3101, 'Word'
),
(
3221, 3102, 'Word'
),
(
3222, 3103, 'Word'
)
GO

SET IDENTITY_INSERT TST_TEMPLATE_OUTTYPE OFF; 

