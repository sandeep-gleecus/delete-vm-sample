var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var WorkspaceProductCompletion = (function (_super) {
    __extends(WorkspaceProductCompletion, _super);
    function WorkspaceProductCompletion(props) {
        var _this = _super.call(this, props) || this;
        _this.lateScheduleBar = SpiraContext.dashboard.scheduleBars.filter(function (x) { return x.key == SpiraContext.dashboard.schedule.late.enum; });
        _this.state = {
            childWorkspaces: null,
            daysDoneAsCount: null,
            daysDoneAsPercent: null,
            daysDoneColorLate: _this.lateScheduleBar && _this.lateScheduleBar.length ? _this.lateScheduleBar[0].color : null,
            daysDoneColors: SpiraContext.dashboard.scheduleBars.reduce(function (a, b) { a[b.label] = b.color; return a; }, {}),
            daysDoneGroups: [SpiraContext.dashboard.scheduleBars.map(function (x) { return x.label; })],
            daysDoneLabels: null,
            daysDoneToDisplay: null,
            isDisplayingPercent: true,
            rqsDoneAsCount: null,
            rqsDoneAsPercent: null,
            rqsDoneColors: SpiraContext.dashboard.completionBars.reduce(function (a, b) { a[b.label] = b.color; return a; }, {}),
            rqsDoneGroups: [SpiraContext.dashboard.completionBars.map(function (x) { return x.label; })],
            rqsDoneLabels: null,
            rqsDoneToDisplay: null,
        };
        _this.daysDoneSet = _this.daysDoneSet.bind(_this);
        _this.toggleDisplayType = _this.toggleDisplayType.bind(_this);
        _this.inProgressScheduleBars = SpiraContext.dashboard.scheduleBars.filter(function (x) { return x.lowerThreshold != undefined; });
        return _this;
    }
    WorkspaceProductCompletion.prototype.componentDidMount = function () {
        this.childWorkspaceSetOverdueData();
    };
    WorkspaceProductCompletion.prototype.childWorkspaceSetOverdueData = function () {
        var _this = this;
        var today = new Date();
        var updatedSprints, updatedReleases, updatedProducts, updatedPrograms, updatedPortfolios, childWorkspaces;
        if (this.props.sprints && this.props.sprints.length) {
            updatedSprints = this.props.sprints.map(function (r) { return _this.overdueWorkspaceSet(r, today, null); });
        }
        if (this.props.releases && this.props.releases.length) {
            updatedReleases = this.props.releases.map(function (r) {
                var children = updatedSprints && updatedSprints.length ? updatedSprints.filter(function (x) { return x.parentId == r.workspaceId; }) : null;
                return _this.overdueWorkspaceSet(r, today, children);
            });
        }
        if (this.props.products && this.props.products.length) {
            updatedProducts = this.props.products.map(function (pr) {
                var children = updatedReleases && updatedReleases.length ? updatedReleases.filter(function (x) { return x.parentId == pr.workspaceId; }) : null;
                return _this.overdueWorkspaceSet(pr, today, children);
            });
        }
        if (this.props.programs && this.props.programs.length) {
            updatedPrograms = this.props.programs.map(function (pg) {
                var children = updatedProducts && updatedProducts.length ? updatedProducts.filter(function (x) { return x.parentId == pg.workspaceId; }) : null;
                return _this.overdueWorkspaceSet(pg, today, children);
            });
        }
        if (this.props.portfolios && this.props.portfolios.length) {
            updatedPortfolios = this.props.portfolios.map(function (pf) {
                var children = updatedPrograms && updatedPrograms.length ? updatedPrograms.filter(function (x) { return x.parentId == pf.workspaceId; }) : null;
                return _this.overdueWorkspaceSet(pf, today, children);
            });
        }
        switch (this.props.workspaceType) {
            case this.props.workspaceEnums.enterprise:
                childWorkspaces = updatedPortfolios;
                break;
            case this.props.workspaceEnums.portfolio:
                childWorkspaces = updatedPrograms;
                break;
            case this.props.workspaceEnums.program:
                childWorkspaces = updatedProducts;
                break;
            case this.props.workspaceEnums.product:
                childWorkspaces = updatedReleases;
                break;
        }
        if (this.props.showSprints && this.props.workspaceType === this.props.workspaceEnums.product && updatedSprints && updatedSprints.length) {
            childWorkspaces = [];
            var residualSprints_1 = updatedSprints;
            if (updatedReleases && updatedReleases.length) {
                updatedReleases.forEach(function (r) {
                    var children = residualSprints_1.filter(function (x) { return x.parentId == r.workspaceId; });
                    childWorkspaces.push(r);
                    if (children && children.length) {
                        residualSprints_1 = residualSprints_1.filter(function (x) { return x.parentId != r.workspaceId; });
                        childWorkspaces.push.apply(childWorkspaces, children);
                    }
                });
            }
            if (residualSprints_1 && residualSprints_1.length) {
                childWorkspaces.push.apply(childWorkspaces, residualSprints_1);
            }
        }
        if (this.props.hideEmptyWorkspaces && childWorkspaces && childWorkspaces.length > 0) {
            childWorkspaces = childWorkspaces.filter(function (x) { return x.requirementsAll > 0; });
        }
        if (this.props.hideEmptyVirtualWorkspaces && childWorkspaces && childWorkspaces.length > 0) {
            childWorkspaces = childWorkspaces.filter(function (x) { return x.workspaceId > 0 || (x.requirementsAll > 0 && x.workspaceId < 0); });
        }
        var workspaceLabels = childWorkspaces && childWorkspaces.length ? childWorkspaces.map(function (x) { return x.workspaceName; }) : [];
        this.setState({
            childWorkspaces: childWorkspaces,
            daysDoneLabels: workspaceLabels,
            rqsDoneLabels: workspaceLabels
        }, function () {
            _this.rqsDoneSet();
            _this.daysDoneSet();
        });
    };
    WorkspaceProductCompletion.prototype.overdueWorkspaceSet = function (item, today, children) {
        var newItem = __assign({}, item);
        var endDate = globalFunctions.parseJsonDate(item.endDate), startDate = globalFunctions.parseJsonDate(item.startDate), daysAllocated = Math.floor((endDate - startDate) / (1000 * 3600 * 24)), childOverdue = children ? children.filter(function (c) { return c.parentId == item.workspaceId; }).filter(function (c) { return c.status == SpiraContext.dashboard.schedule.late.enum; }) : null;
        var status = "notSet";
        var daysPercentComplete = 0;
        if (startDate > today) {
            status = SpiraContext.dashboard.schedule.notStarted.enum;
        }
        else if (item.percentComplete == 100) {
            daysPercentComplete = 100;
            status = SpiraContext.dashboard.schedule.complete.enum;
        }
        else if ((childOverdue && childOverdue.length) || endDate < today ? true : false) {
            var timeOverdue = today - endDate;
            if (timeOverdue > 0) {
                var daysOverdue = Math.floor(timeOverdue / (1000 * 3600 * 24));
                daysPercentComplete = Math.floor((daysAllocated + daysOverdue) / daysAllocated * 100);
            }
            else {
                var daysSinceStart = Math.floor((today - startDate) / (1000 * 3600 * 24));
                daysPercentComplete = Math.floor(daysSinceStart / daysAllocated * 100);
            }
            status = SpiraContext.dashboard.schedule.late.enum;
        }
        else {
            var daysSinceStart = Math.floor((today - startDate) / (1000 * 3600 * 24));
            daysPercentComplete = Math.floor(daysSinceStart / daysAllocated * 100);
            var rqsVsDays = item.percentComplete - daysPercentComplete;
            var thresholds = this.getHighestScheduleMatch(this.inProgressScheduleBars, rqsVsDays, "lowerThreshold");
            status = thresholds && thresholds.key ? thresholds.key : null;
        }
        newItem.status = status;
        newItem.daysAllocated = daysAllocated;
        newItem.daysPercentComplete = daysPercentComplete;
        return newItem;
    };
    WorkspaceProductCompletion.prototype.getHighestScheduleMatch = function (legends, value, key) {
        var legendsArray = legends && legends.length ? legends.filter(function (x) { return x[key] < value; }) : null;
        var highestLegend = legendsArray && legendsArray.length ? legendsArray.reduce(function (previous, current) { return (previous[key] > current[key]) ? previous : current; }) : null;
        return highestLegend || null;
    };
    WorkspaceProductCompletion.prototype.daysDoneSet = function () {
        var percentToNumbers = function (percent, number) { return Math.round(percent * number / 100); };
        if (this.state.childWorkspaces && this.state.childWorkspaces.length) {
            var outputPercent = [
                __spreadArray([SpiraContext.dashboard.schedule.complete.label], this.state.childWorkspaces.map(function (x) {
                    if (x.status == SpiraContext.dashboard.schedule.complete.enum) {
                        return x.daysPercentComplete >= 100 ? 100 : x.daysPercentComplete;
                    }
                    else if (x.status == SpiraContext.dashboard.schedule.late.enum && x.daysPercentComplete > 100) {
                        return 100;
                    }
                    else {
                        return null;
                    }
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.aheadOfSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.aheadOfSchedule.enum ? x.daysPercentComplete : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.onSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.onSchedule.enum ? x.daysPercentComplete : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.behindSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.behindSchedule.enum ? x.daysPercentComplete : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.late.label], this.state.childWorkspaces.map(function (x) {
                    if (x.status == SpiraContext.dashboard.schedule.late.enum) {
                        return x.daysPercentComplete > 100 ? x.daysPercentComplete - 100 : x.daysPercentComplete;
                    }
                    else {
                        return null;
                    }
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.remaining.label], this.state.childWorkspaces.map(function (x) {
                    return x.daysPercentComplete >= 100 ? null : 100 - x.daysPercentComplete;
                }), true),
            ];
            var outputNumbers = [
                __spreadArray([SpiraContext.dashboard.schedule.complete.label], this.state.childWorkspaces.map(function (x) {
                    if (x.status == SpiraContext.dashboard.schedule.complete.enum) {
                        return x.daysPercentComplete >= 100 ? x.daysAllocated : x.daysPercentComplete;
                    }
                    else if (x.status == SpiraContext.dashboard.schedule.late.enum && x.daysPercentComplete > 100) {
                        return x.daysAllocated;
                    }
                    else {
                        return null;
                    }
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.aheadOfSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.aheadOfSchedule.enum ? percentToNumbers(x.daysPercentComplete, x.daysAllocated) : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.onSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.onSchedule.enum ? percentToNumbers(x.daysPercentComplete, x.daysAllocated) : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.behindSchedule.label], this.state.childWorkspaces.map(function (x) {
                    return x.status == SpiraContext.dashboard.schedule.behindSchedule.enum ? percentToNumbers(x.daysPercentComplete, x.daysAllocated) : null;
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.late.label], this.state.childWorkspaces.map(function (x) {
                    if (x.status == SpiraContext.dashboard.schedule.late.enum) {
                        return x.daysPercentComplete > 100 ? percentToNumbers((x.daysPercentComplete - 100), x.daysAllocated) : percentToNumbers(x.daysPercentComplete, x.daysAllocated);
                    }
                    else {
                        return null;
                    }
                }), true),
                __spreadArray([SpiraContext.dashboard.schedule.remaining.label], this.state.childWorkspaces.map(function (x) {
                    return x.daysPercentComplete >= 100 ? null : x.daysAllocated - percentToNumbers(x.daysPercentComplete, x.daysAllocated);
                }), true),
            ];
            this.setState({
                daysDoneAsPercent: outputPercent,
                daysDoneAsCount: outputNumbers,
                daysDoneToDisplay: this.state.daysDoneToDisplay ? this.state.daysDoneToDisplay : outputPercent,
            });
        }
    };
    WorkspaceProductCompletion.prototype.rqsDoneSet = function () {
        var percentToNumbers = function (percent, number) { return Math.round(percent * number / 100); };
        if (this.state.childWorkspaces && this.state.childWorkspaces.length) {
            var outputPercent = [
                __spreadArray([SpiraContext.dashboard.completions.inProgress.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete < 100 ? x.percentComplete : null; }), true),
                __spreadArray([SpiraContext.dashboard.completions.complete.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete == 100 ? 100 : null; }), true),
                __spreadArray([SpiraContext.dashboard.completions.remaining.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete == 100 ? null : 100 - x.percentComplete; }), true),
            ];
            var outputNumbers = [
                __spreadArray([SpiraContext.dashboard.completions.inProgress.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete < 100 ? percentToNumbers(x.percentComplete, x.requirementsAll) : null; }), true),
                __spreadArray([SpiraContext.dashboard.completions.complete.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete == 100 ? percentToNumbers(100, x.requirementsAll) : null; }), true),
                __spreadArray([SpiraContext.dashboard.completions.remaining.label], this.state.childWorkspaces.map(function (x) { return x.percentComplete == 100 ? null : x.requirementsAll - percentToNumbers(x.percentComplete, x.requirementsAll); }), true),
            ];
            this.setState({
                rqsDoneAsPercent: outputPercent,
                rqsDoneAsCount: outputNumbers,
                rqsDoneToDisplay: this.state.rqsDoneToDisplay ? this.state.rqsDoneToDisplay : outputPercent,
            });
        }
    };
    WorkspaceProductCompletion.prototype.toggleDisplayType = function () {
        this.setState({
            isDisplayingPercent: !this.state.isDisplayingPercent,
            rqsDoneToDisplay: !this.state.isDisplayingPercent ? this.state.rqsDoneAsPercent : this.state.rqsDoneAsCount,
            daysDoneToDisplay: !this.state.isDisplayingPercent ? this.state.daysDoneAsPercent : this.state.daysDoneAsCount
        });
    };
    WorkspaceProductCompletion.prototype.render = function () {
        var _a, _b;
        var _this = this;
        return (React.createElement(React.Fragment, null, this.state.childWorkspaces && this.state.childWorkspaces.length > 0 ?
            React.createElement("div", { className: "dib v-top mb5 mx0 w-100" },
                React.createElement("div", { class: "btn-group float-end", role: "group", "aria-label": "Basic example" },
                    console.log(this.state.isDisplayingPercent),
                    React.createElement("button", { className: this.state.isDisplayingPercent ? "btn secondary-button" : "btn primary-button", onClick: this.toggleDisplayType, type: "button" }, resx.Dashboard_Completion_ShowAsNumbers),
                    React.createElement("button", { className: this.state.isDisplayingPercent ? "btn primary-button" : "btn secondary-button", onClick: this.toggleDisplayType, type: "button" }, resx.Dashboard_Completion_ShowAsPercent)),
                React.createElement("div", { className: "flex flex-wrap mt-5 fs-14" },
                    React.createElement("div", { className: "w-60 mt3" },
                        React.createElement("h4", { className: "fs-14 fw-semibold ms-3" }, resx.Dashboard_Completion_ScheduleTitle),
                        React.createElement(ReactC3Chart, { axis: {
                                rotated: true,
                                y: { show: false },
                                x: {
                                    show: true,
                                    type: 'category',
                                    categories: this.state.daysDoneLabels
                                }
                            }, bar: { width: 32 }, data: {
                                colors: this.state.daysDoneColors,
                                color: function (color, d) {
                                    if (d.id && d.id == SpiraContext.dashboard.schedule.remaining.label) {
                                        return null;
                                    }
                                    else if (d.id && d.id == SpiraContext.dashboard.schedule.complete.label) {
                                        if (_this.state.childWorkspaces[d.index].status == SpiraContext.dashboard.schedule.late.enum) {
                                            return _this.state.daysDoneColorLate ? d3.rgb(_this.state.daysDoneColorLate).darker(1) : color;
                                        }
                                        else {
                                            return color;
                                        }
                                    }
                                    else {
                                        return color;
                                    }
                                },
                                columns: this.state.daysDoneToDisplay,
                                groups: this.state.daysDoneGroups,
                                labels: {
                                    format: (_a = {},
                                        _a[SpiraContext.dashboard.schedule.complete.label] = function (v, id, i, j) { return v > 0 ? v : ""; },
                                        _a[SpiraContext.dashboard.schedule.late.label] = function (v, id, i, j) { return v > 0 ? v : ""; },
                                        _a[SpiraContext.dashboard.schedule.aheadOfSchedule.label] = function (v, id, i, j) { return v > 0 ? v : ""; },
                                        _a[SpiraContext.dashboard.schedule.onSchedule.label] = function (v, id, i, j) {
                                            if (v > 0) {
                                                return v;
                                            }
                                            else if (!_this.state.childWorkspaces[i].daysPercentComplete) {
                                                return SpiraContext.dashboard.schedule.notStarted.label;
                                            }
                                            else {
                                                return "";
                                            }
                                        },
                                        _a[SpiraContext.dashboard.schedule.behindSchedule.label] = function (v, id, i, j) { return v > 0 ? v : ""; },
                                        _a)
                                },
                                order: null,
                                type: "bar",
                            }, dataSource: this.state.isDisplayingPercent, size: {
                                height: this.state.daysDoneLabels ? (this.state.daysDoneLabels.length * 50) : 0
                            }, legend: {
                                show: false,
                            } }),
                        React.createElement("div", { className: "acc-wrapper-11" }, SpiraContext.dashboard.scheduleBars.filter(function (x) { return x.showInLegend; }).map(function (x) { return (React.createElement("div", { class: "d-flex align-items-center gap-1" },
                            React.createElement("div", { className: "p-6", style: { backgroundColor: x.color }, title: x.tooltip }),
                            React.createElement("div", { class: "fs-12 fw-medium width-style" }, x.label))); }))),
                    React.createElement("div", { className: "w-40 mt3 pl2" },
                        React.createElement("h4", { className: "fs-14 fw-semibold ms-3" }, resx.Dashboard_Completion_RequirementsTitle),
                        React.createElement(ReactC3Chart, { axis: {
                                rotated: true,
                                y: { show: false },
                                x: {
                                    show: false,
                                    type: 'category',
                                    categories: this.state.rqsDoneLabels
                                }
                            }, bar: { width: 32 }, data: {
                                colors: this.state.rqsDoneColors,
                                color: function (color, d) {
                                    return d.id && d.id == SpiraContext.dashboard.completions.remaining.label ? null : color;
                                },
                                columns: this.state.rqsDoneToDisplay,
                                groups: this.state.rqsDoneGroups,
                                labels: {
                                    format: (_b = {},
                                        _b[SpiraContext.dashboard.completions.inProgress.label] = function (v, id, i, j) {
                                            return _this.state.childWorkspaces[i].requirementsAll ? v : resx.Global_None;
                                        },
                                        _b[SpiraContext.dashboard.completions.complete.label] = function (v, id, i, j) { return v > 0 ? v : ""; },
                                        _b),
                                },
                                order: null,
                                type: "bar"
                            }, dataSource: this.state.isDisplayingPercent, size: {
                                height: this.state.rqsDoneLabels ? (this.state.rqsDoneLabels.length * 50) : 0
                            }, legend: {
                                show: false,
                            } }),
                        React.createElement("div", { className: "acc-wrapper-11" }, SpiraContext.dashboard.completionBars.filter(function (x) { return x.gaugeThreshold !== undefined; }).map(function (x) { return (React.createElement("div", { class: "d-flex align-items-center gap-1" },
                            React.createElement("div", { className: "p-6", style: { backgroundColor: x.color } }),
                            React.createElement("div", { class: "fs-12 fw-medium width-style" }, x.label))); })))))
            :
                React.createElement("div", { className: "ma4 alert alert-info", role: "alert" }, resx.Global_NoDataToDisplay)));
    };
    return WorkspaceProductCompletion;
}(React.Component));
//# sourceMappingURL=rct_comp_workspaceProductCompletion.js.map