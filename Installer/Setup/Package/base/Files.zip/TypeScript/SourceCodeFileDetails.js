var sourceCodeFileDetails = {
    messageBoxId: '',
    updatePreview: function (branchKey, fileKey) {
        var previewAvailable = false;
        var ajxFormManager = $find(ajxFormManager_id);
        var dataItem = ajxFormManager.get_dataItem();
        var mimeType = dataItem.Fields._MimeType.textValue;
        if (mimeType == 'text/markdown') {
            Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeFileService.SourceCodeFile_OpenMarkdown(SpiraContext.ProjectId, branchKey, fileKey, AspNetAjax$Function.createDelegate(this, this.updatePreviewMarkdown_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
            $('#markdownPreview').show();
            previewAvailable = true;
        }
        else {
            $('#markdownPreview').hide();
        }
        if (mimeType != 'text/markdown' && mimeType.substr(0, 'text'.length) == 'text' || mimeType == 'application/x-rapise' || mimeType == 'application/json' || mimeType == 'application/xml' || mimeType == 'application/x-bat') {
            Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeFileService.SourceCodeFile_OpenText(SpiraContext.ProjectId, branchKey, fileKey, AspNetAjax$Function.createDelegate(this, this.updatePreview_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
            previewAvailable = true;
            $('#codePreview').show();
        }
        else {
            $('#codePreview').hide();
        }
        if (mimeType.substr(0, 'image'.length) == 'image') {
            var url = sourceCodeViewer_urlTemplate.replace('{0}', fileKey).replace('{1}', branchKey);
            previewAvailable = true;
            $('#imagePreview').show();
            $('#imgPreviewHyperLink').attr('href', url);
            $('#imgPreview').attr('src', url);
        }
        else {
            $('#imagePreview').hide();
        }
        if (previewAvailable) {
            $('#noPreview').hide();
        }
        else {
            $('#noPreview').show();
            $('#codePreview').hide();
            $('#imagePreview').hide();
            $('#markdownPreview').hide();
        }
        $find(tabControl_id).updateHasData('tabPreview', previewAvailable);
    },
    updatePreview_success: function (preview, dataItem) {
        var codePreview = $get('codePreview');
        var extension = dataItem.Fields.Name.textValue.split('.').pop();
        syntaxHighlighting.highlightElement(preview, extension, codePreview, true);
    },
    updatePreview_failure: function (ex) {
        $('#noPreview').show();
        $('#codePreview').hide();
        $('#imagePreview').hide();
        $('#markdownPreview').hide();
    },
    updatePreviewMarkdown_success: function (preview, dataItem) {
        var markdownPreview = $get('markdownPreview');
        globalFunctions.clearContent(markdownPreview);
        markdownPreview.innerHTML = preview;
        globalFunctions.cleanHtml(markdownPreview);
    }
};
//# sourceMappingURL=SourceCodeFileDetails.js.map