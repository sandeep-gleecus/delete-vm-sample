var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var followers = {
    domContainerId: 'followersListBox',
    dropMenu: '',
    followerData: new Array,
    followerMeta: {
        projectId: 0,
        artifactTypeId: 0,
        artifactId: 0,
    },
    reactInitiallyRendered: false,
    getFollowersList: function (projectId, artifactTypeId, artifactId) {
        followers.followerMeta.projectId = projectId;
        followers.followerMeta.artifactTypeId = artifactTypeId;
        followers.followerMeta.artifactId = artifactId;
        Inflectra.SpiraTest.Web.Services.Ajax.NotificationService.Notification_FollowersOfArtifact(projectId, artifactTypeId, artifactId, followers.getFollowersList_success, followers.getFollowersList_failure);
    },
    getFollowersList_success: function (res) {
        if (res && res.length > 0) {
            followers.followerData = res;
        }
        if (followers.reactInitiallyRendered) {
            pnlAddFollower_updateFollowers_success(res);
        }
        else {
            ReactDOM.render(React.createElement(FollowerBox, { projectId: SpiraContext.ProjectId, artifactTypeId: SpiraContext.ArtifactTypeId, currentUserId: SpiraContext.CurrentUserId, dropMenu: followers.dropMenu }), document.getElementById(followers.domContainerId));
            followers.reactInitiallyRendered = true;
        }
    },
    getFollowersList_failure: function () {
    },
    seeWhoIsOnline: function (onlineUsers) {
    }
};
var FollowerBox = (function (_super) {
    __extends(FollowerBox, _super);
    function FollowerBox(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            artifactId: SpiraContext.ArtifactId,
            canUnsubscribe: _this.props.dropMenu ? $find(_this.props.dropMenu)._authorizedDropMenuItems : false,
            followers: followers.followerData.length > 0 ? followers.followerData : [],
            lastRemovedUserId: -1,
            maxToShow: 100,
            imEnabled: typeof g_userOnlineStatusManager != "undefined",
            numberAboveFold: 5,
            usersOnline: typeof g_userOnlineStatusManager != "undefined" ? g_userOnlineStatusManager.get_onlineUsers() : null,
            viewUpToMax: false
        };
        _this.toggleShowAll = _this.toggleShowAll.bind(_this);
        _this.sendMessageClick = _this.sendMessageClick.bind(_this);
        _this.removeUserAsFollower = _this.removeUserAsFollower.bind(_this);
        _this.updateListOfFollowers = _this.updateListOfFollowers.bind(_this);
        _this.updateListOfFollowers_success = _this.updateListOfFollowers_success.bind(_this);
        return _this;
    }
    FollowerBox.prototype.componentWillMount = function () {
        var self = this;
        followers.seeWhoIsOnline = function () {
            self.setState({ usersOnline: typeof g_userOnlineStatusManager != "undefined" ? g_userOnlineStatusManager.get_onlineUsers() : null });
        };
        if (this.state.imEnabled)
            g_userOnlineStatusManager.register_callback(followers.seeWhoIsOnline);
        pnlAddFollower_updateFollowers_success = function (data) {
            self.setState({
                followers: data,
                artifactId: SpiraContext.ArtifactId
            });
        };
    };
    FollowerBox.prototype.toggleShowAll = function () {
        this.setState({ viewUpToMax: !this.state.viewUpToMax });
    };
    FollowerBox.prototype.sendMessageClick = function (userId) {
        if (this.state.imEnabled)
            g_userOnlineStatusManager.sendMessageToSpecifiedUser(userId);
    };
    FollowerBox.prototype.removeUserAsFollower = function (userId) {
        this.setState({ lastRemovedUserId: userId });
        Inflectra.SpiraTest.Web.Services.Ajax.NotificationService.Notification_UnsubscribeSelectedUserFromArtifact(this.props.projectId, this.props.artifactTypeId, this.state.artifactId, userId, this.updateListOfFollowers, this.removeUserAsFollower_failure);
    };
    FollowerBox.prototype.updateListOfFollowers = function () {
        Inflectra.SpiraTest.Web.Services.Ajax.NotificationService.Notification_FollowersOfArtifact(this.props.projectId, this.props.artifactTypeId, this.state.artifactId, this.updateListOfFollowers_success, this.updateListOfFollowers_failure);
        if (this.props.currentUserId == this.state.lastRemovedUserId) {
            ArtifactEmail_subscribeChange_UpdateDropMenu($find(this.props.dropMenu));
        }
    };
    FollowerBox.prototype.updateListOfFollowers_success = function (data) {
        this.setState({ followers: data });
    };
    FollowerBox.prototype.updateListOfFollowers_failure = function () {
    };
    FollowerBox.prototype.removeUserAsFollower_failure = function () {
    };
    FollowerBox.prototype.render = function () {
        var self = this, moreThanMaxFollowers = this.state.followers.length > this.state.maxToShow, maxNumberToShow = moreThanMaxFollowers ? this.state.maxToShow : this.state.followers.length, numberBelowFold = maxNumberToShow > this.state.numberAboveFold ? maxNumberToShow - this.state.numberAboveFold : 0, followers = this.state.followers.map(function (item) {
            item.nameAsIcon = item.firstName && item.lastName ? item.firstName[0].toUpperCase() + item.lastName[0].toUpperCase() : "?";
            item.isOnline = self.state.imEnabled ? self.state.usersOnline.indexOf(item.userId) >= 0 : false;
            item.avatarUrl = "".concat(SpiraContext.BaseUrl, "UserAvatar.ashx?userId=").concat(item.userId);
            item.index = self.state.followers.indexOf(item);
            item.showIcon = item.index < self.state.maxToShow && (item.index < self.state.numberAboveFold || self.state.viewUpToMax);
            return item;
        }), avatarNodes = followers.filter(function (item) { return item.showIcon; }).map(function (item) {
            return (React.createElement(AvatarIcon, { hasIcon: item.hasIcon, icon: item.avatarUrl, key: item.userId, name: item.fullName, nameAsIcon: item.nameAsIcon, showIcon: item.showIcon, userId: item.userId, canUnsubscribe: self.state.canUnsubscribe || false, cardWidth: "256", department: item.department, isFollower: true, isOnline: item.isOnline, removeUserAsFollower: self.removeUserAsFollower, sendMessageClick: self.sendMessageClick, showCard: true }));
        });
        var belowFoldText = this.state.viewUpToMax ? resx.Global_ShowLess : resx.Global_ShowAll, belowFoldIcon = this.state.viewUpToMax ? "fas fa-angle-up pl3 u-mini-bounce_up-hover" : "fa fa-angle-down pl3 u-mini-bounce_down-hover", numberCurrentlyShowing = this.state.followers.filter(function (item) { return item.showIcon === true; }).length;
        if (this.state.followers.length) {
            return (React.createElement("div", null,
                React.createElement("div", { className: "clearfix mb3 lh-initial" },
                    React.createElement("span", { className: "mr2" }, resx.Global_Followers),
                    React.createElement("span", { className: "gray fs-90" },
                        "(",
                        numberCurrentlyShowing < maxNumberToShow ? numberCurrentlyShowing + " / " : "",
                        maxNumberToShow,
                        moreThanMaxFollowers ? "+" : null,
                        ")"),
                    numberBelowFold ?
                        React.createElement("div", { className: "silver pointer fr", onClick: this.toggleShowAll },
                            belowFoldText,
                            React.createElement("span", { className: belowFoldIcon }))
                        : null),
                avatarNodes));
        }
        else {
            return null;
        }
    };
    return FollowerBox;
}(React.Component));
function AvatarCard(props) {
    var cardClassesBase = "dib absolute br2 shadow-b-mid-gray mh8 bg-white z-110 bottom-100 mb4", cardClassesRight = "left0 u-triangle-bl-vlight-gray", cardClassesLeft = "right0 u-triangle-br-vlight-gray", cardClassesCenter = "u-triangle-b-vlight-gray", isCenter = props.cardPosition !== "right" && props.cardPosition !== "left", cardClasses = "".concat(cardClassesBase, " ").concat(props.cardPosition === "right" ? cardClassesRight :
        props.cardPosition === "left" ? cardClassesLeft : cardClassesCenter), statusClasses = "dib br2 px3 py1 tc mr2 silver ".concat(props.isOnline ? "fw-b" : ""), messageClasses = "dib br2 silver px3 py1 tc ba b-light-gray ".concat(props.isOnline ? "bg-white pointer" : "pointer"), cardStyle = {
        width: "".concat(props.cardWidth, "px"),
        left: isCenter ? "calc(50% - ".concat((props.cardWidth / 2), "px") : ""
    };
    return (React.createElement("div", { className: cardClasses, style: cardStyle },
        React.createElement("div", { className: "db relative df items-start" },
            props.hasIcon ?
                React.createElement("img", { src: props.icon, alt: props.name, className: "w6 h-auto br2-br br2-tl fl" })
                :
                    React.createElement("div", { className: "w6 h6 br2-br br2-tl fl dit bg-vlight-gray ov-hidden tc" },
                        React.createElement("span", { className: "fs-250 white y-center dib lh0 fw-b" }, props.nameAsIcon)),
            React.createElement("div", { className: "dt mx3 mt3" },
                React.createElement("div", { className: "dtc px2 w7" },
                    React.createElement("span", { className: "fs-h4 fw-b db mb1" }, props.name),
                    React.createElement("span", { className: "fs-h5 silver" }, props.department)),
                props.isFollower ?
                    React.createElement("div", { className: "absolute top0 right0 px4 py3 silver ".concat(props.canUnsubscribe ? " pointer" : ""), "data-placement": "bottom", "data-toggle": "tooltip", onClick: props.canUnsubscribe ? props.removeUserAsFollower.bind(null, props.userId) : null, title: props.canUnsubscribe ? resx.Followers_UnfollowUser : null },
                        React.createElement("span", { className: "fas fa-star" }))
                    :
                        React.createElement("div", { className: "absolute top0 right0 px4 py3 silver ".concat(props.canUnsubscribe ? " pointer" : "") },
                            React.createElement("span", { className: "far fa-star" })))),
        React.createElement("div", { className: "mt5 bg-vlight-gray pa3 tr br2-bottom" },
            React.createElement("div", { className: messageClasses, onClick: props.sendMessageClick.bind(null, props.userId) },
                React.createElement("span", { className: "far fa-comment pr2" }),
                resx.ArtifactType_Message))));
}
//# sourceMappingURL=Followers.js.map