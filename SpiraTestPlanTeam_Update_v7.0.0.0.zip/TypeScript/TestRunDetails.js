Type.registerNamespace('Inflectra.SpiraTest.Web');
Inflectra.SpiraTest.Web.TestRunDetails = function () {
    this._isOverNameDesc = false;
    this._initialBuildLoad = true;
    this._testCaseId = null;
    this._testSetId = null;
    this._testSetTestCaseId = null;
    this._testRunStepsViewModel = null;
    this._incidentsViewModel = null;
    this._testRunStepId = null;
    this._testSetFolders = null;
    this._msgChangeTestSetMessages = $get(msgChangeTestSetMessages_id);
    Inflectra.SpiraTest.Web.TestRunDetails.initializeBase(this);
};
Inflectra.SpiraTest.Web.TestRunDetails.prototype =
    {
        initialize: function () {
            Inflectra.SpiraTest.Web.TestRunDetails.callBaseMethod(this, 'initialize');
        },
        dispose: function () {
            delete this._dialog;
            Inflectra.SpiraTest.Web.TestRunDetails.callBaseMethod(this, 'dispose');
        },
        get_testRunStepId: function () {
            return this._testRunStepId;
        },
        get_testCaseId: function () {
            return this._testCaseId;
        },
        set_testCaseId: function (value) {
            this._testCaseId = value;
        },
        get_testSetId: function () {
            return this._testSetId;
        },
        set_testSetId: function (value) {
            this._testSetId = value;
        },
        get_testSetTestCaseId: function () {
            return this._testSetTestCaseId;
        },
        set_testSetTestCaseId: function (value) {
            this._testSetTestCaseId = value;
        },
        loadTestRunSteps: function () {
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestRunStepService.TestRunStep_Retrieve(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.loadTestRunSteps_success), AspNetAjax$Function.createDelegate(this, this.loadTestRunSteps_failure));
        },
        loadTestRunSteps_success: function (data) {
            globalFunctions.hide_spinner();
            if (data && data.items && data.items.length > 0) {
                var tabControl = $find(tclTestRunDetails_id).updateHasData(pnlOverview_id, true);
                if (this._testRunStepsViewModel) {
                    ko.mapping.fromJS(data, this._testRunStepsViewModel);
                }
                else {
                    this._testRunStepsViewModel = ko.mapping.fromJS(data);
                    ko.applyBindings(this._testRunStepsViewModel, $('#grdTestRunSteps')[0]);
                }
            }
            else {
            }
        },
        loadTestRunSteps_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error($get(lblMessage_id), exception);
        },
        display_incidents: function (testRunStep, evt) {
            if (!testRunStep) {
                return;
            }
            var testRunStepId = testRunStep.primaryKey();
            if (!evt) {
                evt = window.event;
            }
            if (!this._dialog) {
                this._dialog = $find(dlgTestRunStepIncidents_id);
            }
            var artifactPrefix = globalFunctions.getArtifactTypes(globalFunctions.artifactTypeEnum.testRunStep)[0].token;
            var title = resx.TestRunDetails_IncidentList + ' ' + globalFunctions.formatArtifactId(artifactPrefix, testRunStepId);
            this._dialog.set_title(title);
            this._dialog.auto_position(evt);
            this.load_incidents(testRunStepId, null, evt);
        },
        load_incidents: function (testRunStepId, testStepId, evt) {
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.IncidentsService.RetrieveByTestRunStepId(SpiraContext.ProjectId, testRunStepId, testStepId, AspNetAjax$Function.createDelegate(this, this.load_incidents_success), AspNetAjax$Function.createDelegate(this, this.load_incidents_failure), evt);
        },
        load_incidents_success: function (data, evt) {
            globalFunctions.hide_spinner();
            if (this._incidentsViewModel) {
                ko.mapping.fromJS(data, this._incidentsViewModel);
            }
            else {
                this._incidentsViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(this._incidentsViewModel, $('#tblTestRunStepIncidents')[0]);
            }
            this._dialog.display(evt);
        },
        load_incidents_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error($get(lblMessage_id), exception);
        },
        displayIncidentTooltip: function (incidentId) {
            ddrivetip(resx.GlobalFunctions_TooltipLoading);
            this._isOverNameDesc = true;
            Inflectra.SpiraTest.Web.Services.Ajax.IncidentsService.RetrieveNameDesc(SpiraContext.ProjectId, incidentId, null, AspNetAjax$Function.createDelegate(this, this.displayIncidentTooltip_success), AspNetAjax$Function.createDelegate(this, this.displayIncidentTooltip_failure));
        },
        displayIncidentTooltip_success: function (tooltipData) {
            if (this._isOverNameDesc) {
                ddrivetip(tooltipData);
            }
        },
        displayIncidentTooltip_failure: function (exception) {
        },
        hideIncidentTooltip: function () {
            hideddrivetip();
            this._isOverNameDesc = false;
        },
        ddlRelease_selectedItemChanged: function (item) {
            var ajxFormManager = $find(ajxFormManager_id);
            var unsavedChanges = ajxFormManager.get_unsavedChanges();
            if (item.get_value() != '') {
                var releaseId = item.get_value();
                this.updateBuildList(releaseId, unsavedChanges);
            }
        },
        updateBuildList: function (releaseId, unsavedChanges) {
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.BuildService.GetBuildsForRelease(SpiraContext.ProjectId, releaseId, AspNetAjax$Function.createDelegate(this, this.updateBuildList_success), AspNetAjax$Function.createDelegate(this, this.updateBuildList_failure), unsavedChanges);
        },
        updateBuildList_success: function (data, unsavedChanges) {
            var ajxFormManager = $find(ajxFormManager_id);
            var ddlBuild = $find(ddlBuild_id);
            ddlBuild.clearItems();
            ddlBuild.addItem('', '-- ' + resx.Global_None + ' --');
            if (data) {
                ddlBuild.set_dataSource(data);
                ddlBuild.dataBind();
                var dataItem = ajxFormManager.get_dataItem();
                if (dataItem.Fields.BuildId && dataItem.Fields.BuildId.intValue > 0) {
                    ddlBuild.set_selectedItem(dataItem.Fields.BuildId && dataItem.Fields.BuildId.intValue);
                }
                else {
                    ddlBuild.set_selectedItem('');
                }
            }
            if (this._initialBuildLoad) {
                ajxFormManager.update_saveButtons(unsavedChanges);
                this._initialBuildLoad = false;
            }
            globalFunctions.hide_spinner();
        },
        updateBuildList_failure: function (error) {
            var ddlBuild = $find(ddlBuild_id);
            ddlBuild.clearItems();
            ddlBuild.addItem('', '-- ' + resx.Global_None + ' --');
            ddlBuild.set_selectedItem('');
            globalFunctions.hide_spinner();
        },
        display_link_incidents: function (testRunStep, evt) {
            this._testRunStepId = testRunStep.primaryKey();
            var pnlAddAssociation = $find(pnlAddAssociation_id);
            pnlAddAssociation.display(evt);
        },
        execute_test_case: function () {
            var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
            if (this._testSetId && this._testSetTestCaseId) {
                ajxBackgroundProcessManager.display(SpiraContext.ProjectId, 'TestSet_TestCaseExecute', resx.TestCaseList_ExecuteTestCase, resx.TestCaseList_ExecuteTestCaseDesc, this._testSetId, [this._testSetTestCaseId]);
            }
            else {
                ajxBackgroundProcessManager.display(SpiraContext.ProjectId, 'TestCase_Execute', resx.TestCaseList_ExecuteTestCase, resx.TestCaseList_ExecuteTestCaseDesc, this._testCaseId);
            }
        },
        ajxBackgroundProcessManager_success: function (msg, returnCode) {
            if (returnCode && returnCode > 0) {
                var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
                var baseUrl = msg === "testcase_executeexploratory" ? urlTemplate_testRunsPendingExploratory : urlTemplate_testRunsPending;
                var url = baseUrl.replace(globalFunctions.artifactIdToken, returnCode).replace(globalFunctions.projectIdToken, SpiraContext.ProjectId);
                window.location.href = url;
            }
        },
        lnkTestSet_changeClicked: function (evt) {
            if (!this._testSetFolders) {
                globalFunctions.display_spinner();
                Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.RetrieveTestSetFolders(SpiraContext.ProjectId, AspNetAjax$Function.createDelegate(this, this.load_testSetFolders_success), AspNetAjax$Function.createDelegate(this, this.load_testSetFolders_failure));
            }
            var pnlChangeTestSet = $find(pnlChangeTestSet_id);
            pnlChangeTestSet.display(evt);
        },
        load_testSetFolders_success: function (data) {
            globalFunctions.hide_spinner();
            this._testSetFolders = data;
            var ddlTestSetFolders = $find(ddlTestSetFolders_id);
            ddlTestSetFolders.set_dataSource(data);
            ddlTestSetFolders.dataBind();
        },
        load_testSetFolders_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgChangeTestSetMessages, exception);
        },
        ddlTestSetFolders_changed: function (item) {
            var folderId = item.get_value();
            var standardFilters = { TestSetFolderId: globalFunctions.serializeValueInt(folderId) };
            var ajxTestSetSelector = $find(ajxTestSetSelector_id);
            ajxTestSetSelector.set_standardFilters(standardFilters);
            ajxTestSetSelector.load_data();
        },
        pnlChangeTestSet_updateItem: function () {
            var lnkTestSet = $find(lnkTestSet_id);
            var ajxTestSetSelector = $find(ajxTestSetSelector_id);
            var items = ajxTestSetSelector.get_selectedItems();
            var testSetId = null;
            if (items.length > 0) {
                testSetId = items[0];
                var testSetName = ajxTestSetSelector.get_artifactName(testSetId);
                lnkTestSet.update_artifact(testSetId, testSetName, '');
            }
            else {
                lnkTestSet.update_artifact(testSetId, '', '');
            }
            var pnlChangeTestSet = $find(pnlChangeTestSet_id);
            pnlChangeTestSet.close();
        }
    };
//# sourceMappingURL=TestRunDetails.js.map