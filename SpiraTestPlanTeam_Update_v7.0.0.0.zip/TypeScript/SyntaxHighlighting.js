var syntaxHighlighting = {};
syntaxHighlighting = {
    highlightElement: function (code, extension, element, showLineNumbers) {
        var languageName = extension;
        switch (extension.toLowerCase()) {
            case "bash":
            case "sh":
            case "cfm":
            case "cf":
                languageName = "bash";
                break;
            case "bat":
                languageName = "batch";
                break;
            case "cp":
            case "m":
            case "mm":
                languageName = "cpp";
                break;
            case "pas":
                languageName = "delphi";
                break;
            case "erl":
            case "hrl":
                languageName = "erlang";
                break;
            case "gitattributes":
                languageName = "gitignore";
                break;
            case "feature":
                languageName = "gherkin";
                break;
            case "map":
                languageName = "json";
                break;
            case "pl":
                languageName = "perl";
                break;
            case "ps1":
            case "psm1":
            case "psd1":
            case "pssc":
            case "psrc":
                languageName = "powershell";
                break;
            case "tsx":
                languageName = "ts";
                break;
            case "vbnet":
            case "vbs":
                languageName = "vb";
                break;
            case "sstest":
            case "xhtml":
            case "htm":
            case "xslt":
            case "xsd":
            case "xsl":
            case "asax":
            case "ascx":
            case "ashx":
            case "asp":
            case "aspx":
            case "build":
            case "config":
            case "csproj":
            case "resx":
            case "ps1xml":
            case "cdxml":
                languageName = "xml";
                break;
        }
        globalFunctions.clearContent(element);
        var codeElement = document.createElement('code');
        if (code) {
            codeElement.textContent = code;
        }
        else {
            codeElement.innerText = '';
        }
        globalFunctions.cleanHtml(codeElement);
        var preElement = document.createElement('pre');
        preElement.className = "language-".concat(languageName, " ").concat(showLineNumbers ? "line-numbers" : "");
        preElement.setAttribute("style", "white-space: pre-wrap;");
        preElement.appendChild(codeElement);
        element.appendChild(preElement);
        Prism.highlightElement(codeElement);
    }
};
//# sourceMappingURL=SyntaxHighlighting.js.map