var sourceCodeRevisionFileAction = {
    messageBoxId: '',
    branchKey: '',
    fileKey: '',
    revisionKey: '',
    previousRevisionKey: '',
    isUnified: false,
    updatePreview: function (branchKey, fileKey, revisionKey, previousRevisionKey, isUnified) {
        this.branchKey = branchKey;
        this.fileKey = fileKey;
        this.revisionKey = revisionKey;
        this.previousRevisionKey = previousRevisionKey;
        this.isUnified = isUnified;
        var previewAvailable = false;
        if (mimeType == 'text/markdown') {
            Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenMarkdown(SpiraContext.ProjectId, branchKey, fileKey, revisionKey, AspNetAjax$Function.createDelegate(this, this.updatePreviewMarkdown_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), 'markdownPreview');
            $('#markdownPreview').show();
            previewAvailable = true;
        }
        else {
            $('#markdownPreview').hide();
        }
        if (mimeType != 'text/markdown' && mimeType.substr(0, 'text'.length) == 'text' || mimeType == 'application/x-rapise' || mimeType == 'application/json' || mimeType == 'application/xml' || mimeType == 'application/x-bat') {
            Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenText(SpiraContext.ProjectId, branchKey, fileKey, revisionKey, AspNetAjax$Function.createDelegate(this, this.updatePreview_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), 'codePreview');
            previewAvailable = true;
            $('#codePreview').show();
        }
        else {
            $('#codePreview').hide();
        }
        if (mimeType.substr(0, 'image'.length) == 'image') {
            var url = sourceCodeViewer_urlTemplate.replace('{0}', fileKey).replace('{1}', revisionKey).replace('{2}', branchKey);
            previewAvailable = true;
            $('#imagePreview').show();
            $('#imgPreviewHyperLink').attr('href', url);
            $('#imgPreview').attr('src', url);
        }
        else {
            $('#imagePreview').hide();
        }
        if (previewAvailable) {
            $('#noPreview').hide();
        }
        else {
            $('#noPreview').show();
            $('#codePreview').hide();
            $('#imagePreview').hide();
            $('#markdownPreview').hide();
        }
        $find(tabControl_id).updateHasData('tabPreview', previewAvailable);
        if (previousRevisionKey && previousRevisionKey != '') {
            if (mimeType == 'text/markdown') {
                Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenMarkdown(SpiraContext.ProjectId, branchKey, fileKey, previousRevisionKey, AspNetAjax$Function.createDelegate(this, this.updatePreviewMarkdown_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), 'markdownPreviewPrevious');
                $('#markdownPreviewPrevious').show();
                previewAvailable = true;
            }
            else {
                $('#markdownPreviewPrevious').hide();
            }
            if (mimeType != 'text/markdown' && mimeType.substr(0, 'text'.length) == 'text' || mimeType == 'application/x-rapise' || mimeType == 'application/json' || mimeType == 'application/xml' || mimeType == 'application/x-bat') {
                Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenText(SpiraContext.ProjectId, branchKey, fileKey, previousRevisionKey, AspNetAjax$Function.createDelegate(this, this.updatePreview_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), 'codePreviewPrevious');
                previewAvailable = true;
                $('#codePreviewPrevious').show();
            }
            else {
                $('#codePreviewPrevious').hide();
            }
            if (mimeType.substr(0, 'image'.length) == 'image') {
                var url = sourceCodeViewer_urlTemplate.replace('{0}', fileKey).replace('{1}', previousRevisionKey).replace('{2}', branchKey);
                previewAvailable = true;
                $('#imagePreviewPrevious').show();
                $('#imgPreviewPreviousHyperLink').attr('href', url);
                $('#imgPreviewPrevious').attr('src', url);
            }
            else {
                $('#imagePreviewPrevious').hide();
            }
            if (previewAvailable) {
                $('#noPreviewPrevious').hide();
            }
            else {
                $('#noPreviewPrevious').show();
                $('#codePreviewPrevious').hide();
                $('#imagePreviewPrevious').hide();
                $('#markdownPreviewPrevious').hide();
            }
            $find(tabControl_id).updateHasData('tabPreviewPrevious', previewAvailable);
            this.updateChangesView(branchKey, fileKey, revisionKey, previousRevisionKey, isUnified);
        }
    },
    updatePreview_success: function (preview, elementId) {
        var codePreview = $get(elementId);
        var extension = filename.split('.').pop();
        if (elementId == 'codePreviewPrevious') {
            setTimeout(function () { syntaxHighlighting.highlightElement(preview, extension, codePreview, true); }, 1000);
        }
        else {
            syntaxHighlighting.highlightElement(preview, extension, codePreview, true);
        }
    },
    updatePreview_failure: function (ex) {
        $('#noPreview').show();
        $('#codePreview').hide();
        $('#imagePreview').hide();
        $('#markdownPreview').hide();
    },
    updatePreviewMarkdown_success: function (preview, elementId) {
        var markdownPreview = $get(elementId);
        globalFunctions.clearContent(markdownPreview);
        markdownPreview.innerHTML = preview;
        globalFunctions.cleanHtml(markdownPreview);
    },
    updateChangesView: function (branchKey, fileKey, revisionKey, previousRevisionKey, isUnified) {
        this.isUnified = isUnified;
        if (mimeType.substr(0, 'text'.length) == 'text' || mimeType == 'application/x-rapise' || mimeType == 'application/json' || mimeType == 'application/xml' || mimeType == 'application/x-bat') {
            if (isUnified) {
                Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenUnifiedTextDiff(SpiraContext.ProjectId, branchKey, fileKey, revisionKey, previousRevisionKey, AspNetAjax$Function.createDelegate(this, this.updateUnifiedChanges_success), AspNetAjax$Function.createDelegate(this, this.updateChanges_failure));
            }
            else {
                Inflectra.SpiraTest.Web.Services.Ajax.SourceCodeRevisionFileService.SourceCodeFile_OpenSideBySideTextDiff(SpiraContext.ProjectId, branchKey, fileKey, revisionKey, previousRevisionKey, AspNetAjax$Function.createDelegate(this, this.updateSideBySideChanges_success), AspNetAjax$Function.createDelegate(this, this.updateChanges_failure));
            }
        }
        else {
            $('#no-difference').show();
            $('#target-changes').hide();
            $find(tabControl_id).updateHasData('tabChanges', false);
        }
    },
    updateUnifiedChanges_success: function (diffModel) {
        var _this = this;
        var template = document.getElementById('template-unified-changes').innerHTML;
        var totalInserts = 0, totalDeletes = 0, totalChanges = 0, totalLineEdits = 0, percentInserts = 0, percentDeletes = 0, percentChanges = 0, lines = diffModel.lines, COLLAPSE_BUFFER = 3, TYPE_UNCHANGED = "Unchanged", isCollapseLines = diffModel.hasDifferences > 0 && diffModel.lines.length > 32;
        if (diffModel && diffModel.lines.length) {
            totalInserts += diffModel.lines.filter(function (line) { return line.type == "Inserted"; }).length;
            totalDeletes += diffModel.lines.filter(function (line) { return line.type == "Deleted"; }).length;
            totalChanges += diffModel.lines.filter(function (line) { return line.type == "Modified"; }).length;
            totalLineEdits = totalInserts + totalDeletes + totalChanges;
            percentInserts = Math.round((totalInserts / totalLineEdits) * 100);
            percentDeletes = Math.round((totalDeletes / totalLineEdits) * 100);
            percentChanges = Math.round((totalChanges / totalLineEdits) * 100);
            lines = this.setCollapsedLines(isCollapseLines, lines, TYPE_UNCHANGED, COLLAPSE_BUFFER);
        }
        if (totalLineEdits > 0) {
            var view = {
                hasDifferences: diffModel.hasDifferences,
                isCollapseLines: isCollapseLines,
                lines: lines,
                changesTooltip: (totalInserts + " " + resx.SourceCode_Additions + ", " + totalDeletes + " " + resx.SourceCode_Deletions + ", " + totalChanges + " " + resx.SourceCode_Changes).toLowerCase(),
                totalLineEdits: totalLineEdits,
                percentInserts: percentInserts,
                percentDeletes: percentDeletes,
                percentChanges: percentChanges,
                oldRevisionName: resx.Pagination_Previous + " (" + previousRevisionName + ")",
                newRevisionName: resx.Global_Current + " (" + revisionName + ")",
                unifiedTitle: resx.SourceCode_Diff_UnifiedView,
                splitTitle: resx.SourceCode_Diff_SplitView,
                expandTitle: resx.SourceCode_Diff_ExpandTooltip,
                collapseTitle: resx.SourceCode_Diff_CollapseTooltip
            };
            var rendered = Mustache.render(template, view);
            document.getElementById('target-changes').innerHTML = rendered;
            $('#target-changes').show();
            $find(tabControl_id).updateHasData('tabChanges', true);
        }
        else {
            $('#no-difference').show();
            $('#target-changes').hide();
            $find(tabControl_id).updateHasData('tabChanges', false);
        }
        var btnDiffBoxToUnified = document.getElementById("btn-diffBox-to-split");
        if (btnDiffBoxToUnified) {
            btnDiffBoxToUnified.addEventListener("click", function () { return _this.updateChangesView(_this.branchKey, _this.fileKey, _this.revisionKey, _this.previousRevisionKey, false); });
        }
    },
    updateSideBySideChanges_success: function (diffModel) {
        var _this = this;
        var template = document.getElementById('template-sideBySide-changes').innerHTML;
        var combinedLines = null, totalInserts = 0, totalDeletes = 0, totalChanges = 0, totalLineEdits = 0, percentInserts = 0, percentDeletes = 0, percentChanges = 0, lines = diffModel.oldText.lines, COLLAPSE_BUFFER = 3, TYPE_UNCHANGED = "Unchanged", isCollapseLines = diffModel.oldText.hasDifferences > 0 && diffModel.oldText.lines.length > 32;
        if (diffModel.oldText.lines.length) {
            combinedLines = diffModel.oldText.lines.map(function (line, index) {
                var newLine = {
                    type: line.type,
                    oldPosition: line.position,
                    oldType: line.type,
                    oldText: line.text,
                    oldSubPieces: line.subPieces,
                    newPosition: diffModel.newText.lines[index].position,
                    newType: diffModel.newText.lines[index].type,
                    newText: !line.isSummary ? diffModel.newText.lines[index].text : line.text,
                    newSubPieces: diffModel.newText.lines[index].subPieces
                };
                return newLine;
            });
            var lines = this.setCollapsedLines(isCollapseLines, combinedLines, TYPE_UNCHANGED, COLLAPSE_BUFFER, true);
            totalInserts = diffModel.oldText.lines.filter(function (line) { return line.type == "Inserted"; }).length + diffModel.newText.lines.filter(function (line) { return line.type == "Inserted"; }).length;
            totalDeletes = diffModel.oldText.lines.filter(function (line) { return line.type == "Deleted"; }).length + diffModel.newText.lines.filter(function (line) { return line.type == "Deleted"; }).length;
            totalChanges = diffModel.oldText.lines.filter(function (line) { return line.type == "Modified"; }).length + diffModel.newText.lines.filter(function (line) { return line.type == "Modified"; }).length;
            totalLineEdits = totalInserts + totalDeletes + totalChanges;
            percentInserts = Math.round((totalInserts / totalLineEdits) * 100);
            percentDeletes = Math.round((totalDeletes / totalLineEdits) * 100);
            percentChanges = Math.round((totalChanges / totalLineEdits) * 100);
        }
        if (totalLineEdits > 0) {
            var view = {
                hasDifferences: diffModel.oldText.hasDifferences,
                isCollapseLines: isCollapseLines,
                lines: lines,
                changesTooltip: (totalInserts + " " + resx.SourceCode_Additions + ", " + totalDeletes + " " + resx.SourceCode_Deletions + ", " + totalChanges + " " + resx.SourceCode_Changes).toLowerCase(),
                totalLineEdits: totalLineEdits,
                percentInserts: percentInserts,
                percentDeletes: percentDeletes,
                percentChanges: percentChanges,
                oldRevisionName: resx.Pagination_Previous + " (" + previousRevisionName + ")",
                newRevisionName: resx.Global_Current + " (" + revisionName + ")",
                unifiedTitle: resx.SourceCode_Diff_UnifiedView,
                splitTitle: resx.SourceCode_Diff_SplitView,
                expandTitle: resx.SourceCode_Diff_ExpandTooltip,
                collapseTitle: resx.SourceCode_Diff_CollapseTooltip
            };
            var rendered = Mustache.render(template, view);
            document.getElementById('target-changes').innerHTML = rendered;
            $('#target-changes').show();
            $find(tabControl_id).updateHasData('tabChanges', true);
        }
        else {
            $('#no-difference').show();
            $('#target-changes').hide();
            $find(tabControl_id).updateHasData('tabChanges', false);
        }
        var btnDiffBoxToUnified = document.getElementById("btn-diffBox-to-unified");
        if (btnDiffBoxToUnified) {
            btnDiffBoxToUnified.addEventListener("click", function () { return _this.updateChangesView(_this.branchKey, _this.fileKey, _this.revisionKey, _this.previousRevisionKey, true); });
        }
    },
    setCollapsedLines: function (isCollapseLines, lines, TYPE_UNCHANGED, COLLAPSE_BUFFER, isSideBySide) {
        if (!isCollapseLines) {
            return lines;
        }
        else {
            var linesCollapsed = [], summaryLineIndex = 0, showLineCount = 0;
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                if (line.type != TYPE_UNCHANGED) {
                    line.show = true;
                }
                if (!line.show) {
                    for (var backward = 1; backward <= COLLAPSE_BUFFER && i - backward >= 0; backward++) {
                        if (lines[i - backward].type != TYPE_UNCHANGED) {
                            line.show = true;
                            if (backward === COLLAPSE_BUFFER) {
                                line.bufferEnd = true;
                            }
                            break;
                        }
                    }
                }
                if (!line.show) {
                    for (var forward = 1; forward <= COLLAPSE_BUFFER && i + forward < lines.length; forward++) {
                        if (lines[i + forward].type != TYPE_UNCHANGED) {
                            line.show = true;
                            if (forward === COLLAPSE_BUFFER) {
                                line.bufferStart = true;
                            }
                            break;
                        }
                    }
                }
                if (line.show) {
                    showLineCount++;
                    if (line.bufferStart && i > 0 && !lines[i - 1].bufferEnd) {
                        var summaryLine = {
                            isSummary: true,
                            show: true,
                            type: "collapse-summary",
                            oldType: isSideBySide ? "collapse-summary" : null,
                            newType: isSideBySide ? "collapse-summary" : null,
                            text: "@@ +" + (isSideBySide ? line.oldPosition : line.position),
                            oldText: null,
                            newText: null
                        };
                        linesCollapsed.push(summaryLine);
                        summaryLineIndex = linesCollapsed.length - 1;
                        linesCollapsed.push(line);
                    }
                    else {
                        linesCollapsed.push(line);
                    }
                }
                else {
                    if (summaryLineIndex) {
                        var finalText = linesCollapsed[summaryLineIndex].text += "," + showLineCount + " @@";
                        linesCollapsed[summaryLineIndex].text = finalText;
                        linesCollapsed[summaryLineIndex].oldText = finalText;
                        linesCollapsed[summaryLineIndex].newText = finalText;
                        summaryLineIndex = 0;
                    }
                    showLineCount = 0;
                    linesCollapsed.push(line);
                }
            }
            return linesCollapsed;
        }
    },
    updateChanges_failure: function (ex) {
        $('#noChanges').show();
        $('#target-changes').hide();
        $find(tabControl_id).updateHasData('tabChanges', false);
    }
};
//# sourceMappingURL=SourceCodeRevisionFileDetails.js.map