INSERT INTO [TST_PROJECT_COLLECTION] VALUES
	('PullRequests.Filters','Y'),
	('PullRequests.General','Y'),
	('BuildDetails.Commits.Filters','Y'),
	('BuildDetails.Commits.General','Y'),
	('SourceCodeFileDetails.Commits.Filters','Y'),
	('SourceCodeFileDetails.Commits.General','Y'),
	('PullRequest.Commits.Filters','Y'),
	('PullRequest.Commits.General','Y');
