var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var WorkspaceSchedule = (function (_super) {
    __extends(WorkspaceSchedule, _super);
    function WorkspaceSchedule(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            ganttData: null,
            zoomToFit: (_this.props.fullSize) ? false : true
        };
        _this.DEFAULT_WORKSPACE_ID = -1;
        _this.ROOT_ID = _this.props.workspaceType + "-" + _this.props.workspace.workspaceId;
        return _this;
    }
    WorkspaceSchedule.prototype.componentDidMount = function () {
        this.ganttSet();
    };
    WorkspaceSchedule.prototype.getKeyByValue = function (object, value) {
        for (var prop in object) {
            if (object.hasOwnProperty(prop)) {
                if (object[prop] === value)
                    return prop;
            }
        }
    };
    WorkspaceSchedule.prototype.parentTypeIdGet = function (workspaceType) {
        switch (workspaceType) {
            case this.props.workspaceEnums.portfolio:
                return this.props.workspaceEnums.enterprise;
            case this.props.workspaceEnums.program:
                return this.props.workspaceEnums.portfolio;
            case this.props.workspaceEnums.product:
                return this.props.workspaceEnums.program;
            case this.props.workspaceEnums.release:
            case this.props.workspaceEnums.sprint:
                return this.props.workspaceEnums.product;
            case this.props.workspaceEnums.releaseTask:
                return this.props.workspaceEnums.release;
            case this.props.workspaceEnums.sprintTask:
                return this.props.workspaceEnums.sprint;
            default:
                return null;
        }
    };
    WorkspaceSchedule.prototype.ganttSet = function () {
        var _this = this;
        var updatedPortfolios = this.props.portfolios ? this.props.portfolios
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.portfolio); }) : null;
        var updatedPrograms = this.props.programs ? this.props.programs
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.program); }) : null;
        var updatedProducts = this.props.products ? this.props.products
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.product); }) : null;
        var updatedReleases = this.props.releases ? this.props.releases
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.release); }) : null;
        var updatedSprints = this.props.sprints ? this.props.sprints
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.sprint); }) : null;
        var updatedSprintTasks = this.props.sprintTasks ? this.props.sprintTasks
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.sprintTask); }) : null;
        var updatedReleaseTasks = this.props.releaseTasks ? this.props.releaseTasks
            .filter(function (x) { return _this.entryisValid(x); })
            .map(function (x) { return _this.ganttEntryCreate(x, _this.props.workspaceEnums.releaseTask); }) : null;
        var output = [];
        if (updatedPortfolios)
            output.push.apply(output, updatedPortfolios);
        if (updatedPrograms)
            output.push.apply(output, updatedPrograms);
        if (updatedProducts)
            output.push.apply(output, updatedProducts);
        if (updatedReleases)
            output.push.apply(output, updatedReleases);
        if (updatedSprints)
            output.push.apply(output, updatedSprints);
        if (updatedSprintTasks)
            output.push.apply(output, updatedSprintTasks);
        if (updatedReleaseTasks)
            output.push.apply(output, updatedReleaseTasks);
        var ganttData = {
            data: output.map(function (x) {
                var parentIsRoot = x.parent == _this.ROOT_ID;
                var parentInList = output.map(function (y) { return y.id; }).indexOf(x.parent) >= 0;
                if (!parentIsRoot && !parentInList) {
                    x.parent = _this.ROOT_ID;
                }
                return x;
            })
        };
        this.setState({ ganttData: ganttData });
    };
    WorkspaceSchedule.prototype.ganttEntryCreate = function (entry, workspaceEnum) {
        var parentIdToUse = typeof entry.parentId != "undefined" ? entry.parentId : this.DEFAULT_WORKSPACE_ID;
        var parentTypeToUse = !entry.parentIsSameType ? this.parentTypeIdGet(workspaceEnum) : (workspaceEnum === this.props.workspaceEnums.sprint ? this.props.workspaceEnums.release : workspaceEnum);
        var workspaceEnumValue = this.getKeyByValue(this.props.workspaceEnums, workspaceEnum);
        var url = entry.workspaceId > 0 ? globalFunctions.getWorkspaceDefaultUrl(SpiraContext.BaseUrl, workspaceEnum, entry.workspaceId, this.props.productId || null) : "";
        return {
            end_date: globalFunctions.parseJsonDate(entry.endDate),
            iconClass: workspaceEnumValue,
            workspaceEnum: workspaceEnum,
            id: workspaceEnum + "-" + entry.workspaceId,
            parent: parentTypeToUse + "-" + parentIdToUse,
            progress: entry.percentComplete / 100,
            readonly: true,
            start_date: globalFunctions.parseJsonDate(entry.startDate),
            taskBgClass: "bg-" + workspaceEnumValue,
            text: url ? "<a class=\"transition-all\" href=\"".concat(url, "\">").concat(globalFunctions.htmlEncode(entry.workspaceName), "</a>") : globalFunctions.htmlEncode(entry.workspaceName),
        };
    };
    WorkspaceSchedule.prototype.entryisValid = function (entry) {
        if (entry) {
            return entry.startDate && globalFunctions.parseJsonDate(entry.startDate) > 0 && entry.endDate && globalFunctions.parseJsonDate(entry.endDate) > 0;
        }
        else {
            return false;
        }
    };
    WorkspaceSchedule.prototype.render = function () {
        var heightClass = this.props.heightClass || "h10";
        return (React.createElement("div", { className: "gantt-container ".concat(heightClass) }, this.state.ganttData && this.state.ganttData.data && this.state.ganttData.data.length > 0 ?
            React.createElement(ReactGantt, { tasks: this.state.ganttData, isCustomTaskClass: this.props.isCustomTaskClass, isLightboxEnabled: this.props.isLightboxEnabled || false, config: {
                    columns: [
                        { name: "text", label: resx.Global_Workspaces, width: "*", tree: true },
                    ],
                    readonly: this.props.isEditable ? false : true,
                    root_id: this.ROOT_ID,
                    xml_date: "%Y-%m-%d %H:%i",
                }, templates: {
                    task_class: function (start, end, task) { return task.taskBgClass || ""; }
                }, zoomToFit: this.state.zoomToFit })
            :
                React.createElement("div", { className: "ma4 alert alert-info", role: "alert" }, resx.Global_NoDataToDisplay)));
    };
    return WorkspaceSchedule;
}(React.Component));
//# sourceMappingURL=rct_comp_workspaceSchedule.js.map