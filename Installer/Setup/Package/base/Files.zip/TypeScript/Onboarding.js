var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var resx = Inflectra.SpiraTest.Web.GlobalResources;
var OnBoarding = (function (_super) {
    __extends(OnBoarding, _super);
    function OnBoarding(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            seenAppIntro: _this.props.seenAppIntro,
            seenUpdate: _this.props.seenUpdate,
            showTour: false,
            tour: null,
            tourStepTitles: [],
            tourIndex: 0
        };
        _this.handleClose = _this.handleClose.bind(_this);
        _this.tourStart = _this.tourStart.bind(_this);
        _this.tourStop = _this.tourStop.bind(_this);
        _this.tourStopAndClosePanel = _this.tourStopAndClosePanel.bind(_this);
        _this.tourChangeIndex = _this.tourChangeIndex.bind(_this);
        return _this;
    }
    OnBoarding.prototype.handleClose = function (e) {
        globalFunctions.dlgGlobalDynamicClear();
    };
    OnBoarding.prototype.tourStopAndClosePanel = function (tourName) {
        this.tourStop(tourName);
        this.handleClose(null);
    };
    OnBoarding.prototype.tourStop = function (tourName) {
        if (tourName) {
            if (!this.props.toursSeen[tourName]) {
                Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.UserSettings_GuidedTour_SetSeen(tourName);
            }
            this.setState({
                showTour: false,
                seenAppIntro: tourName == "appIntro" ? true : this.state.seenAppIntro,
                seenUpdate: tourName == this.props.updateTourName ? true : this.state.seenUpdate,
                tourIndex: 0
            });
        }
    };
    OnBoarding.prototype.tourStart = function (tourName) {
        var newTour = this.tourGet(tourName);
        this.setState({
            showTour: true,
            tour: newTour,
            tourStepTitles: newTour && newTour.steps.length ? newTour.steps.map(function (x) { return x.title; }) : []
        });
    };
    OnBoarding.prototype.tourGet = function (name) {
        var tourIndex = this.props.tours.map(function (x) { return x.name; }).indexOf(name);
        if (tourIndex >= 0) {
            var newTour = this.props.tours[tourIndex];
            var userIsAdmin = !globalFunctions.objectIsEmpty(SpiraContext.Navigation.adminNavigation);
            var newTourFilterAdmin = userIsAdmin ? newTour : this.tourStripAdminOnlySteps(newTour);
            var newTourFilterAdminAndTours = this.tourStripSeenTours(newTourFilterAdmin);
            return newTourFilterAdminAndTours;
        }
        else {
            return null;
        }
    };
    OnBoarding.prototype.tourStripAdminOnlySteps = function (tour) {
        var filteredSteps = tour.steps.filter(function (x) { return !x.isAdmin; });
        var newTour = tour;
        newTour.steps = filteredSteps;
        return newTour;
    };
    OnBoarding.prototype.tourStripSeenTours = function (tour) {
        var _this = this;
        var tourLinkToTours = tour.steps.filter(function (x) { return x.linkToTour; });
        if (tourLinkToTours) {
            var filteredSteps = tour.steps.filter(function (x) {
                if (!x.linkToTour) {
                    return x;
                }
                else if (!_this.props.toursSeen[x.linkToTour]) {
                    return x;
                }
            });
            var newTour = tour;
            newTour.steps = filteredSteps;
            return newTour;
        }
        else {
            return tour;
        }
    };
    OnBoarding.prototype.tourChangeIndex = function (newIndex) {
        if (newIndex >= 0 && newIndex < this.state.tour.steps.length && newIndex !== this.state.tourIndex) {
            var newIndexLinkToTour_1 = this.state.tour.steps[newIndex].linkToTour;
            if (newIndexLinkToTour_1) {
                var newTour = this.props.tours.filter(function (x) { return x.name == newIndexLinkToTour_1; });
                if (newTour && newTour.length) {
                    this.tourStop(this.state.tour.name);
                    this.tourStart(newIndexLinkToTour_1);
                }
            }
            else {
                this.setState({ tourIndex: newIndex });
            }
        }
    };
    OnBoarding.prototype.render = function () {
        var _a = this.state, seenAppIntro = _a.seenAppIntro, seenUpdate = _a.seenUpdate, showTour = _a.showTour, tour = _a.tour, tourIndex = _a.tourIndex, tourStepTitles = _a.tourStepTitles;
        var shouldShowUpdate = !seenUpdate && this.tourGet(this.props.updateTourName);
        return (null);
    };
    return OnBoarding;
}(React.Component));
//# sourceMappingURL=Onboarding.js.map