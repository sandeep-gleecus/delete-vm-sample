var ReactGrid = function (props) {
    var visibleColumns = props.meta.filter(function (x) { return !x.hidden; });
    var headerCells = visibleColumns.map(function (x, i) { return React.createElement("th", { key: i }, x.name); });
    var rows = props.data.map(function (row, index) {
        var dataCells = [];
        visibleColumns.forEach(function (col) {
            if (!col.hidden) {
                var cellContents;
                if (col.type) {
                    switch (col.type) {
                        case 'dropdown':
                            cellContents = col.dropdown.filter(function (item) { return item.id == row[col.ref]; })[0].name;
                            break;
                        case 'icon':
                            cellContents = React.createElement("img", { src: "row[col.ref]", className: "w4 h4" });
                            break;
                        default:
                            cellContents = row[col.ref];
                    }
                }
                else {
                    cellContents = row[col.ref];
                }
                dataCells.push(React.createElement("td", { key: col.ref }, cellContents));
            }
        });
        return (React.createElement("tr", { key: index }, dataCells));
    });
    return (React.createElement("div", { className: "table-responsive" },
        React.createElement("table", { className: "table table-condensed" },
            React.createElement("thead", null,
                React.createElement("tr", null, headerCells)),
            React.createElement("tbody", null, rows))));
};
//# sourceMappingURL=rct_comp_grid.js.map