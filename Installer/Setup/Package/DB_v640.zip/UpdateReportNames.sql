UPDATE tst_report_format SET name = 'MS-Word (legacy)', description = 'Format that will open in MS-Word versions 2013 or earlier' WHERE token = 'MsWord2003'
GO

UPDATE tst_report_format SET name = 'MS-Excel (data)', description = 'Format optimized for data manipulation' WHERE token = 'MsExcel2003'
GO

UPDATE tst_report_format SET name = 'MS-Word', description = 'Format that will open in MS-Word versions 2015 or later' WHERE token = 'MsWord2007'
GO

UPDATE tst_report_format SET name = 'MS-Excel (printable)', description = 'Format that is optimized for printing and includes rich text formatting' WHERE token = 'MsExcel2007'
GO

