/***************************************************************
**	Insert script for table TST_RELEASE_TYPE_WORKFLOW
***************************************************************/
INSERT INTO TST_RELEASE_TYPE_WORKFLOW
(
RELEASE_TYPE_ID, RELEASE_WORKFLOW_ID, PROJECT_TEMPLATE_ID
)
VALUES
(
1, 1, 1
),
(
2, 1, 1
),
(
3, 1, 1
),
(
4, 1, 1
),
(
1, 2, 2
),
(
2, 2, 2
),
(
3, 2, 2
),
(
4, 2, 2
),
(
1, 3, 3
),
(
2, 3, 3
),
(
3, 3, 3
),
(
4, 3, 3
),
(
1, 4, 4
),
(
2, 4, 4
),
(
3, 4, 4
),
(
4, 4, 4
)
GO

