var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var LandScreenNavigation = (function (_super) {
    __extends(LandScreenNavigation, _super);
    function LandScreenNavigation(props) {
        var _a;
        var _this = _super.call(this, props) || this;
        _this.enum = {
            workspaceAdminClasses: "mx2 fs-66 o-50 v-super",
            urlType: {
                workspace: "workspaceUrl",
                artifact: "artifactUrl"
            },
            searchStorage: "searchHistory",
            searchHistoryMax: 10,
        };
        _this.supportsCssVars = typeof CSS != "undefined" && CSS.supports('color', 'var(--fake-var)');
        _this.state = {
            workspaceDefaultText: resx.Global_ChooseWorkspace,
            workspaceList: [],
            workspaceListIsOpen: false,
            workspaceHidden: [],
            workspaceCurrent: "",
            workspaceCurrentId: "",
            workspaceLoading: false,
            artifactList: [],
            artifactListIsOpen: false,
            artifactHidden: [],
            artifactParent: {},
            userIcon: {},
            userList: [],
            userColorScheme: "auto",
            myPageLoading: false,
            reportsButton: null,
            reportsLoading: false,
            searchHistory: [],
            searchTerm: "",
            searchIsOpen: false,
            adminMenuShow: false,
            adminMenuPosition: "global-nav",
            spinnerShow: 0,
            navMobileIsOpen: false,
        };
        _this.workspaceDrop = React.createRef();
        _this.artifactDrop = React.createRef();
        _this.userDrop = React.createRef();
        _this.handleOpenLink = _this.handleOpenLink.bind(_this);
        _this.kbCodes = {
            codes: (_a = {
                    showGlossary: { term: "?" }
                },
                _a[globalFunctions.artifactTypeEnum.requirement] = { term: "n r q" },
                _a[globalFunctions.artifactTypeEnum.planningBoard] = { term: "n p b" },
                _a[globalFunctions.artifactTypeEnum.programPlanningBoard] = { term: "n p b" },
                _a[globalFunctions.artifactTypeEnum.release] = { term: "n r l" },
                _a[globalFunctions.artifactTypeEnum.programReleases] = { term: "n r l" },
                _a[globalFunctions.artifactTypeEnum.document] = { term: "n d c" },
                _a[globalFunctions.artifactTypeEnum.testCase] = { term: "n t c" },
                _a[globalFunctions.artifactTypeEnum.testSet] = { term: "n t s" },
                _a[globalFunctions.artifactTypeEnum.testRun] = { term: "n t r" },
                _a[globalFunctions.artifactTypeEnum.automationHost] = { term: "n a h" },
                _a[globalFunctions.artifactTypeEnum.testConfigurationSet] = { term: "n t n" },
                _a[globalFunctions.artifactTypeEnum.incident] = { term: "n i n" },
                _a[globalFunctions.artifactTypeEnum.programIncidents] = { term: "n i n" },
                _a[globalFunctions.artifactTypeEnum.task] = { term: "n t k" },
                _a[globalFunctions.artifactTypeEnum.risk] = { term: "n r k" },
                _a[globalFunctions.artifactTypeEnum.resource] = { term: "n u s" },
                _a[globalFunctions.artifactTypeEnum.sourceCode] = { term: "n s c" },
                _a[globalFunctions.artifactTypeEnum.sourceCodeRevisions] = { term: "n c o" },
                _a[globalFunctions.artifactTypeEnum.pullRequests] = { term: "n p r" },
                _a)
        };
        return _this;
    }
    LandScreenNavigation.prototype.componentWillMount = function () {
    };
    LandScreenNavigation.prototype.workspaceUrl = function () {
        var _this = this;
        if (this.state.workspaceCurrent && this.state.workspaceList.length) {
            var filteredWorkspaces = this.state.workspaceList.filter(function (x) { return x.listId == _this.state.workspaceCurrent; });
            if (filteredWorkspaces.length) {
                return filteredWorkspaces[0].workspaceUrl;
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    };
    LandScreenNavigation.prototype.handleOpenLink = function (name, url, evt) {
        var _a;
        if (evt.ctrlKey || evt.which === 2) {
            window.open(url, '_blank');
        }
        else {
            window.location.assign(url);
            this.setState((_a = {}, _a[name] = true, _a));
        }
    };
    LandScreenNavigation.prototype.render = function () {
        var _a = this.state, adminShow = _a.adminShow, artifactList = _a.artifactList, artifactParent = _a.artifactParent, currentLocation = _a.currentLocation, reportsButton = _a.reportsButton, searchHistory = _a.searchHistory, searchTerm = _a.searchTerm, spinnerShow = _a.spinnerShow, userIcon = _a.userIcon, userList = _a.userList, workspaceCurrent = _a.workspaceCurrent, workspaceList = _a.workspaceList;
        var loaderIcon = React.createElement("div", { className: "lds-ellipsis" },
            React.createElement("div", null),
            React.createElement("div", null),
            React.createElement("div", null),
            React.createElement("div", null));
        var productIcon = React.createElement("img", { alt: this.props.product, className: "nav-home-logo mh-100 mw5", src: this.props.baseThemeUrl + "NewImages/VM Studio large logo-color 1.svg" });
        var workspaceTitle = artifactParent.name;
        var workspaceIcon = React.createElement("img", { alt: workspaceTitle, className: "navbar-brand d-flex align-items-center  pe-2  me-3", src: this.props.baseThemeUrl + "NewImages/VM Studio large logo-color 1.svg" });
        var mainListClasses = "fw2 cf nav-top-list nav-top-list-";
        return (React.createElement("nav", { className: "nav-top pt-3 px-3 nav-fixed mw-100 z-999", "aria-label": "Offcanvas navbar large" },
            React.createElement("div", { class: "container-fluid " },
                React.createElement("a", { class: "navbar-brand d-flex align-items-center flex-grow-1 flex-lg-grow-0 p-0 me-4", href: "/ValidationMaster/LandingScreen.aspx" },
                    React.createElement("img", { src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/VM Studio large logo-color 1.svg", class: "pe-2", alt: "Validation Master logo" }),
                    React.createElement("span", { class: "fs-14 border-start ps-2 d-none d-md-block" }, "Studio")),
                React.createElement("div", { class: "dropdown nav-item flex-shrink-0 profile" },
                    React.createElement("a", { href: "#", class: "d-flex align-items-start gap-md-2 link-body-emphasis text-decoration-none justify-content-end dropdown-toggle", "data-bs-toggle": "dropdown", "aria-expanded": "false" },
                        React.createElement("img", { src: "https://github.com/mdo.png", alt: "mdo", width: "36", height: "36", class: "border border-grey rounded-3" }),
                        React.createElement("p", { class: "mb-0 fs-14 fw-bold d-none d-md-block" },
                            "System Administrator",
                            React.createElement("span", { class: "d-block fs-12 vm-midgrey-7 fw-normal" }, "Product Owner"))),
                    React.createElement("ul", { class: "dropdown-menu dropdown-menu-end text-small py-0" },
                        React.createElement("li", null,
                            React.createElement("a", { class: "dropdown-item p-2", href: "/ValidationMaster/MyProfile.aspx" },
                                React.createElement("img", { class: "image pe-2", src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/profile.svg", alt: "profile icon" }),
                                "Profile")),
                        React.createElement("li", null,
                            React.createElement("a", { class: "dropdown-item p-2", href: "#" },
                                React.createElement("img", { class: "image pe-2", src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/settings.svg", alt: "settings icon" }),
                                "Admin settings")),
                        React.createElement("li", null,
                            React.createElement("a", { class: "dropdown-item p-2", href: "/ValidationMaster/Logout.aspx" },
                                React.createElement("img", { class: "image pe-2", src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/logout.svg", alt: "logout icon" }),
                                "Logout")))))));
    };
    return LandScreenNavigation;
}(React.Component));
function landNavLoadTry() {
    console.log(SpiraContext);
    if (typeof SpiraContext == 'undefined') {
        setTimeout(function () { return landNavLoadTry(); }, 100);
    }
    else if (!document.getElementById('land-navigation')) {
        window.requestAnimationFrame(landNavLoadTry);
    }
    else {
        ReactDOM.render(React.createElement(LandScreenNavigation, { data: SpiraContext.Navigation, baseThemeUrl: SpiraContext.BaseThemeUrl, baseUrl: SpiraContext.BaseUrl, isGroupAdmin: SpiraContext.IsGroupAdmin, isPortfolioEnabled: SpiraContext.Features.portfolios, isPortfolioViewer: SpiraContext.IsPortfolioAdmin, isEnterpriseViewer: SpiraContext.IsPortfolioAdmin, isProjectAdmin: SpiraContext.IsProjectAdmin, isSysAdmin: SpiraContext.IsSystemAdmin, isReportAdmin: SpiraContext.isReportAdmin, projectGroupId: SpiraContext.ProjectGroupId, projectId: SpiraContext.ProjectId, product: SpiraContext.ProductType, ref: function (rct_comp_globalNav) { window.rct_comp_globalNav = rct_comp_globalNav; }, workspaceEnums: SpiraContext.WorkspaceEnums, workspaceType: SpiraContext.WorkspaceType }), document.getElementById('land-navigation'));
    }
}
;
landNavLoadTry();
//# sourceMappingURL=LandScreenNavigation.js.map