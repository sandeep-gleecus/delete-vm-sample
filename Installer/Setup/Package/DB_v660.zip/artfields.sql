INSERT INTO [tst_artifact_field]
	([artifact_type_id],[name],[lookup_property],[caption],[artifact_field_type_id],[is_workflow_config],[is_list_config],[is_list_default],[list_default_position],[is_active],[is_data_mapping],[is_report],[is_notify],[is_history_recorded],[description]) VALUES
	(4,'PlannedPoints',NULL,'Planned Points',13,1,1,0,24,1,0,1,1,1,'The planned story points');