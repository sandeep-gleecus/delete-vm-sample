/***************************************************************
**	Insert script for table TST_PRODUCT_TYPE
***************************************************************/
INSERT INTO TST_PRODUCT_TYPE
(
NAME, PRODUCT_LICENSE_NUMBER, ACTIVE_YN
)
VALUES
(
'SpiraTest', 1, 'N'
),
(
'SpiraPlan', 2, 'N'
),
(
'SpiraTeam', 3, 'N'
),
(
'ValidationMaster', 4, 'Y'
)
GO

