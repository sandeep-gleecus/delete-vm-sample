/***************************************************************
**	Insert script for table TST_TEST_CASE_TYPE
***************************************************************/
SET IDENTITY_INSERT TST_TEST_CASE_TYPE ON; 

INSERT INTO TST_TEST_CASE_TYPE
(
TEST_CASE_TYPE_ID, PROJECT_TEMPLATE_ID, TEST_CASE_WORKFLOW_ID, NAME, IS_ACTIVE, POSITION, IS_DEFAULT, IS_EXPLORATORY, IS_BDD
)
VALUES
(
1, 1, 1, 'Acceptance', 1, 1, 0, 0, 1
),
(
2, 1, 1, 'Compatibility', 1, 2, 0, 0, 0
),
(
3, 1, 1, 'Functional', 1, 4, 1, 0, 0
),
(
4, 1, 1, 'Integration', 1, 5, 0, 0, 0
),
(
5, 1, 1, 'Load/Performance', 1, 6, 0, 0, 0
),
(
6, 1, 1, 'Network', 1, 7, 0, 0, 0
),
(
7, 1, 1, 'Regression', 1, 8, 0, 0, 0
),
(
8, 1, 1, 'Scenario', 1, 9, 0, 0, 0
),
(
9, 1, 1, 'Security', 1, 10, 0, 0, 0
),
(
10, 1, 1, 'Unit', 1, 11, 0, 0, 0
),
(
11, 1, 1, 'Usability', 1, 12, 0, 0, 0
),
(
12, 1, 1, 'Exploratory', 1, 3, 0, 1, 0
),
(
13, 2, 2, 'Acceptance', 1, 1, 0, 0, 1
),
(
14, 2, 2, 'Compatibility', 1, 2, 0, 0, 0
),
(
15, 2, 2, 'Functional', 1, 4, 1, 0, 0
),
(
16, 2, 2, 'Integration', 1, 5, 0, 0, 0
),
(
17, 2, 2, 'Load/Performance', 1, 6, 0, 0, 0
),
(
18, 2, 2, 'Network', 1, 7, 0, 0, 0
),
(
19, 2, 2, 'Regression', 1, 8, 0, 0, 0
),
(
20, 2, 2, 'Scenario', 1, 9, 0, 0, 0
),
(
21, 2, 2, 'Security', 1, 10, 0, 0, 0
),
(
22, 2, 2, 'Unit', 1, 11, 0, 0, 0
),
(
23, 2, 2, 'Usability', 1, 12, 0, 0, 0
),
(
24, 2, 2, 'Exploratory', 1, 3, 0, 1, 0
),
(
25, 3, 3, 'Acceptance', 1, 1, 0, 0, 0
),
(
26, 3, 3, 'Compatibility', 1, 2, 0, 0, 0
),
(
27, 3, 3, 'Functional', 1, 4, 1, 0, 0
),
(
28, 3, 3, 'Integration', 1, 5, 0, 0, 0
),
(
29, 3, 3, 'Load/Performance', 1, 6, 0, 0, 0
),
(
30, 3, 3, 'Network', 1, 7, 0, 0, 0
),
(
31, 3, 3, 'Regression', 1, 8, 0, 0, 0
),
(
32, 3, 3, 'Scenario', 1, 9, 0, 0, 0
),
(
33, 3, 3, 'Security', 1, 10, 0, 0, 0
),
(
34, 3, 3, 'Unit', 1, 11, 0, 0, 0
),
(
35, 3, 3, 'Usability', 1, 12, 0, 0, 0
),
(
36, 3, 3, 'Exploratory', 1, 3, 0, 1, 0
),
(
37, 4, 4, 'Acceptance', 1, 1, 0, 0, 0
),
(
38, 4, 4, 'Compatibility', 1, 2, 0, 0, 0
),
(
39, 4, 4, 'Functional', 1, 4, 1, 0, 0
),
(
40, 4, 4, 'Integration', 1, 5, 0, 0, 0
),
(
41, 4, 4, 'Load/Performance', 1, 6, 0, 0, 0
),
(
42, 4, 4, 'Network', 1, 7, 0, 0, 0
),
(
43, 4, 4, 'Regression', 1, 8, 0, 0, 0
),
(
44, 4, 4, 'Scenario', 1, 9, 0, 0, 0
),
(
45, 4, 4, 'Security', 1, 10, 0, 0, 0
),
(
46, 4, 4, 'Unit', 1, 11, 0, 0, 0
),
(
47, 4, 4, 'Usability', 1, 12, 0, 0, 0
),
(
48, 4, 4, 'Exploratory', 1, 3, 0, 1, 0
)
GO

SET IDENTITY_INSERT TST_TEST_CASE_TYPE OFF; 

