/***************************************************************
**	Insert script for table TST_TEST_SET_TEST_CASE
***************************************************************/
SET IDENTITY_INSERT TST_TEST_SET_TEST_CASE ON; 

INSERT INTO TST_TEST_SET_TEST_CASE
(
TEST_SET_TEST_CASE_ID, TEST_SET_ID, TEST_CASE_ID, POSITION, OWNER_ID, PLANNED_DATE, IS_SETUP_TEARDOWN
)
VALUES
(
1, 1, 2, 1, NULL, NULL, 0
),
(
2, 1, 3, 2, NULL, NULL, 0
),
(
3, 1, 4, 3, NULL, NULL, 0
),
(
4, 1, 5, 4, NULL, NULL, 0
),
(
5, 1, 6, 5, NULL, NULL, 0
),
(
6, 1, 8, 6, NULL, NULL, 0
),
(
7, 1, 9, 7, NULL, NULL, 0
),
(
8, 2, 2, 3, NULL, NULL, 0
),
(
9, 2, 3, 4, NULL, NULL, 0
),
(
10, 2, 4, 5, NULL, NULL, 0
),
(
11, 2, 5, 6, NULL, NULL, 0
),
(
12, 2, 6, 7, NULL, NULL, 0
),
(
13, 2, 8, 8, NULL, NULL, 0
),
(
14, 2, 9, 9, NULL, NULL, 0
),
(
15, 2, 12, 1, NULL, NULL, 0
),
(
16, 2, 13, 2, NULL, NULL, 0
),
(
17, 3, 8, 1, NULL, NULL, 0
),
(
18, 3, 9, 2, 3, NULL, 0
),
(
19, 4, 8, 1, 2, NULL, 0
),
(
20, 4, 9, 2, 3, NULL, 0
),
(
21, 5, 4, 1, NULL, NULL, 0
),
(
22, 5, 6, 2, NULL, NULL, 0
),
(
23, 5, 12, 3, NULL, NULL, 0
),
(
24, 5, 13, 4, NULL, NULL, 0
),
(
25, 6, 12, 1, NULL, NULL, 0
),
(
26, 6, 13, 2, NULL, NULL, 0
),
(
28, 3, 8, 3, NULL, NULL, 0
),
(
29, 3, 9, 4, 3, NULL, 0
),
(
30, 4, 8, 3, 2, NULL, 0
),
(
31, 4, 9, 4, 3, NULL, 0
)
GO

SET IDENTITY_INSERT TST_TEST_SET_TEST_CASE OFF; 

