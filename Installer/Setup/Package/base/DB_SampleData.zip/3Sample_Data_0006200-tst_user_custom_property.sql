/***************************************************************
**	Insert script for table TST_USER_CUSTOM_PROPERTY
***************************************************************/
INSERT INTO TST_USER_CUSTOM_PROPERTY
(
CUSTOM_PROPERTY_ID, PROJECT_ID, USER_ID, IS_VISIBLE, LIST_POSITION
)
VALUES
(
7, 1, 2, 1, 20
),
(
2, 1, 2, 1, NULL
),
(
10, 1, 2, 1, NULL
),
(
11, 1, 2, 1, NULL
),
(
17, 1, 2, 1, NULL
),
(
18, 1, 2, 1, NULL
),
(
17, 1, 1, 1, NULL
),
(
18, 1, 1, 1, NULL
)
GO

