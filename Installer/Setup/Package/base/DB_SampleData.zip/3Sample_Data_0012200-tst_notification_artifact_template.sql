/***************************************************************
**	Insert script for table TST_NOTIFICATION_ARTIFACT_TEMPLATE
***************************************************************/
SET IDENTITY_INSERT TST_NOTIFICATION_ARTIFACT_TEMPLATE ON; 

INSERT INTO TST_NOTIFICATION_ARTIFACT_TEMPLATE
(
NOTIFICATION_TEMPLATE_ID, ARTIFACT_TYPE_ID, PROJECT_TEMPLATE_ID, TEMPLATE_TEXT
)
VALUES
(
8, 1, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A Requirement has changed</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Requirement:</span> ${Name} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >ID:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${ID#}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Importance:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Importance}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Type:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${RequirementType}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Status:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${RequirementStatus}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Component:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Component}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Requirement''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
),
(
9, 2, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A Test Case has changed</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Test Case:</span> ${Name} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Test Case:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${ID#}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Last Execution:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${ExecutionStatus} on ${ExecutionDate}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Priority:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${TestCasePriority}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Test Case''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
),
(
10, 3, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >An Incident has changed</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Incident:</span> ${Name} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >ID:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${ID#}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Status:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${IncidentStatus}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Type:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${IncidentType}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Priority:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Priority}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Severity:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Severity}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Incident''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
),
(
11, 6, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A task has been updated</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Task:</span> ${Name} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >ID:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${ID#}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Status:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${TaskStatus}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Type:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${TaskType}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Priority:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${TaskPriority}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Release:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Release}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Task''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
),
(
12, 8, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" > 	
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" > 
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A Test Set has changed</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Test Set:</span> ${Name} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Owner:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Owner}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Last Execution:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${TestSetStatus} on ${ExecutionDate}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" ><br>Description:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:13px;" >Comments:</td>
<td class="longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;" >${Comments}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Test Set''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>'
),
(
13, 13, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;" >
<div class="body" style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:100% !important;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;padding-bottom:24px;font-size:13px;line-height:19px;" >
<table class="container" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:550px;max-width:95%;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;" >
<table class="header" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;background-color:#f3f3f3;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="title accent" style="padding-left:16px;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;" >
<h1 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:24px;" >${Product}</h1>
</td>
<td class="subtitle gray" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:#777;vertical-align:middle;padding-left:10px;" >
<h5 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;margin-bottom:4px;Margin-bottom:4px;font-size:15px;font-weight:bold;" >A Document has changed</h5>
</td>
</tr>
</tbody>
</table>
<div class="message" style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;box-sizing:border-box;background-color:#fefefe;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;text-align:inherit;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;border-radius:7px;border-width:1px;border-style:solid;border-color:#e5e5e5;" >
<h4 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:18px;" ><span class="gray" style="color:#777;" >Document:</span> ${Filename} in product "${ProjectName}"</h4>
<table class="details" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;margin-top:16px;margin-bottom:16px;margin-right:0px;margin-left:0px;Margin:16px 0px;" >
<tbody>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Description:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Description}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Author:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Author}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Current Version:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${CurrentVersion}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >Tags:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${Tags}</td>
</tr>
<tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" >
<td class="label" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;text-align:right;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;" >URL:</td>
<td class="info" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family:Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle;" >${URL}</td>
</tr>
</tbody>
</table>
<h6 class="gray" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family:Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;" >Please log into ${Product} to view this Documents''s details.</h6>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>
'
),
(
14, 1, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Requirement ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Component:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Component}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Importance:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Importance}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
15, 2, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Case ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ExecutionStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCasePriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
16, 3, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            ${IncidentType} ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${IncidentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Priority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Severity:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Severity}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
17, 6, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Task ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskPriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
18, 8, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Set ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestSetStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
19, 13, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Document ${ID#} "${Filename}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Author:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Author}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Editor:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Editor}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
20, 14, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Risk ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Exposure:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskExposure}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
21, 14, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Risk ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Exposure:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskExposure}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
22, 13, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Document ${ID#} "${Filename}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Author:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Author}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Editor:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Editor}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
23, 3, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            ${IncidentType} ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${IncidentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Priority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Severity:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Severity}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
24, 1, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Requirement ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Component:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Component}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Importance:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Importance}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
25, 6, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Task ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskPriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
26, 2, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Case ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ExecutionStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCasePriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
27, 8, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Set ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestSetStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
28, 14, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Risk ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Exposure:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskExposure}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
29, 13, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Document ${ID#} "${Filename}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${DocumentType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Author:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Author}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Editor:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Editor}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
30, 3, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            ${IncidentType} ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${IncidentStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Priority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Severity:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Severity}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
31, 1, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Requirement ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RequirementType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Component:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Component}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Importance:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Importance}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
32, 6, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Task ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TaskPriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Latest Comment:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments:last}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
33, 2, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Case ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ExecutionStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Priority:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestCasePriority}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
34, 8, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Test Set ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Last Execution:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${TestSetStatus} (${ExecutionDate})
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
35, 14, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Risk ${ID#} "${Name}"</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Exposure:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${RiskExposure}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Release:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Release}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>'
),
(
37, 4, 1, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Release ${VersionNumber} "${Name}" [RL:${ID#}]</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Start Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${StartDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                End Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${EndDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
'
),
(
38, 4, 2, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Release ${VersionNumber} "${Name}" [RL:${ID#}]</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Start Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${StartDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                End Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${EndDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
'
),
(
39, 4, 3, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Release ${VersionNumber} "${Name}" [RL:${ID#}]</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Start Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${StartDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                End Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${EndDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
'
),
(
40, 4, 4, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="min-height:100%;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="format-detection" content="telephone=no"> 
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta name="x-apple-disable-message-reformatting" />
<style>
    @media only screen and (max-device-width: 480px) { #body,#container,#longfield-comments,#longfield-description {max-width:480px;}}
    img {display:none;}
</style>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"
    style="height:100% !important;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:100% !important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:19px;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
    <div id="body"
        style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;padding-top:0;padding-right:0;padding-left:0;height:100% !important;width:768px;padding-bottom:24px;font-size:13px;line-height:19px;max-width:100vw;display:inline;">
        <table id="container"
            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;height:100%;width:768px;max-width:100vw;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;Margin:0 auto;">
            <tbody>
                <tr style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                    <td
                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:16px;padding-right:16px;padding-left:16px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;">
                        <table class="header"
                            style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse !important;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;width:100%;margin-top:10px;margin-bottom:10px;margin-right:auto;margin-left:auto;Margin:10px auto;text-align:inherit;box-sizing:border-box;">
                            <tbody>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="title accent"
                                        style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;color:rgb(244, 101, 21);width:0;">
                                        <h2
                                            style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:20px;font-weight:200;">
                                            ${Product} Notification in ${ProjectName}:</h2>
                                        <h1
                                            style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;color:inherit;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:16px;">
                                            Release ${VersionNumber} "${Name}" [RL:${ID#}]</h1>
                                        <h6 class="gray" style="padding-top:8px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:rgb(180,180,180);">
                                            View in full (inc any images) at ${URL}</h6>
        
                                    </td>
                                </tr>
                                <tr
                                style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;" class="fields">
                                    <td style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:16px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;width:0;">
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Status:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseStatus}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Type:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${ReleaseType}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Start Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${StartDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                End Date:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${EndDate}
                                            </span>
                                        </div>
                                        <div style="float:left;">
                                            <label style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;width: 75px;">
                                                Owner:
                                            </label>
                                            <span style="float:left;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-top:0;padding-bottom:0;padding-right:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;padding-left:10px;line-height:200%;vertical-align:middle; width: 150px;">
                                                ${Owner}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0px;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:13px;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;font-size:18px;font-weight:200;border-bottom:4px solid rgb(230, 230, 230);">
                                        Description:
                                    </td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-description" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:10px;padding-left:10px;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Description}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="label longfield" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;font-size:18px;font-weight:200;color:rgb(244, 101, 21);width:0;line-height:200%;vertical-align:middle;padding-top:24px;border-bottom:4px solid rgb(230, 230, 230);">
                                        Comments:</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="longfield" id="longfield-comments" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        ${Comments}</td>
                                </tr>
                                <tr
                                    style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;vertical-align:top;text-align:left;">
                                    <td class="footer" style="-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;mso-table-lspace:0pt;mso-table-rspace:0pt;vertical-align:top;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;Margin:0;text-align:left;font-size:13px;line-height:19px;padding-top:13px;width:768px;max-width:100vw;overflow-x:hidden;">
                                        <h6 class="gray"
                                        style="padding-top:30px;padding-bottom:0;padding-right:0;padding-left:0;margin-top:0;margin-right:0;margin-left:0;Margin:0;text-align:left;line-height:1.3;word-wrap:normal;font-family: -apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;font-weight:normal;margin-bottom:4px;Margin-bottom:4px;font-size:11px;color:#777;">
                                            <svg width="32" height= "32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1241 1435"><defs><style>.a{fill:#f1a42b;}.b{fill:#fdcb26;}.c{fill:#f08231;}</style></defs><title>Asset 2spiraplan</title><polygon class="a" points="974 1231 1241 1077 1241 768 974 922 974 1231"/><polygon class="b" points="707 768 974 922 1241 768 974 614 707 768"/><polygon class="c" points="974 1231 974 922 707 768 707 1077 974 1231"/><polygon class="b" points="887 154 620 0 353 154 620 308 887 154"/><polygon class="c" points="620 616 620 308 353 154 353 462 620 616"/><polygon class="a" points="887 154 620 308 620 616 887 462 887 154"/><polygon class="c" points="0 766 0 1074 267 1229 267 920 0 766"/><polygon class="a" points="534 766 267 920 267 1229 534 1074 534 766"/><polygon class="b" points="0 766 267 920 534 766 267 612 0 766"/><polygon class="a" points="267 820 534 666 534 358 267 512 267 820"/><polygon class="b" points="0 358 267 512 534 358 267 204 0 358"/><polygon class="c" points="267 820 267 512 0 358 0 666 267 820"/><polygon class="a" points="620 1435 887 1281 887 972 620 1127 620 1435"/><polygon class="b" points="353 972 620 1127 887 972 620 818 353 972"/><polygon class="c" points="620 1435 620 1127 353 972 353 1281 620 1435"/><polygon class="c" points="707 360 707 668 974 823 974 514 707 360"/><polygon class="a" points="1241 360 974 514 974 823 1241 668 1241 360"/><polygon class="b" points="707 360 974 514 1241 360 974 206 707 360"/></svg>
                                            <div style="width:100%;margin-top:10px;margin-bottom:10px;margin-right:0;margin-left:0;Margin:10px 0;box-sizing:border-box;text-align:inherit;">
                                                Read the <a href="http://www.inflectra.com/Ideas/?Source=AppUser">latest news</a> about Inflectra or <a href="https://spiradoc.inflectra.com">learn more</a> about ${Product}
                                            </div>
                                        </h6>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
'
)
GO

SET IDENTITY_INSERT TST_NOTIFICATION_ARTIFACT_TEMPLATE OFF; 

