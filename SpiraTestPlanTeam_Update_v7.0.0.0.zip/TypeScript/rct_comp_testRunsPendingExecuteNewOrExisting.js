var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var resx = Inflectra.SpiraTest.Web.GlobalResources;
var RctTestRunsPendingExecuteNewOrExisting = (function (_super) {
    __extends(RctTestRunsPendingExecuteNewOrExisting, _super);
    function RctTestRunsPendingExecuteNewOrExisting(props) {
        var _this = _super.call(this, props) || this;
        _this.ddlTestRunsPending = null;
        _this.btnExecute = React.createRef();
        _this.startExecuteProcess = _this.startExecuteProcess.bind(_this);
        _this.handleClose = _this.handleClose.bind(_this);
        _this.btnExecuteKeyDown = _this.btnExecuteKeyDown.bind(_this);
        _this.btnCancelKeyDown = _this.btnCancelKeyDown.bind(_this);
        return _this;
    }
    RctTestRunsPendingExecuteNewOrExisting.prototype.componentDidMount = function () {
        var _this = this;
        Mousetrap.bind("escape", function (e) { return _this.handleClose(null); });
        this.btnExecute.current.focus();
        this.ddlTestRunsPending = $create(Inflectra.SpiraTest.Web.ServerControls.DropDownList, {
            multiSelectable: false,
            enabledCssClass: 'u-dropdown is-active fs-14 form-control mt-2 ',
            disabledCssClass: 'u-dropdown disabled'
        }, null, null, document.getElementById('ddlExistingTestRunsPending'));
        var dataForDdl = this.props.data.reverse().reduce(function (acc, item, index, arr) {
            var _a;
            return __assign((_a = {}, _a[globalFunctions.keyPrefix + item.id] = item.name, _a), acc);
        }, {});
        this.ddlTestRunsPending.set_dataSource(dataForDdl);
        this.ddlTestRunsPending.dataBind();
        this.ddlTestRunsPending.addItem('', resx.TestRun_ExecuteNewTest);
        this.ddlTestRunsPending.set_selectedItem(resx.TestRun_ExecuteNewTest, false);
    };
    RctTestRunsPendingExecuteNewOrExisting.prototype.startExecuteProcess = function (e) {
        e.preventDefault();
        var selectedValue = this.ddlTestRunsPending.get_selectedItem().get_value();
        this.props.executeFunction(selectedValue);
        this.handleClose(null);
    };
    RctTestRunsPendingExecuteNewOrExisting.prototype.btnExecuteKeyDown = function (e) {
        if (e.key === "Enter") {
            this.startExecuteProcess(e);
        }
    };
    RctTestRunsPendingExecuteNewOrExisting.prototype.handleClose = function (e) {
        this.ddlTestRunsPending.dispose();
        delete this.ddlTestRunsPending;
        globalFunctions.dlgGlobalDynamicClear();
        Mousetrap.unbind("escape");
    };
    RctTestRunsPendingExecuteNewOrExisting.prototype.btnCancelKeyDown = function (e) {
        if (e.key === "Enter") {
            this.handleClose(e);
        }
    };
    RctTestRunsPendingExecuteNewOrExisting.prototype.render = function () {
        return (React.createElement(React.Fragment, null,
            React.createElement("div", { className: "DialogBoxModalBackground visibility-none fade-in-50 fixed left0 right0 top0 bottom0", onClick: this.handleClose }),
            React.createElement("div", { class: "custom-model u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                React.createElement("div", { class: "custom-header" },
                    React.createElement("div", { id: "divMessagePopupBox", className: "modal-title fs-16 fw-bold", role: "alert" }, resx.TestRun_ExistingPendingForUseAndTestId),
                    React.createElement("span", { onClick: this.handleClose, className: "ti ti-x d-flex p-1 bg-border rounded-circle vm-darkgrey abc" })),
                React.createElement("div", { className: "mb-3 fw-normal fs-14 custom-body" },
                    React.createElement("p", null, resx.TestRun_ExistingPendingForUseAndTestId_info),
                    React.createElement("div", null,
                        React.createElement("label", { className: "fs-14 fw-normal", htmlFor: "ddlExistingTestRunsPending" },
                            resx.TestRun_ChooseTestToRun,
                            ":")),
                    React.createElement("div", { id: "ddlExistingTestRunsPending" }),
                    React.createElement("div", { className: "d-flex justify-content-end gap-2 mt-4", role: "group" },
                        React.createElement("button", { className: "btn secondary-button width-style", id: "btnCancelExistingTestRunsPending", onClick: this.handleClose, onKeyDown: this.btnCancelKeyDown, type: "button" }, resx.Global_Cancel),
                        React.createElement("button", { className: "btn primary-button width-style", id: "btnExistingTestRunsPending", onClick: this.startExecuteProcess, onKeyDown: this.btnExecuteKeyDown, ref: this.btnExecute, type: "button" }, resx.TestCaseList_ExecuteTestCase))))));
    };
    return RctTestRunsPendingExecuteNewOrExisting;
}(React.Component));
;
//# sourceMappingURL=rct_comp_testRunsPendingExecuteNewOrExisting.js.map