var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var AvatarIcon = (function (_super) {
    __extends(AvatarIcon, _super);
    function AvatarIcon(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            cardPosition: "right"
        };
        return _this;
    }
    AvatarIcon.prototype.componentDidMount = function () {
        if (this.props.showCard) {
            var iconNode = ReactDOM.findDOMNode(this), spaceOnLeft = iconNode.offsetLeft, spaceOnRight = window.innerWidth - iconNode.offsetLeft, newCardPosition = this.setCardPosition(spaceOnLeft, spaceOnRight, this.props.cardWidth);
            this.setState({ cardPosition: newCardPosition });
        }
    };
    AvatarIcon.prototype.setCardPosition = function (left, right, cardWidth) {
        return right >= cardWidth ? "right" : left >= cardWidth ? "left" : "center";
    };
    AvatarIcon.prototype.render = function () {
        var iconSize = this.props.iconSize || 5, iconWidth = "w" + iconSize, iconHeight = "h" + iconSize;
        return (React.createElement("div", { className: this.props.wrapperClasses ? this.props.wrapperClasses : "mr3 mb3 relative dib lh-initial", onClick: this.props.onClick },
            React.createElement("div", { className: "dib relative o-1-sibling-hover u-slideIn-sibling-hover" },
                this.props.hasIcon ?
                    React.createElement("img", { alt: this.props.name, className: "br-100 h-auto " + iconWidth, src: this.props.icon })
                    :
                        React.createElement("div", { className: "icon-border dib v-mid bg-light-gray ov-hidden tc " + iconWidth + " " + iconHeight },
                            React.createElement("span", { className: "fs-12 fs-12-sm white y-center dib lh0 fw-b" }, this.props.nameAsIcon)),
                this.props.isOnline ?
                    React.createElement("div", { className: "h3 w3 br-100 absolute bottom0 right0 bg-green" })
                    : null),
            this.props.showCard &&
                React.createElement(AvatarCard, __assign({ cardPosition: this.state.cardPosition }, this.props))));
    };
    return AvatarIcon;
}(React.Component));
//# sourceMappingURL=rct_comp_avatarIcon.js.map