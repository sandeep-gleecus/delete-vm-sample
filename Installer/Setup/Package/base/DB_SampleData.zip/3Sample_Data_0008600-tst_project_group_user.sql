/***************************************************************
**	Insert script for table TST_PROJECT_GROUP_USER
***************************************************************/
INSERT INTO TST_PROJECT_GROUP_USER
(
PROJECT_GROUP_ID, USER_ID, PROJECT_GROUP_ROLE_ID
)
VALUES
(
1, 1, 1
),
(
2, 1, 1
),
(
2, 2, 1
),
(
3, 2, 2
),
(
3, 1, 1
),
(
4, 1, 1
)
GO

