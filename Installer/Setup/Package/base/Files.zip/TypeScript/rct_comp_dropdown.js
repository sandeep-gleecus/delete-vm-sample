var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RctDrop = (function (_super) {
    __extends(RctDrop, _super);
    function RctDrop(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            menuIsOpen: false,
            boxClasses: "drop-box" + (_this.props.boxClasses ? " " + _this.props.boxClasses : ""),
            buttonClasses: "",
            buttonText: "",
            hasItems: false,
            menuClasses: _this.props.menuClasses ? _this.props.menuClasses : "u-drop-menu mh9 ov-y-auto",
            itemClasses: _this.props.itemClasses ? _this.props.itemClasses : "",
            liClasses: "u-drop-item " + (_this.props.liClasses ? _this.props.liClasses : ""),
            selected: _this.props.selected,
            selectedItem: "",
            focused: _this.props.selected,
            itemListIds: _this.props.items && _this.props.items.length ? _this.props.items.filter(function (x) { return !x.hide; }).map(function (x) { return x.listId; }) : null,
            showLoader: false
        };
        _this.setButtonClasses = _this.setButtonClasses.bind(_this);
        _this.menuToggle = _this.menuToggle.bind(_this);
        _this.menuClose = _this.menuClose.bind(_this);
        _this.menuOnBlur = _this.menuOnBlur.bind(_this);
        _this.itemOnClick = _this.itemOnClick.bind(_this);
        _this.itemExpanderClick = _this.itemExpanderClick.bind(_this);
        return _this;
    }
    RctDrop.prototype.componentDidMount = function () {
        this.bindKeyboardShortcuts();
        this.setButtonClasses();
        this.setState({
            buttonText: this.buttonText(),
            hasItems: this.hasItems(),
            selectedItem: this.selectedItem()
        });
    };
    RctDrop.prototype.hasItems = function () {
        return this.props.items && this.props.items.length > 0 && this.props.items[0] != undefined;
    };
    RctDrop.prototype.setButtonClasses = function () {
        var classes = "drop-toggle d-flex align-items-center" + (this.hasItems() ? "" : " is-empty") + (this.props.buttonClasses ? " " + this.props.buttonClasses : " u-btn");
        this.setState({ buttonClasses: classes });
    };
    RctDrop.prototype.selectedItem = function () {
        var _this = this;
        return this.hasItems() ?
            this.props.items.filter(function (item) { return item.listId == _this.props.selected; })[0] || this.props.items[0].listId
            : null;
    };
    RctDrop.prototype.buttonText = function () {
        var selectedItem = this.selectedItem();
        var wrapperClasses = "ov-hidden to-ellipsis";
        var selectedText = "", defaultText = "", extraDefaultText = "";
        if (selectedItem && selectedItem.name) {
            var selectedImage = this.props.showImageInButton && selectedItem.imageUrl ? React.createElement("img", { src: selectedItem.imageUrl, className: selectedItem.imageClasses || "" }) : null;
            var selectedTextActual = selectedItem.showTitleInButton ? selectedItem.title : selectedItem.name;
            var selectedGlyph = selectedItem.secondaryGlyph && React.createElement("i", { className: selectedItem.secondaryGlyph });
            selectedText = React.createElement("span", null,
                selectedImage,
                selectedTextActual,
                selectedGlyph);
        }
        if (this.props.defaultText && (this.props.showDefaultAndSelected || this.props.alwaysShowDefault || !selectedText)) {
            defaultText = this.props.defaultText;
        }
        if (!selectedText && this.props.extraDefaultText && (this.props.showDefaultAndSelected || this.props.alwaysShowDefault)) {
            extraDefaultText = React.createElement("span", { className: this.props.extraDefaultClasses }, this.props.extraDefaultText);
        }
        var showDefaultOnRight = this.props.showDefaultOnRight;
        var firstItem = showDefaultOnRight ? selectedText : defaultText, secondItem = extraDefaultText, thirdItem = showDefaultOnRight ? defaultText : selectedText;
        return React.createElement("span", { className: wrapperClasses },
            firstItem,
            React.createElement("span", { className: "ml2" }, secondItem),
            React.createElement("span", { className: "ml2" }, thirdItem));
    };
    RctDrop.prototype.bindKeyboardShortcuts = function () {
        var _this = this;
        Mousetrap.bind("down", function (e) {
            e.target.focus();
            e.preventDefault();
            _this.focusedMove("down");
        });
        Mousetrap.bind("up", function (e) {
            e.target.focus();
            e.preventDefault();
            _this.focusedMove("up");
        });
        Mousetrap.bind("right", function (e) {
            e.preventDefault();
            _this.itemExpanderClick(_this.state.focused, false, null);
        });
        Mousetrap.bind("left", function (e) {
            e.preventDefault();
            _this.itemExpanderClick(_this.state.focused, true, null);
        });
        Mousetrap.bind("escape", function (e) { return _this.menuClose(); });
        Mousetrap.bind("enter", function (e) { return _this.itemOnClick(_this.state.focused, e); });
    };
    RctDrop.prototype.unbindKeyboardShortcuts = function () {
        Mousetrap.unbind('down');
        Mousetrap.unbind('up');
        Mousetrap.unbind('right');
        Mousetrap.unbind('left');
    };
    RctDrop.prototype.moveInArray = function (item, array, moveUp) {
        var index = array.indexOf(String(item));
        var shift = (moveUp && index > 0) ? -1 : (!moveUp && array.length > index + 1) ? 1 : 0;
        var newIndex = index === -1 ? 0 : index + shift;
        return {
            item: array[newIndex],
            atStart: newIndex === 0,
            atEnd: newIndex === array.length - 1
        };
    };
    RctDrop.prototype.focusedMove = function (direction) {
        var newFocus = this.state.selected;
        var isMoveUp = direction == "up";
        var listIds = this.props.items.filter(function (x) { return !x.hide; }).map(function (x) { return x.listId; });
        if (listIds.length) {
            newFocus = this.moveInArray(this.state.focused, listIds, isMoveUp).item;
        }
        this.setState({ focused: newFocus });
    };
    RctDrop.prototype.menuToggle = function (e) {
        if (e)
            e.stopPropagation();
        this.props.menuToggleCallback && this.props.menuToggleCallback(this.props.dataName, !this.state.menuIsOpen);
        this.state.menuIsOpen ? this.unbindKeyboardShortcuts() : this.bindKeyboardShortcuts();
        this.setState({ menuIsOpen: !this.state.menuIsOpen });
    };
    RctDrop.prototype.menuClose = function () {
        this.props.menuToggleCallback && this.props.menuToggleCallback(this.props.dataName, false);
        this.setState({ menuIsOpen: false });
        this.unbindKeyboardShortcuts();
    };
    RctDrop.prototype.menuOnBlur = function (e) {
        var _this = this;
        var target = e.currentTarget;
        setTimeout(function () {
            if (!target.contains(document.activeElement)) {
                _this.menuClose();
                _this.unbindKeyboardShortcuts();
            }
        }, 0);
    };
    RctDrop.prototype.itemOnClick = function (listId, e) {
        if (e)
            e.preventDefault();
        var item = this.props.items.filter(function (x) { return x.listId === listId; })[0];
        if (item && item.isEnabled) {
            if (this.props.itemClickManager) {
                this.props.itemClickManager(listId);
                if (this.props.showLoaderOnClick && !item.dontShowLoader) {
                    this.setState({ showLoader: true });
                }
                ;
                this.menuClose();
            }
            else if (item.url) {
                if (e.ctrlKey || e.which === 2) {
                    window.open(item.url, '_blank');
                }
                else {
                    window.location.assign(item.url);
                    if (this.props.showLoaderOnClick && !item.dontShowLoader) {
                        this.setState({ showLoader: true });
                    }
                    ;
                    this.menuClose();
                }
            }
            else if (item.children) {
                this.itemExpanderClick(listId, null, null);
            }
        }
        else if (item && item.children) {
            this.itemExpanderClick(listId, null, null);
        }
    };
    RctDrop.prototype.itemExpanderClick = function (parentListId, status, event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        var parent = this.props.items.filter(function (x) { return x.listId === parentListId; })[0];
        var hasChildren = parent && parent.children && parent.children.length > 0;
        if (hasChildren) {
            var newHideStatus = status == null ? !parent.hideChildren : status;
            this.props.expanderClickManager([parentListId], newHideStatus, this.props.dataName, this.props.dataHiddenName);
        }
    };
    RctDrop.prototype.render = function () {
        var _this = this;
        var _a = this.state, boxClasses = _a.boxClasses, buttonClasses = _a.buttonClasses, buttonText = _a.buttonText, hasItems = _a.hasItems, itemClasses = _a.itemClasses, menuClasses = _a.menuClasses, menuIsOpen = _a.menuIsOpen, selectedItem = _a.selectedItem, showLoader = _a.showLoader;
        var itemNodes = hasItems ?
            this.props.items.filter(function (x) { return !x.hide; }).map(function (item, index) {
                var selectedClass = _this.state.selected == item.listId ? " is-selected" : "", focusedClass = _this.state.focused == item.listId ? " is-focused" : "", enabledClass = item.isEnabled ? "" : " cursor-default";
                var linkClasses = (item.linkClasses ? item.linkClasses : "u-drop-item") + selectedClass + enabledClass + focusedClass, expanderClasses = _this.props.expanderClasses + (" w4 mln4 pointer fas fa-fw" + (item.hideChildren ? " fa-caret-right" : " fa-caret-down"));
                return (React.createElement("a", { "aria-label": item.ariaLabel, className: linkClasses, href: item.isEnabled ? item.url || "#" : "#", id: item.domIdPrefix && item.listId ? item.domIdPrefix + item.listId : "", key: item.listId, target: item.target || "", onClick: item.onClick ? item.onClick : item.openPlainHtml ? null : _this.itemOnClick.bind(null, item.listId), title: item.title },
                    item.indentLevel ? React.createElement("span", { style: { paddingLeft: (item.indentLevel + "rem") } }) : null,
                    item.children &&
                        React.createElement("span", { className: expanderClasses, onClick: _this.itemExpanderClick.bind(null, item.listId, null) }),
                    item.imageUrl &&
                        React.createElement("img", { src: item.imageUrl, className: item.imageClasses || "" }),
                    item.glyph && React.createElement("i", { "aria-hidden": "true", className: item.glyph }),
                    item.name,
                    item.secondaryGlyph && React.createElement("i", { "aria-hidden": "true", className: item.secondaryGlyph })));
            })
            : null;
        return (React.createElement("div", { className: boxClasses, id: this.props.wrapperId || "", onBlur: this.menuOnBlur },
            React.createElement("button", { "aria-haspopup": "true", "aria-label": this.props.ariaLabelWrapper, className: buttonClasses + (menuIsOpen ? " is-open" : "") + (showLoader ? " is-empty" : ""), id: this.props.domId || "", onClick: this.menuToggle, title: selectedItem && selectedItem.title || this.props.defaultTitle || "", type: "button" },
                this.state.showLoader ?
                    React.createElement("div", { className: "lds-ellipsis" },
                        React.createElement("div", null),
                        React.createElement("div", null),
                        React.createElement("div", null),
                        React.createElement("div", null))
                    : selectedItem && selectedItem.title || this.props.defaultTitle ? React.createElement("span", { className: "nav-drop-text FirstOpt " }, buttonText) : React.createElement("span", { className: "nav-drop-text " }, buttonText),
                selectedItem && selectedItem.title || this.props.defaultTitle ? React.createElement("img", { class: "", src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/ArrowDown.svg", alt: "ArrowDown" }) : React.createElement("img", { class: "", src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/ArrowDown.svg", alt: "ArrowDown" })),
            hasItems && menuIsOpen &&
                React.createElement("div", { className: menuClasses, role: "menu", tabindex: "0" }, itemNodes)));
    };
    return RctDrop;
}(React.Component));
//# sourceMappingURL=rct_comp_dropdown.js.map