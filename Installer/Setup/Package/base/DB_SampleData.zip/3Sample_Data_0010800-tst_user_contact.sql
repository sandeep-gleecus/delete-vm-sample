/***************************************************************
**	Insert script for table TST_USER_CONTACT
***************************************************************/
INSERT INTO TST_USER_CONTACT
(
CREATOR_USER_ID, CONTACT_USER_ID
)
VALUES
(
2, 1
),
(
2, 3
)
GO

