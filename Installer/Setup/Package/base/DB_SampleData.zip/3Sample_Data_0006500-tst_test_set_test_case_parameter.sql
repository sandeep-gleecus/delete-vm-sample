/***************************************************************
**	Insert script for table TST_TEST_SET_TEST_CASE_PARAMETER
***************************************************************/
INSERT INTO TST_TEST_SET_TEST_CASE_PARAMETER
(
TEST_SET_TEST_CASE_ID, TEST_CASE_PARAMETER_ID, VALUE
)
VALUES
(
17, 4, 'Microsoft Edge'
),
(
18, 4, 'Microsoft Edge'
),
(
28, 4, 'Firefox'
),
(
29, 4, 'Firefox'
),
(
19, 4, 'Internet Explorer'
),
(
20, 4, 'Internet Explorer'
),
(
30, 4, 'Chrome'
),
(
31, 4, 'Chrome'
)
GO

