-- =====================================================================
-- Author:			Inflectra Corporation
-- =====================================================================
UPDATE TST_USER_PROFILE
SET IS_PORTFOLIO_ADMIN = 1
WHERE [USER_ID] = 1
GO

