var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Type.registerNamespace('Inflectra.SpiraTest.Web');
Inflectra.SpiraTest.Web.TestSetDetails = function () {
    this._currentTestSetTestCaseId = null;
    this._addPanelIsOpen = false;
    this._testFolders = null;
    this._testSetTestCaseParametersViewModel = null;
    this._testSetParametersViewModel = null;
    this._lblTestCaseMessages = $get(lblTestCaseMessages_id);
    this._msgTestCaseParameters = $get(msgTestCaseParameters_id);
    this._msgTestSetParameters = $get(msgTestSetParameters_id);
    Inflectra.SpiraTest.Web.TestSetDetails.initializeBase(this);
};
Inflectra.SpiraTest.Web.TestSetDetails.prototype =
    {
        initialize: function () {
            Inflectra.SpiraTest.Web.TestSetDetails.callBaseMethod(this, 'initialize');
        },
        dispose: function () {
            Inflectra.SpiraTest.Web.TestSetDetails.callBaseMethod(this, 'dispose');
        },
        get_testSetId: function () {
            return this._testSetId;
        },
        set_testSetId: function (val) {
            this._testSetId = val;
        },
        get_addPanelIsOpen: function () {
            return this._addPanelIsOpen;
        },
        set_addPanelIsOpen: function (value) {
            this._addPanelIsOpen = value;
        },
        displayEditTestCaseParameters: function (evt) {
            var grdTestCases = $find(grdTestCases_id);
            var testSetTestCaseIds = grdTestCases.get_selected_items();
            if (testSetTestCaseIds.length != 1) {
                alert(Inflectra.SpiraTest.Web.GlobalResources.TestSetDetails_SelectOnlyOneTestCase);
                return;
            }
            $get('divHasParameters').style.display = 'none';
            $get('divNoParameters').style.display = 'none';
            var testSetTestCaseId = testSetTestCaseIds[0];
            this._currentTestSetTestCaseId = testSetTestCaseId;
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetTestCaseService.RetrieveParameters(testSetTestCaseId, AspNetAjax$Function.createDelegate(this, this.tblTestCaseParametersEdit_success), AspNetAjax$Function.createDelegate(this, this.tblTestCaseParametersEdit_failure), evt);
        },
        tblTestCaseParametersEdit_success: function (data, evt) {
            globalFunctions.hide_spinner();
            var valuesUnique = [], dataUnique = [];
            data.forEach(function (item) {
                var name = item.Fields.Name.textValue, value = item.Fields.Value.textValue;
                if (valuesUnique.indexOf(name) < 0 || value) {
                    valuesUnique.push(name);
                    dataUnique.push(item);
                }
            });
            if (this._testSetTestCaseParametersViewModel) {
                ko.mapping.fromJS(dataUnique, this._testSetTestCaseParametersViewModel);
            }
            else {
                this._testSetTestCaseParametersViewModel = ko.mapping.fromJS(dataUnique);
                ko.applyBindings(this._testSetTestCaseParametersViewModel, $get('tblTestCaseParametersEdit'));
            }
            var pnlEditTestCaseParameters = $find(pnlEditTestCaseParameters_id);
            pnlEditTestCaseParameters.display(evt);
            if (data && data.length > 0) {
                $get('divHasParameters').style.display = 'block';
            }
            else {
                $get('divNoParameters').style.display = 'block';
            }
        },
        tblTestCaseParametersEdit_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._lblTestCaseMessages, exception);
        },
        pnlEditTestCaseParameters_tblTestCaseParametersEdit_keydown: function (data, evt) {
            var keynum = evt.keyCode | evt.which;
            if (keynum == 13) {
                evt.preventDefault();
                evt.stopPropagation();
                this.pnlEditTestCaseParameters_btnTestParametersUpdate_click(evt);
                return false;
            }
            return true;
        },
        pnlEditTestCaseParameters_btnTestParametersUpdate_click: function (evt) {
            var testSetTestCaseId = this._currentTestSetTestCaseId;
            var parameterValues = ko.mapping.toJS(this._testSetTestCaseParametersViewModel);
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetTestCaseService.UpdateParameters(testSetTestCaseId, parameterValues, AspNetAjax$Function.createDelegate(this, this.tblTestCaseParametersUpdate_success), AspNetAjax$Function.createDelegate(this, this.tblTestCaseParametersUpdate_failure));
        },
        tblTestCaseParametersUpdate_success: function () {
            globalFunctions.hide_spinner();
            var pnlEditTestCaseParameters = $find(pnlEditTestCaseParameters_id);
            pnlEditTestCaseParameters.close();
            var grdTestCases = $find(grdTestCases_id);
            grdTestCases.load_data();
        },
        tblTestCaseParametersUpdate_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgTestCaseParameters, exception);
        },
        execute_test_set: function () {
            var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
            ajxBackgroundProcessManager.display(SpiraContext.ProjectId, 'TestSet_Execute', resx.TestSetList_ExecuteTestSet, resx.TestSetList_ExecuteTestSetDesc, this._testSetId);
        },
        grdTestCases_execute: function () {
            var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
            var grdTestCases = $find(grdTestCases_id);
            var testCaseIds = grdTestCases.get_selected_items();
            if (testCaseIds.length < 1) {
                alert(resx.TestSetDetails_SelectTestCaseFirst);
                return;
            }
            ajxBackgroundProcessManager.display(SpiraContext.ProjectId, 'TestSet_TestCaseExecute', resx.TestSetDetails_ExecuteTestCases, resx.TestSetDetails_ExecuteTestCasesDesc, this._testSetId, testCaseIds);
        },
        ajxBackgroundProcessManager_success: function (msg, returnCode) {
            if (returnCode == -2) {
                window.location.href = urlTemplate_launchUrl;
            }
            else if (returnCode && returnCode > 0) {
                var ajxBackgroundProcessManager = $find(ajxBackgroundProcessManager_id);
                var projectId = ajxBackgroundProcessManager.get_projectId();
                var baseUrl = msg === "testcase_executeexploratory" ? urlTemplate_testRunsPendingExploratory : urlTemplate_testRunsPending;
                var url = baseUrl.replace(globalFunctions.artifactIdToken, returnCode).replace(globalFunctions.projectIdToken, projectId);
                window.location.href = url;
            }
        },
        grdTestCases_loaded: function () {
        },
        ddlAutomationHost_changed: function (args) {
            var ddlAutomationHost = $find(ddlAutomationHost_id);
            var ddlTestRunType = $find(ddlTestRunType_id);
            if (ddlAutomationHost.get_selectedItem().get_value() == '') {
                ddlTestRunType.set_selectedItem(globalFunctions.testRunTypeEnum.manual);
            }
            else {
                ddlTestRunType.set_selectedItem(globalFunctions.testRunTypeEnum.automated);
            }
        },
        load_parameterValues: function () {
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.RetrieveParameterValues(SpiraContext.ProjectId, this._testSetId, AspNetAjax$Function.createDelegate(this, this.load_parameterValues_success), AspNetAjax$Function.createDelegate(this, this.load_parameterValues_failure));
        },
        load_parameterValues_success: function (data) {
            SpiraContext.uiState.testSetParametersWithValues = [];
            if (data) {
                for (var item in data) {
                    data[item].editable = false;
                    if (!data[item].Fields.Value.textValue) {
                        data[item].Fields.Value.textValue = '';
                    }
                    if (!data[item].Fields.DefaultValue.textValue) {
                        data[item].Fields.DefaultValue.textValue = '';
                    }
                    SpiraContext.uiState.testSetParametersWithValues.push(data[item].Fields.Name.textValue);
                }
            }
            if (this._testSetParametersViewModel) {
                ko.mapping.fromJS(data, this._testSetParametersViewModel);
            }
            else {
                this._testSetParametersViewModel = ko.mapping.fromJS(data);
                ko.applyBindings(this._testSetParametersViewModel, $get('tblTestSetParameterValues'));
            }
        },
        load_parameterValues_failure: function (exception) {
            globalFunctions.hide_spinner();
            globalFunctions.display_error(this._msgTestSetParameters, exception);
        },
        testSetParameters_edit: function (testSetParameter) {
            var editable = testSetParameter.editable();
            testSetParameter.editable(!editable);
        },
        testSetParameters_delete: function (testSetParameter) {
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.DeleteParameterValue(SpiraContext.ProjectId, this._testSetId, testSetParameter.primaryKey(), AspNetAjax$Function.createDelegate(this, this.update_parameterValues_success), AspNetAjax$Function.createDelegate(this, this.load_parameterValues_failure));
        },
        testSetParameters_save: function (testSetParameter) {
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.UpdateParameterValue(SpiraContext.ProjectId, this._testSetId, testSetParameter.primaryKey(), testSetParameter.Fields.Value.textValue(), AspNetAjax$Function.createDelegate(this, this.update_parameterValues_success), AspNetAjax$Function.createDelegate(this, this.load_parameterValues_failure));
        },
        update_parameterValues_success: function () {
            this.load_parameterValues();
        },
        btnAddTestSetParameterValue_click: function (evt) {
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.RetrieveParameters(SpiraContext.ProjectId, this._testSetId, AspNetAjax$Function.createDelegate(this, this.btnAddTestSetParameterValue_click_success), AspNetAjax$Function.createDelegate(this, this.load_parameterValues_failure), evt);
        },
        btnAddTestSetParameterValue_click_success: function (data, evt) {
            globalFunctions.hide_spinner();
            var valuesUnique = [], dataUnique = {}, dataUniqueCount = 0;
            if (SpiraContext.uiState.testSetParametersWithValues && SpiraContext.uiState.testSetParametersWithValues.length) {
                valuesUnique = __spreadArray([], SpiraContext.uiState.testSetParametersWithValues, true);
            }
            for (var property in data) {
                if (property !== "__type") {
                    if (valuesUnique.indexOf(data[property]) < 0) {
                        valuesUnique.push(data[property]);
                        dataUnique[property] = data[property];
                        dataUniqueCount++;
                    }
                }
            }
            if (dataUniqueCount > 0) {
                var ddlParameterName = $find(ddlParameterName_id);
                ddlParameterName.clearItems();
                ddlParameterName.addItem('', resx.Global_PleaseSelect, true);
                ddlParameterName.set_dataSource(dataUnique);
                ddlParameterName.dataBind();
                ddlParameterName.set_selectedItem('', true);
                $get(txtNewParameterValue_id).value = '';
                var pnlAddTestSetParameter = $find(pnlAddTestSetParameter_id);
                pnlAddTestSetParameter.display(evt);
            }
            else {
                globalFunctions.globalAlert(resx.TestSetDetails_ParamatersNoneToAdd, "info", true, null, "fas fa-info-circle mr3 o-70");
            }
        },
        testSetParameters_add: function () {
            globalFunctions.hide_spinner();
            var ddlParameterName = $find(ddlParameterName_id);
            var txtNewParameterValue = $get(txtNewParameterValue_id);
            var newValue = globalFunctions.trim(txtNewParameterValue.value);
            if (!ddlParameterName.get_selectedItem() || ddlParameterName.get_selectedItem().get_value() == '') {
                alert(resx.TestSetDetails_ParameterRequired);
                return;
            }
            if (!newValue || newValue == '') {
                alert(resx.TestSetDetails_ParameterValueRequired);
                return;
            }
            var testCaseParameterId = parseInt(ddlParameterName.get_selectedItem().get_value());
            globalFunctions.display_spinner();
            Inflectra.SpiraTest.Web.Services.Ajax.TestSetService.AddParameterValue(SpiraContext.ProjectId, this._testSetId, testCaseParameterId, newValue, AspNetAjax$Function.createDelegate(this, this.testSetParameters_add_success), AspNetAjax$Function.createDelegate(this, this.load_parameterValues_failure));
        },
        testSetParameters_add_success: function () {
            globalFunctions.hide_spinner();
            var pnlAddTestSetParameter = $find(pnlAddTestSetParameter_id);
            pnlAddTestSetParameter.close();
            this.load_parameterValues();
        },
        closeAddAssocationPanel: function () {
            var domId = panelAssociationAdd.lnkAddBtnId;
            if (SpiraContext.uiState[domId].isMounted) {
                $("#" + panelAssociationAdd.lnkAddBtnId).removeClass('disabled');
                SpiraContext.uiState[domId].isMounted = false;
                ReactDOM.unmountComponentAtNode(document.getElementById(domId));
            }
        }
    };
//# sourceMappingURL=TestSetDetails.js.map