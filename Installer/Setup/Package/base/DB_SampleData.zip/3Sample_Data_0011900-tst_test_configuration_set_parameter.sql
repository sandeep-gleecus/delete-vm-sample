/***************************************************************
**	Insert script for table TST_TEST_CONFIGURATION_SET_PARAMETER
***************************************************************/
INSERT INTO TST_TEST_CONFIGURATION_SET_PARAMETER
(
TEST_CONFIGURATION_SET_ID, TEST_CASE_PARAMETER_ID
)
VALUES
(
1, 4
),
(
1, 10
),
(
2, 2
),
(
2, 3
),
(
3, 4
),
(
3, 10
),
(
3, 2
)
GO

