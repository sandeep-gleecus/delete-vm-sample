var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var documentDetails = {
    versionGridId: '',
    versionHeaders: [],
    uploadButton: '',
    messageBoxId: '',
    makeActiveButton: '',
    deleteButton: '',
    uploadClickHandler: null,
    uploadFile_details: null,
    dlgUploadNewVersion_id: '',
    attachmentTypeId: -1,
    isAuthorizedToModify: false,
    mimeType: '',
    check_hasData: function () {
        Inflectra.SpiraTest.Web.Services.Ajax.DocumentVersionService.DocumentVersion_CountVersions(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.check_hasData_success), this.check_hasData_failure);
    },
    check_hasData_success: function (count) {
        var hasData = (count > 0);
        $find(tabControl_id).updateHasData('tabVersions', hasData);
    },
    check_hasData_failure: function (ex) {
    },
    updateUrl: function () {
        var ajxFormManager = $find(ajxFormManager_id);
        var dataItem = ajxFormManager.get_dataItem();
        if (dataItem) {
            var url = void 0;
            this.attachmentTypeId = dataItem.Fields._AttachmentTypeId.intValue;
            if (dataItem.Fields._AttachmentTypeId.intValue == globalFunctions.attachmentTypeEnum.file) {
                url = urlTemplate_attachmentOpenUrl.replace(globalFunctions.artifactIdToken, dataItem.primaryKey);
            }
            else {
                url = globalFunctions.formNavigatableUrl(dataItem.Fields.Filename.textValue);
            }
            $get(lnkDocumentName_id).href = url;
        }
    },
    updatePreview: function () {
        var previewAvailable = false;
        var ajxFormManager = $find(ajxFormManager_id);
        var dataItem = ajxFormManager.get_dataItem();
        if (dataItem && dataItem.Fields._AttachmentTypeId.intValue == globalFunctions.attachmentTypeEnum.file) {
            this.mimeType = dataItem.Fields._MimeType.textValue;
            if (this.mimeType == 'text/markdown') {
                Inflectra.SpiraTest.Web.Services.Ajax.DocumentsService.Documents_OpenMarkdown(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.updatePreviewMarkdown_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
                previewAvailable = true;
            }
            else if (this.mimeType == 'text/html') {
                Inflectra.SpiraTest.Web.Services.Ajax.DocumentsService.Documents_OpenText(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.updatePreviewMarkdown_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
                previewAvailable = true;
            }
            else {
                $('#htmlPreview').hide();
                $('#htmlPreviewIframe').hide();
            }
            if (this.mimeType != 'text/markdown' && this.mimeType != 'text/html' && this.mimeType.substr(0, 'text'.length) == 'text' || this.mimeType == 'application/x-rapise' || this.mimeType == 'application/json' || this.mimeType == 'application/xml' || this.mimeType == 'application/x-bat') {
                Inflectra.SpiraTest.Web.Services.Ajax.DocumentsService.Documents_OpenText(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.updatePreview_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
                previewAvailable = true;
                $('#codePreview').show();
            }
            else {
                $('#codePreview').hide();
            }
            if (this.mimeType == 'application/x-diagram' || this.mimeType == 'application/x-mindmap') {
                Inflectra.SpiraTest.Web.Services.Ajax.DocumentsService.Documents_OpenText(SpiraContext.ProjectId, SpiraContext.ArtifactId, AspNetAjax$Function.createDelegate(this, this.updatePreviewDiagram_success), AspNetAjax$Function.createDelegate(this, this.updatePreview_failure), dataItem);
                previewAvailable = true;
                $('#diagramPreview').show();
            }
            else {
                $('#diagramPreview').hide();
            }
            if (this.mimeType.substr(0, 'image'.length) == 'image') {
                var url = urlTemplate_attachmentOpenUrl.replace(globalFunctions.artifactIdToken, dataItem.primaryKey);
                previewAvailable = true;
                $('#imagePreview').show();
                $('#imgPreviewHyperLink').attr('href', url);
                $('#imgPreview').attr('src', url);
            }
            else {
                $('#imagePreview').hide();
            }
        }
        if (previewAvailable) {
            $('#noPreview').hide();
        }
        else {
            $('#noPreview').show();
            $('#codePreview').hide();
            $('#imagePreview').hide();
            $('#htmlPreview').hide();
            $('#htmlPreviewIframe').hide();
        }
        $find(tabControl_id).updateHasData('tabPreview', previewAvailable);
    },
    updatePreview_success: function (preview, dataItem) {
        var codePreview = $get('codePreview');
        var extension = dataItem.Fields.Filename.textValue.split('.').pop();
        syntaxHighlighting.highlightElement(preview, extension, codePreview, true);
    },
    updatePreview_failure: function (ex) {
        $('#noPreview').show();
        $('#codePreview').hide();
        $('#imagePreview').hide();
        $('#htmlPreview').hide();
        $('#htmlPreviewIframe').hide();
        $('#diagramPreview').hide();
        document.getElementById("diagramPreview-preview").innerHTML = "";
    },
    updatePreviewMarkdown_success: function (htmlString, dataItem) {
        var thisRef = this;
        var hasStyleTag = htmlString.match(/<style[^>]*>[.\S\s\n]*?<\/style>/gm);
        if (hasStyleTag) {
            $('#htmlPreview').hide();
            $('#htmlPreviewIframe').show();
            var htmlPreviewIframe = $get('htmlPreviewIframe');
            htmlPreviewIframe.srcdoc = htmlString;
            globalFunctions.cleanHtml(htmlPreviewIframe);
            var newHeight = (htmlPreviewIframe.contentWindow.document.body.scrollHeight + 50) + 'px';
            if (htmlPreviewIframe.style.height != newHeight) {
                htmlPreviewIframe.style.height = newHeight;
            }
        }
        else {
            $('#htmlPreview').show();
            $('#htmlPreviewIframe').hide();
            var htmlPreview = $get('htmlPreview');
            globalFunctions.clearContent(htmlPreview);
            htmlPreview.innerHTML = htmlString;
            globalFunctions.cleanHtml(htmlPreview);
        }
    },
    updatePreviewDiagram_success: function (preview, dataItem) {
        var diagramType = "default";
        switch (this.mimeType) {
            case 'application/x-diagram':
                diagramType = "default";
                break;
            case 'application/x-orgchart':
                diagramType = "org";
                break;
            case 'application/x-mindmap':
                diagramType = "mindmap";
                break;
        }
        document.getElementById("diagramPreview-preview").innerHTML = "";
        var diagram = new dhx.Diagram("diagramPreview-preview", {
            type: diagramType
        });
        if (preview) {
            diagram.data.parse(JSON.parse(JSON.stringify(preview)));
            document.getElementById('diagramPreviewExportPng').addEventListener("click", function () { return diagram.export.png(); });
            document.getElementById('diagramPreviewExportPdf').addEventListener("click", function () { return diagram.export.pdf(); });
        }
    },
    displayVersionsGrid: function (attachmentId, isAuthorizedToModify) {
        ReactDOM.render(React.createElement(DocumentVersionGrid, { domId: this.versionGridId, projectId: SpiraContext.ProjectId, attachmentId: attachmentId, headers: this.versionHeaders, uploadButtonLegend: this.uploadButton, uploadClickHandler: this.uploadClickHandler, messageBoxId: this.messageBoxId, makeActiveLegend: this.makeActiveButton, deleteLegend: this.deleteButton, attachmentTypeId: this.attachmentTypeId, ref: function (rct_comp_documentVersionGrid) { window.rct_comp_documentVersionGrid = rct_comp_documentVersionGrid; } }), document.getElementById(this.versionGridId));
    },
    uploadFile: function (file, attachmentId, description, version, makeActive) {
        if (file.size <= 0) {
            alert(resx.FileUpload_AttachmentEmpty);
            return;
        }
        if (file.size > SpiraContext.MaxAllowedContentLength) {
            alert(resx.FileUpload_AttachmentTooLarge.replace('{0}', (SpiraContext.MaxAllowedContentLength / 1024)));
            return;
        }
        this.uploadFile_details = {
            filename: file.name,
            attachmentId: attachmentId,
            description: description,
            version: version,
            makeActive: makeActive,
        };
        globalFunctions.display_spinner();
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = AspNetAjax$Function.createDelegate(this, this.uploadFile_shipOff);
    },
    uploadFile_shipOff: function (event) {
        var result = event.target.result;
        Inflectra.SpiraTest.Web.Services.Ajax.DocumentVersionService.DocumentVersion_UploadFile(SpiraContext.ProjectId, this.uploadFile_details.attachmentId, this.uploadFile_details.filename, this.uploadFile_details.description, this.uploadFile_details.version, result, this.uploadFile_details.makeActive, AspNetAjax$Function.createDelegate(this, this.uploadFile_success), AspNetAjax$Function.createDelegate(this, this.uploadFile_failure));
    },
    uploadFile_success: function (newId) {
        globalFunctions.hide_spinner();
        $find(this.dlgUploadNewVersion_id).close();
        accessReact('rct_comp_documentVersionGrid', 'reload');
    },
    uploadFile_failure: function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(msgUploadMessage_id), exception);
    }
};
var DocumentVersionGrid = (function (_super) {
    __extends(DocumentVersionGrid, _super);
    function DocumentVersionGrid(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            items: [],
            isAuthorizedToModify: false
        };
        _this.loadData = _this.loadData.bind(_this);
        _this.reload = _this.reload.bind(_this);
        _this.uploadVersion = _this.uploadVersion.bind(_this);
        _this.loadData_success = _this.loadData_success.bind(_this);
        return _this;
    }
    DocumentVersionGrid.prototype.componentDidMount = function () {
        this.loadData(this.props.attachmentId);
    };
    DocumentVersionGrid.prototype.componentWillReceiveProps = function (nextProps) {
        if (this.props.attachmentId != nextProps.attachmentId) {
            this.loadData(nextProps.attachmentId);
        }
    };
    DocumentVersionGrid.prototype.reload = function () {
        this.loadData(this.props.attachmentId);
    };
    DocumentVersionGrid.prototype.loadData = function (attachmentId) {
        globalFunctions.display_spinner();
        var self = this;
        Inflectra.SpiraTest.Web.Services.Ajax.DocumentVersionService.DocumentVersion_RetrieveVersions(this.props.projectId, attachmentId, self.loadData_success, self.loadData_failure);
    };
    DocumentVersionGrid.prototype.loadData_success = function (items) {
        globalFunctions.hide_spinner();
        var ajxFormManager = $find(ajxFormManager_id);
        this.setState({
            items: items,
            isAuthorizedToModify: globalFunctions.isAuthorizedToModifyCurrentArtifact(globalFunctions.artifactTypeEnum.document, ajxFormManager)
        });
        SpiraContext.uiState.documentMaxVersionNumber = items.length ? Math.max.apply(Math, items.map(function (x) { return x.Fields.VersionNumber.textValue; })) : 0;
        $find(ajxFormManager_id).load_data();
    };
    DocumentVersionGrid.prototype.loadData_failure = function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(this.props.messageBoxId), exception);
    };
    DocumentVersionGrid.prototype.set_disabled = function () {
        this.setState({ isAuthorizedToModify: false });
    };
    DocumentVersionGrid.prototype.set_enabled = function () {
        this.setState({ isAuthorizedToModify: true });
    };
    DocumentVersionGrid.prototype.uploadVersion = function () {
        this.props.uploadClickHandler();
    };
    DocumentVersionGrid.prototype.render = function () {
        return (React.createElement(React.Fragment, null,
            React.createElement("div", { class: "TabControlHeader my-10 border-bottom-0 d-flex align-items-center" },
                React.createElement("div", { className: "btn-group ", role: "group" },
                    React.createElement("button", { type: "button", id: "DocumentVersionGrid_Refresh", class: "btn btn-refreshDefault", onClick: this.reload },
                        React.createElement("span", { class: "me-1 ti ti-refresh vm-midgrey" }),
                        resx.Global_Refresh)),
                this.props.attachmentTypeId == globalFunctions.attachmentTypeEnum.file && this.state.isAuthorizedToModify ?
                    React.createElement("div", { className: "btn-group ", role: "group" },
                        React.createElement("button", { type: "button", id: "DocumentVersionGrid_UploadVersion", class: "btn primary-button", onClick: this.uploadVersion },
                            React.createElement("span", { class: "fas fa-upload mr3" }),
                            this.props.uploadButtonLegend))
                    : null),
            React.createElement("table", { className: "DataGrid w-100" },
                React.createElement(DocumentVersionGridHead, { headers: this.props.headers }),
                React.createElement(DocumentVersionGridBody, { isAuthorizedToModify: this.state.isAuthorizedToModify, loadData: this.loadData, items: this.state.items, projectId: this.props.projectId, attachmentId: this.props.attachmentId, messageBoxId: this.props.messageBoxId, makeActiveLegend: this.props.makeActiveLegend, deleteLegend: this.props.deleteLegend }))));
    };
    return DocumentVersionGrid;
}(React.Component));
function DocumentVersionGridHead(props) {
    return (React.createElement("thead", null,
        React.createElement("tr", { className: "Header" },
            React.createElement("th", { className: "priority2" }, props.headers[0]),
            React.createElement("th", { className: "priority1" }, props.headers[1]),
            React.createElement("th", { className: "priority1" }, props.headers[2]),
            React.createElement("th", { className: "priority2" }, props.headers[3]),
            React.createElement("th", { className: "priority4" }, props.headers[4]),
            React.createElement("th", { className: "priority4" }, props.headers[5]),
            React.createElement("th", { className: "priority3 ws-nowrap" },
                props.headers[6],
                React.createElement("span", { className: "fas fa-sort-down", style: { paddingLeft: '3px' } })),
            React.createElement("th", null, props.headers[7]))));
}
function DocumentVersionGridBody(props) {
    return (React.createElement("tbody", null, props.items.map(function (item, i) {
        return React.createElement(DocumentVersionGridRow, { key: i, item: item, loadData: props.loadData, messageBoxId: props.messageBoxId, projectId: props.projectId, attachmentId: props.attachmentId, isAuthorizedToModify: props.isAuthorizedToModify, makeActiveLegend: props.makeActiveLegend, deleteLegend: props.deleteLegend });
    })));
}
var DocumentVersionGridRow = (function (_super) {
    __extends(DocumentVersionGridRow, _super);
    function DocumentVersionGridRow(props) {
        var _this = _super.call(this, props) || this;
        _this.makeActive = _this.makeActive.bind(_this);
        _this.makeActive_success = _this.makeActive_success.bind(_this);
        _this.deleteVersion = _this.deleteVersion.bind(_this);
        _this.deleteVersion_success = _this.deleteVersion_success.bind(_this);
        return _this;
    }
    DocumentVersionGridRow.prototype.componentDidMount = function () {
        globalFunctions.cleanHtml(this.refs.versionDescription);
    };
    DocumentVersionGridRow.prototype.makeActive = function () {
        globalFunctions.display_spinner();
        var self = this;
        Inflectra.SpiraTest.Web.Services.Ajax.DocumentVersionService.DocumentVersion_MakeActive(this.props.projectId, this.props.item.primaryKey, self.makeActive_success, self.makeActive_failure);
    };
    DocumentVersionGridRow.prototype.makeActive_success = function () {
        globalFunctions.hide_spinner();
        this.props.loadData(this.props.attachmentId);
        $find(ajxFormManager_id).load_data();
    };
    DocumentVersionGridRow.prototype.makeActive_failure = function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(this.props.messageBoxId), exception);
    };
    DocumentVersionGridRow.prototype.deleteVersion = function () {
        if (confirm(resx.DocumentDetails_DeleteVersionConfirm)) {
            globalFunctions.display_spinner();
            var self = this;
            Inflectra.SpiraTest.Web.Services.Ajax.DocumentVersionService.DocumentVersion_Delete(this.props.projectId, this.props.item.primaryKey, self.deleteVersion_success, self.deleteVersion_failure);
        }
    };
    DocumentVersionGridRow.prototype.deleteVersion_success = function () {
        globalFunctions.hide_spinner();
        this.props.loadData(this.props.attachmentId);
    };
    DocumentVersionGridRow.prototype.deleteVersion_failure = function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(this.props.messageBoxId), exception);
    };
    DocumentVersionGridRow.prototype.render = function () {
        var that = this;
        return (React.createElement("tr", null,
            React.createElement("td", { className: "text-center priority2" },
                React.createElement("span", { className: "fas fa-check", style: { display: (this.props.item.Fields.IsCurrent.textValue == 'Y') ? 'inline' : 'none' } })),
            React.createElement("td", { className: "priority1 ws-nowrap" },
                React.createElement("img", { className: "w4 h4", src: SpiraContext.BaseThemeUrl + 'Images/' + this.props.item.Fields.Filetype.textValue, title: this.props.item.Fields.Filetype.tooltip }),
                React.createElement("span", { className: "pr2" }),
                React.createElement("a", { className: "external-link", href: urlTemplate_attachmentVersionOpenUrl.replace(globalFunctions.artifactIdToken, this.props.item.primaryKey), target: "_blank" }, this.props.item.Fields.Filename.textValue)),
            React.createElement("td", { className: "priority1 ws-nowrap" }, this.props.item.Fields.VersionNumber.textValue),
            React.createElement("td", { className: "priority2", ref: "versionDescription", dangerouslySetInnerHTML: { __html: filterXSS(this.props.item.Fields.Description.textValue, filterXssInlineStyleOptions) } }),
            React.createElement("td", { className: "priority4 ws-nowrap" }, this.props.item.Fields.Size.textValue),
            React.createElement("td", { className: "priority4 ws-nowrap" }, this.props.item.Fields.AuthorId.textValue),
            React.createElement("td", { className: "priority3 ws-nowrap" },
                React.createElement("span", { className: "has-tooltip" },
                    this.props.item.Fields.UploadDate.textValue,
                    React.createElement("span", { className: "is-tooltip" }, globalFunctions.parseJsonDate(this.props.item.Fields.UploadDate.dateValue).toString()))),
            React.createElement("td", null, this.props.item.Fields.IsCurrent.textValue == 'N' && this.props.isAuthorizedToModify ?
                React.createElement("div", { className: "d-flex align-items-center gap-6", role: "group" },
                    React.createElement("button", { type: "button", className: "btn border-0 fs-14 fw-normal", onClick: this.makeActive }, this.props.makeActiveLegend),
                    React.createElement("button", { type: "button", className: " btn border-0 fs-14 fw-normal", onClick: this.deleteVersion },
                        React.createElement("div", { class: "d-flex align-items-center gap-1 vm-darkgrey" },
                            React.createElement("img", { src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/Planning/Delete.svg", alt: "", class: "w-h-16" }),
                            this.props.deleteLegend)))
                : null)));
    };
    return DocumentVersionGridRow;
}(React.Component));
//# sourceMappingURL=DocumentDetails.js.map