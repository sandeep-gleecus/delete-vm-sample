INSERT INTO tst_user_collection ([name], [active_yn])
VALUES
	('ProjectGroupHome.General', 'Y'),
	('Administration.PortfolioList.Filters', 'Y'),
	('Administration.PortfolioList.General', 'Y'),
	('MyPage.RecentWorkspaces', 'Y'),
	('MyPage.RecentArtifacts', 'Y')
