var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var GlobalNavigation = (function (_super) {
    __extends(GlobalNavigation, _super);
    function GlobalNavigation(props) {
        var _a;
        var _this = _super.call(this, props) || this;
        console.log("Props--" + props);
        _this.enum = {
            workspaceAdminClasses: "mx2 fs-66 o-50 v-super",
            urlType: {
                workspace: "workspaceUrl",
                artifact: "artifactUrl"
            },
            searchStorage: "searchHistory",
            searchHistoryMax: 10,
        };
        _this.supportsCssVars = typeof CSS != "undefined" && CSS.supports('color', 'var(--fake-var)');
        _this.state = {
            workspaceDefaultText: resx.Global_ChooseWorkspace,
            workspaceList: [],
            workspaceListIsOpen: false,
            workspaceHidden: [],
            workspaceOnDashboard: _this.workspaceOnDashboard(SpiraContext.Navigation.currentLocation),
            workspaceCurrent: "",
            workspaceCurrentId: "",
            workspaceLoading: false,
            artifactList: [],
            artifactListIsOpen: false,
            artifactHidden: [],
            artifactParent: {},
            userIcon: {},
            userList: [],
            userColorScheme: "auto",
            myPageLoading: false,
            reportsButton: null,
            reportsLoading: false,
            searchHistory: [],
            searchTerm: "",
            searchIsOpen: false,
            adminMenuShow: false,
            adminMenuPosition: "global-nav",
            spinnerShow: 0,
            currentLocation: SpiraContext.Navigation.currentLocation,
            navMobileIsOpen: false,
        };
        _this.workspaceDrop = React.createRef();
        _this.artifactDrop = React.createRef();
        _this.userDrop = React.createRef();
        _this.workspaceCreateList = _this.workspaceCreateList.bind(_this);
        _this.workspaceSetExpanded = _this.workspaceSetExpanded.bind(_this);
        _this.artifactListCallback = _this.artifactListCallback.bind(_this);
        _this.artifactCreateTree = _this.artifactCreateTree.bind(_this);
        _this.artifactsSetExpanded = _this.artifactsSetExpanded.bind(_this);
        _this.userIcon = _this.userIcon.bind(_this);
        _this.userCreateList = _this.userCreateList.bind(_this);
        _this.userSetColorScheme = _this.userSetColorScheme.bind(_this);
        _this.userSetColorSchemeAuto = _this.userSetColorSchemeAuto.bind(_this);
        _this.userToggleColorScheme = _this.userToggleColorScheme.bind(_this);
        _this.expandingToggle = _this.expandingToggle.bind(_this);
        _this.setListInfo = _this.setListInfo.bind(_this);
        _this.handleOpenLink = _this.handleOpenLink.bind(_this);
        _this.adminToggleMenu = _this.adminToggleMenu.bind(_this);
        _this.adminMenuOnBlur = _this.adminMenuOnBlur.bind(_this);
        _this.adminMenuClose = _this.adminMenuClose.bind(_this);
        _this.searchInput = React.createRef();
        _this.searchToggleOpen = _this.searchToggleOpen.bind(_this);
        _this.closeRecentSearch = _this.closeRecentSearch.bind(_this);
        _this.searchInit = _this.searchInit.bind(_this);
        _this.searchKeyPress = _this.searchKeyPress.bind(_this);
        _this.searchTermUpdate = _this.searchTermUpdate.bind(_this);
        _this.wholeNavMobileToggle = _this.wholeNavMobileToggle.bind(_this);
        _this.updateDropStatus = _this.updateDropStatus.bind(_this);
        _this.kbCodes = {
            codes: (_a = {
                    showGlossary: { term: "?" }
                },
                _a[globalFunctions.artifactTypeEnum.requirement] = { term: "n r q" },
                _a[globalFunctions.artifactTypeEnum.planningBoard] = { term: "n p b" },
                _a[globalFunctions.artifactTypeEnum.programPlanningBoard] = { term: "n p b" },
                _a[globalFunctions.artifactTypeEnum.release] = { term: "n r l" },
                _a[globalFunctions.artifactTypeEnum.programReleases] = { term: "n r l" },
                _a[globalFunctions.artifactTypeEnum.document] = { term: "n d c" },
                _a[globalFunctions.artifactTypeEnum.testCase] = { term: "n t c" },
                _a[globalFunctions.artifactTypeEnum.testSet] = { term: "n t s" },
                _a[globalFunctions.artifactTypeEnum.testRun] = { term: "n t r" },
                _a[globalFunctions.artifactTypeEnum.automationHost] = { term: "n a h" },
                _a[globalFunctions.artifactTypeEnum.testConfigurationSet] = { term: "n t n" },
                _a[globalFunctions.artifactTypeEnum.incident] = { term: "n i n" },
                _a[globalFunctions.artifactTypeEnum.programIncidents] = { term: "n i n" },
                _a[globalFunctions.artifactTypeEnum.task] = { term: "n t k" },
                _a[globalFunctions.artifactTypeEnum.risk] = { term: "n r k" },
                _a[globalFunctions.artifactTypeEnum.resource] = { term: "n u s" },
                _a[globalFunctions.artifactTypeEnum.sourceCode] = { term: "n s c" },
                _a[globalFunctions.artifactTypeEnum.sourceCodeRevisions] = { term: "n c o" },
                _a[globalFunctions.artifactTypeEnum.pullRequests] = { term: "n p r" },
                _a)
        };
        return _this;
    }
    GlobalNavigation.prototype.onShowAdmin = function () {
        if (document.getElementById('sidebar-menu')) {
            var menuItems = [
                { title: 'Requirements', icon: "Requirements.svg" },
                { title: 'Releases', icon: "Release.svg" },
                { title: 'Documents', icon: "Document.svg" },
                { title: 'Test Cases', icon: "TestCase.svg" },
                { title: 'Incidents', icon: "Incident.svg" },
                { title: 'Tasks', icon: "Task.svg" },
                { title: 'Risks', icon: "Risk.svg" },
                { title: 'Custom Properties', icon: "CustomProperties.svg" },
                { title: 'Notifications', icon: "Notification.svg" },
                { title: 'Workspaces', icon: "Workspace.svg" },
                { title: 'Users', icon: "Users.svg" },
                { title: 'System', icon: "System.svg" },
                { title: 'Integration', icon: "Integration.svg" },
                { title: 'Reporting', icon: "Reporting.svg" },
                { title: 'Audit Trail', icon: "Audit.svg" },
            ];
            ReactDOM.render(React.createElement(AdminMenu, { currentLocation: this.state.currentLocation, currentProjectId: SpiraContext.ProjectId, currentProgramId: SpiraContext.ProjectGroupId, currentTemplateId: SpiraContext.ProjectTemplateId, system: this.props.data.adminNavigation.system, workspaceMain: this.adminSetMainData(this.props.workspaceType), workspaceMainType: this.adminSetMainType(this.props.workspaceType), workspaceSecondary: this.adminSetSecondaryData(this.props.workspaceType), workspaceSecondaryType: this.adminSetSecondaryType(this.props.workspaceType), workspaceEnums: this.props.workspaceEnums, isSystemAdmin: this.props.isSysAdmin, isReportAdmin: this.props.isReportAdmin, wrapperId: "global-admin-nav", sectionClasses: "", sectionTitleClasses: "sidemenu-titlebox", sectionTitleLinkClasses: "sidemenu-title", subSectionClasses: "submenu-link-list", subSectionWrapperClasses: "df flex-wrap", linkClasses: "submenu-link", menuItems: menuItems }), document.getElementById("sidebar-menu"));
        }
    };
    GlobalNavigation.prototype.componentWillMount = function () {
        this.workspaceSet();
        this.workspaceCreateList(this.workspaceSetExpanded);
        this.artifactCreateTree(this.artifactListCallback);
        this.setState({ userIcon: this.userIcon() });
        this.userCreateList();
        this.userColorSchemeGetLocal();
        this.searchGetLocalTerms();
        this.onboardingShow(true);
        this.onboardingRegisterPage();
        this.onShowAdmin();
    };
    GlobalNavigation.prototype.workspaceCreateList = function (callback) {
        var _this = this;
        var _a = this.props.data, portfolios = _a.portfolios, programs = _a.programs, programIdsByOwner = _a.programIdsByOwner, projects = _a.projects, projectIdsByOwner = _a.projectIdsByOwner, templates = _a.templates;
        var list = [];
        var programsToUse = programs;
        var portfoliosToUse = portfolios && portfolios.length ? portfolios : [];
        if (this.props.isPortfolioEnabled && this.props.isEnterpriseViewer) {
            var enterpriseMenuItem = this.workspaceCreateEnterpriseItem(SpiraContext.IsSystemAdmin);
            list.push(enterpriseMenuItem);
        }
        var portfolioItems = null;
        if (this.props.isPortfolioEnabled) {
            var orphanPrograms_1 = programs.filter(function (x) { return !x.portfolioId; }).map(function (x) { return x.id; });
            if (orphanPrograms_1 && orphanPrograms_1.length) {
                portfoliosToUse.push({
                    id: -1,
                    name: resx.GlobalNavigation_DefaultPortfolio,
                    programIds: orphanPrograms_1
                });
                programsToUse = programs.map(function (x) {
                    if (orphanPrograms_1.indexOf(x.id) >= 0) {
                        x.portfolioId = -1;
                    }
                    return x;
                });
            }
            portfolioItems = portfoliosToUse
                .sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; })
                .map(function (pf) {
                var programsInPortfolio = programsToUse.filter(function (x) { return x.portfolioId === pf.id; });
                var programIdsInPortfolio = programsInPortfolio.map(function (x) { return x.id; });
                var projectListIdsInPortfolio = projects
                    .filter(function (x) { return programIdsInPortfolio.indexOf(x.programId) >= 0; })
                    .map(function (x) { return _this.props.workspaceEnums.product + "-" + x.id; });
                var programListIdsInPortfolio = programsInPortfolio.map(function (x) { return _this.props.workspaceEnums.program + "-" + x.id; });
                var children = projectListIdsInPortfolio.concat.apply(projectListIdsInPortfolio, programListIdsInPortfolio);
                return _this.workspaceCreatePortfolioItem(pf, children);
            });
        }
        var programItems = programsToUse
            .sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; })
            .map(function (pg) {
            var children = projects
                .filter(function (x) { return x.programId === pg.id; })
                .map(function (x) { return _this.props.workspaceEnums.product + "-" + x.id; });
            return _this.workspaceCreateProgramItem(pg, programIdsByOwner, children, _this.props.isPortfolioEnabled);
        });
        var projectItems = projects
            .sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; })
            .map(function (p) { return _this.workspaceCreateProjectItem(p, projectIdsByOwner, _this.props.isPortfolioEnabled); });
        if (this.props.isPortfolioEnabled) {
            var _loop_1 = function () {
                var pf = portfolioItems[i];
                list.push(pf);
                var programsInPortfolio = programItems.filter(function (pg) { return pf.children && pf.children.indexOf(pg.listId) >= 0; });
                var _loop_3 = function () {
                    var pg = programsInPortfolio[j];
                    list.push(pg);
                    var children = projectItems.filter(function (p) { return pg.children && pg.children.indexOf(p.listId) >= 0; });
                    list = list.concat.apply(list, children);
                };
                for (var j = 0; j < programsInPortfolio.length; j++) {
                    _loop_3();
                }
            };
            for (var i = 0; i < portfolioItems.length; i++) {
                _loop_1();
            }
        }
        else {
            var _loop_2 = function () {
                var pg = programItems[i];
                var children = projectItems.filter(function (p) { return pg.children && pg.children.indexOf(p.listId) >= 0; });
                list.push(pg);
                list = list.concat.apply(list, children);
            };
            for (var i = 0; i < programItems.length; i++) {
                _loop_2();
            }
        }
        if (templates && templates.length) {
            list.push(this.workspaceCreateTemplateWrapper(templates));
            var templatesItems = templates
                .sort(function (a, b) { return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1; })
                .map(function (t) { return _this.workspaceCreateTemplateItem(t); });
            list = list.concat.apply(list, templatesItems);
        }
        this.setState({ workspaceList: list }, function () { return callback && callback(); });
    };
    GlobalNavigation.prototype.workspaceSetExpanded = function () {
        this.expandingToggle(JSON.parse(localStorage.getItem("workspaceHidden")), true, "workspaceList", "workspaceHidden");
    };
    GlobalNavigation.prototype.workspaceOnDashboard = function (location) {
        return location === globalFunctions.artifactTypeEnum.projectHome || location === globalFunctions.artifactTypeEnum.programHome;
    };
    GlobalNavigation.prototype.workspaceSet = function () {
        var prefix = this.props.workspaceType;
        var suffix = null;
        switch (this.props.workspaceType) {
            case this.props.workspaceEnums.program:
                suffix = SpiraContext.ProjectGroupId;
                break;
            case this.props.workspaceEnums.product:
                suffix = SpiraContext.ProjectId;
                break;
            case this.props.workspaceEnums.template:
                suffix = SpiraContext.ProjectTemplateId;
                break;
            case this.props.workspaceEnums.portfolio:
                suffix = SpiraContext.PortfolioId;
                break;
            case this.props.workspaceEnums.enterprise:
            default:
                suffix = 1;
                if (this.props.data.currentLocation == globalFunctions.artifactTypeEnum.administration) {
                    prefix = this.props.data.currentLocation;
                    this.setState({ workspaceDefaultText: resx.Global_SystemAdministration });
                }
                break;
        }
        if (prefix && suffix) {
            this.setState({
                workspaceCurrent: "".concat(prefix, "-").concat(suffix),
                workspaceCurrentId: suffix
            });
        }
    };
    GlobalNavigation.prototype.workspaceUrl = function () {
        var _this = this;
        if (this.state.workspaceCurrent && this.state.workspaceList.length) {
            var filteredWorkspaces = this.state.workspaceList.filter(function (x) { return x.listId == _this.state.workspaceCurrent; });
            if (filteredWorkspaces.length) {
                return filteredWorkspaces[0].workspaceUrl;
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    };
    GlobalNavigation.prototype.workspaceIconName = function (workspaceEnum) {
        if (workspaceEnum) {
            switch (workspaceEnum) {
                case this.props.workspaceEnums.enterprise:
                    return "org-Enterprise.svg";
                case this.props.workspaceEnums.portfolio:
                    return "org-Portfolio.svg";
                case this.props.workspaceEnums.template:
                    return "org-Template-outline.svg";
                case this.props.workspaceEnums.program:
                    return "org-Program-outline.svg";
                case this.props.workspaceEnums.product:
                default:
                    return "org-Project-outline.svg";
            }
        }
    };
    GlobalNavigation.prototype.workspaceCreateEnterpriseItem = function (isAdmin) {
        return {
            ariaLabel: "Global Navigation Enterprise View",
            domIdPrefix: "globalNav_workspaceDropdown_enterprise_",
            imageClasses: "global-drop-icon pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "NewImages/GlobalNavigation/Enterprise.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item fs-110",
            listId: this.props.workspaceEnums.enterprise + "-1",
            name: resx.Global_Enterprise,
            secondaryGlyph: isAdmin ? this.enum.workspaceAdminClasses : null,
            title: resx.GlobalNavigation_TooltipEnterprise,
            type: this.props.workspaceEnums.enterprise,
            url: globalFunctions.replaceBaseUrl("~/Enterprise/Default.aspx"),
            workspaceUrl: this.props.data.adminUrl
        };
    };
    GlobalNavigation.prototype.workspaceCreatePortfolioItem = function (pf, children) {
        var isPortfolioOwner = this.props.isPortfolioViewer || false;
        var isOnAdminPage = this.state.currentLocation == globalFunctions.artifactTypeEnum.administration;
        var urlToUse = this.state.workspaceOnDashboard || (isOnAdminPage && !isPortfolioOwner) ? this.enum.urlType.workspace : this.enum.urlType.artifact;
        return {
            ariaLabel: "PF:" + pf.id + " - " + pf.name,
            children: children && children.length ? children : null,
            hideChildren: false,
            id: pf.id,
            imageClasses: "global-drop-icon pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "NewImages/GlobalNavigation/Folder.svg",
            isEnabled: isPortfolioOwner,
            linkClasses: "nav-drop-menu-item fs-110",
            listId: this.props.workspaceEnums.portfolio + "-" + pf.id,
            domIdPrefix: "globalNav_workspaceDropdown_portfolio_",
            name: pf.name,
            title: (pf.description ? "(" : "") + "PF:" + pf.id + (isPortfolioOwner ? " - " + resx.Global_Owner : "") + (pf.description ? ") " + pf.description : ""),
            type: this.props.workspaceEnums.portfolio,
            url: globalFunctions.replaceBaseUrl(pf[urlToUse]),
            workspaceUrl: globalFunctions.replaceBaseUrl(pf.workspaceUrl)
        };
    };
    GlobalNavigation.prototype.workspaceCreateProgramItem = function (pg, programIdsByOwner, children, isPortfolioEnabled) {
        var isProgramOwner = programIdsByOwner && programIdsByOwner.length ? globalFunctions.findItemInArray(programIdsByOwner, pg.id) : false;
        var isOnAdminPage = this.state.currentLocation == globalFunctions.artifactTypeEnum.administration;
        var urlToUse = this.state.workspaceOnDashboard || (isOnAdminPage && !isProgramOwner) ? this.enum.urlType.workspace : this.enum.urlType.artifact;
        return {
            ariaLabel: "PG:" + pg.id + " - " + pg.name,
            children: children && children.length ? children : null,
            hideChildren: false,
            id: pg.id,
            imageClasses: "global-drop-icon pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "NewImages/GlobalNavigation/Portfolio.svg",
            indentLevel: isPortfolioEnabled ? 1 : 0,
            isEnabled: pg.isEnabled,
            linkClasses: "nav-drop-menu-item fs-110",
            listId: this.props.workspaceEnums.program + "-" + pg.id,
            domIdPrefix: "globalNav_workspaceDropdown_program_",
            name: pg.name,
            secondaryGlyph: isProgramOwner ? this.enum.workspaceAdminClasses : null,
            title: "PG:" + pg.id + (isProgramOwner ? " - " + resx.Global_Owner : ""),
            type: this.props.workspaceEnums.program,
            url: globalFunctions.replaceBaseUrl(pg[urlToUse]),
            workspaceUrl: globalFunctions.replaceBaseUrl(pg.workspaceUrl),
        };
    };
    GlobalNavigation.prototype.workspaceCreateProjectItem = function (p, projectIdsByOwner, isPortfolioEnabled) {
        var isProjectOwner = projectIdsByOwner && projectIdsByOwner.length ? globalFunctions.findItemInArray(projectIdsByOwner, p.id) : false;
        var isOnAdminPage = this.state.currentLocation == globalFunctions.artifactTypeEnum.administration;
        var urlToUse = this.state.workspaceOnDashboard || (isOnAdminPage && !isProjectOwner) ? this.enum.urlType.workspace : this.enum.urlType.artifact;
        return {
            ariaLabel: "PR:" + p.id + " - " + p.name,
            id: p.id,
            imageClasses: "global-drop-icon pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "NewImages/GlobalNavigation/Group.svg",
            indentLevel: isPortfolioEnabled ? 2 : 1,
            isEnabled: p.isEnabled,
            linkClasses: "nav-drop-menu-item",
            listId: this.props.workspaceEnums.product + "-" + p.id,
            domIdPrefix: "globalNav_workspaceDropdown_product_",
            name: p.name,
            secondaryGlyph: isProjectOwner ? this.enum.workspaceAdminClasses : null,
            title: (p.description ? "(" : "") + "PR:" + p.id + (isProjectOwner ? " - " + resx.Global_Owner : "") + (p.description ? ") " + p.description : ""),
            type: this.props.workspaceEnums.product,
            url: globalFunctions.replaceBaseUrl(p[urlToUse]),
            workspaceUrl: globalFunctions.replaceBaseUrl(p.workspaceUrl),
        };
    };
    GlobalNavigation.prototype.workspaceCreateTemplateWrapper = function (templates) {
        var _this = this;
        return {
            children: templates.map(function (x) { return _this.props.workspaceEnums.template + "-" + x.id; }),
            imageClasses: "global-drop-icon pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "NewImages/GlobalNavigation/Template.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item fs-110",
            listId: this.props.workspaceEnums.template + "-" + 0,
            domIdPrefix: "globalNav_workspaceDropdown_template_",
            hideChildren: false,
            name: resx.Global_Templates,
            type: this.props.workspaceEnums.template,
        };
    };
    GlobalNavigation.prototype.workspaceCreateTemplateItem = function (pt) {
        return {
            ariaLabel: "PT:" + pt.id + " - " + pt.name,
            id: pt.id,
            indentLevel: 1,
            imageClasses: "w4 h4 pr2",
            imageUrl: SpiraContext.BaseThemeUrl + "Images/org-Template-outline.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: this.props.workspaceEnums.template + "-" + pt.id,
            domIdPrefix: "globalNav_workspaceDropdown_template_",
            name: pt.name,
            secondaryGlyph: this.enum.workspaceAdminClasses,
            title: (pt.description ? "(" : "") + "PT:" + pt.id + (pt.description ? ") " + pt.description : ""),
            type: this.props.workspaceEnums.template,
            url: SpiraContext.BaseUrl + "pt/" + pt.id + "/Administration/Default.aspx",
            workspaceUrl: SpiraContext.BaseUrl + "pt/" + pt.id + "/Administration/Default.aspx",
        };
    };
    GlobalNavigation.prototype.workspaceTemplateControlsProduct = function () {
        if (this.props.workspaceType == this.props.workspaceEnums.template) {
            var currentTemplate = this.props.data.templates.filter(function (x) { return x.id == SpiraContext.ProjectTemplateId; });
            if (currentTemplate && currentTemplate.length) {
                var templateProductMatch = currentTemplate[0].projects && currentTemplate[0].projects.length ? currentTemplate[0].projects.filter(function (x) { return x.id == SpiraContext.ProjectId; }) : false;
                return templateProductMatch && templateProductMatch.length ? true : false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    };
    GlobalNavigation.prototype.artifactCreateTree = function (callback) {
        var _this = this;
        var nodes = JSON.parse(JSON.stringify(SpiraContext.Navigation.nodeTree.children)), artifactTypeCode = this.props.workspaceType == this.props.workspaceEnums.program ? globalFunctions.artifactTypeEnum.programHome : globalFunctions.artifactTypeEnum.projectHome;
        var artifactParentNode = nodes.filter(function (x) { return x.id == artifactTypeCode; })[0];
        var artifactList = [];
        if (artifactParentNode && artifactParentNode.children && artifactParentNode.children.length) {
            for (var i = 0; i < artifactParentNode.children.length; i++) {
                var art = artifactParentNode.children[i];
                if (art.id == globalFunctions.artifactTypeEnum.reports) {
                    var button = {
                        id: art.id,
                        url: this.replaceWorkplaceTokenUrl(art.url),
                        name: art.name
                    };
                    this.setState({ reportsButton: button });
                }
                else if (art.children && art.children.length) {
                    var children = art.children.map(function (child) { return _this.artifactCreateItem(child, true, true, false); });
                    var parent_1 = this.artifactCreateItem(art, false, false, true);
                    if (children.length) {
                        parent_1.children = children.map(function (x) { return x.listId; });
                        parent_1.hideChildren = false;
                    }
                    artifactList.push(parent_1);
                    artifactList.push.apply(artifactList, children);
                }
                else if (art.id) {
                    artifactList.push(this.artifactCreateItem(art, true, false, false));
                }
            }
            ;
            artifactParentNode.children = artifactList;
            this.setState({
                artifactParent: artifactParentNode,
                artifactList: artifactList
            }, function () { return callback && callback(); });
        }
    };
    GlobalNavigation.prototype.artifactCreateItem = function (art, hasIcon, isIndented, isParent) {
        var artifactObject = art.id ? globalFunctions.getArtifactTypes(art.id)[0] : null;
        var item = {
            ariaLabel: art.name,
            children: null,
            hideChildren: false,
            imageUrl: hasIcon && artifactObject ? SpiraContext.BaseThemeUrl + artifactObject.image : null,
            imageClasses: "w4 h4 mr3",
            linkClasses: "nav-drop-menu-item" + (isParent ? " fs-125" : ""),
            id: art.id,
            name: art.name,
            url: isParent ? null : this.replaceWorkplaceTokenUrl(art.url),
            listId: isParent ? art.name : art.id,
            domIdPrefix: "globalNav_artifactDropdown_",
            isEnabled: false,
            title: artifactObject && resx["GlobalNavigation_Tooltip" + artifactObject.image.replace("Images/artifact-", "").replace(".svg", "")]
        };
        return item;
    };
    GlobalNavigation.prototype.artifactsSetExpanded = function () {
        this.expandingToggle(JSON.parse(localStorage.getItem("artifactHidden")), true, "artifactList", "artifactHidden");
    };
    GlobalNavigation.prototype.artifactListCallback = function () {
        this.artifactsSetExpanded();
        this.keyboardShortcutsInit();
    };
    GlobalNavigation.prototype.artifactListGetItem = function (artifactId) {
        var match = false;
        if (typeof artifactId != "undefined" || artifactId !== 0) {
            match = this.state.artifactList.map(function (x) { return x.id; }).indexOf(artifactId) >= 0;
        }
        return match;
    };
    GlobalNavigation.prototype.artifactShowDropdown = function () {
        var hasArtifacts = this.state.artifactList && this.state.artifactList.length, notEnterpriseView = this.props.workspaceType != this.props.workspaceEnums.enterprise, notPortfolioView = this.props.workspaceType != this.props.workspaceEnums.portfolio, productMatchesTemplate = this.workspaceTemplateControlsProduct();
        return hasArtifacts && notEnterpriseView && notPortfolioView && productMatchesTemplate;
    };
    GlobalNavigation.prototype.userIcon = function () {
        var userObj = SpiraContext.Navigation.user;
        return {
            name: userObj.fullName,
            nameAsIcon: userObj.firstName && userObj.lastName ? userObj.firstName[0].toUpperCase() + userObj.lastName[0].toUpperCase() : "?",
            hasIcon: userObj.hasIcon || false,
            avatarUrl: userObj.hasIcon ? userObj.avatarUrl : null
        };
    };
    GlobalNavigation.prototype.userCreateList = function () {
        var icon = this.userIcon();
        var userProfileName = React.createElement("div", { className: "df" },
            React.createElement(AvatarIcon, { hasIcon: icon.hasIcon, icon: icon.avatarUrl, iconSize: 6, name: icon.name, nameAsIcon: icon.nameAsIcon, wrapperClasses: "lh-initial mr3" }),
            React.createElement("div", null,
                React.createElement("p", { className: "ma0 pa0 nowrap fs-125" }, SpiraContext.Navigation.user.fullName),
                React.createElement("p", { className: "ma0 pa0", title: SpiraContext.IsSystemAdmin ? "" : SpiraContext.ProjectRole.Description }, SpiraContext.IsSystemAdmin ? "Product Owner" : SpiraContext.ProjectRole.Name)));
        var userProfile = {
            ariaLabel: "Global Navigation My Profile",
            domIdPrefix: "globalNav_userDropdown_profile_",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: globalFunctions.artifactTypeEnum.myProfile.toString(),
            name: userProfileName,
            showTitleInButton: true,
            title: resx.GlobalNavigation_MyProfile,
            url: globalFunctions.replaceBaseUrl(SpiraContext.Navigation.myProfileUrl)
        };
        var timecard = SpiraContext.Navigation.myTimecardUrl && {
            ariaLabel: "Global Navigation My Timecard",
            domIdPrefix: "globalNav_userDropdown_timecard_",
            glyph: "fas fa-stopwatch pr3",
            isEnabled: true,
            name: resx.GlobalNavigation_MyTimecard,
            linkClasses: "nav-drop-menu-item",
            listId: globalFunctions.artifactTypeEnum.myTimecard.toString(),
            title: resx.GlobalNavigation_MyTimecard,
            url: globalFunctions.replaceBaseUrl(SpiraContext.Navigation.myTimecardUrl)
        };
        var keyboard = {
            ariaLabel: "Global Navigation Open Keyboard Shortcuts Help",
            domIdPrefix: "globalNav_userDropdown_shortcuts_",
            glyph: "far fa-keyboard pr3",
            isEnabled: true,
            name: resx.GlobalNavigation_KeyboardShortcuts,
            linkClasses: "nav-drop-menu-item",
            listId: "keyboard",
            dontShowLoader: true,
            url: "javascript:ucGlobalNavigation_displayShortcuts()"
        };
        var onboarding = {
            ariaLabel: "Global Navigation Show Onboarding Tours",
            domIdPrefix: "globalNav_userDropdown_tours_",
            dontShowLoader: true,
            glyph: "far fa-eye pr3",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: "onboarding",
            name: resx.GlobalNavigation_ShowOnboardingTours,
            url: "javascript:window.rct_comp_globalNav.onboardingShow(false)"
        };
        var colorScheme = {
            ariaLabel: "Global Navigation Change Color Scheme",
            domIdPrefix: "globalNav_userDropdown_colorsSCheme_",
            dontShowLoader: true,
            glyph: this.state.userColorScheme == "dark" ? "fas fa-moon pr3" : this.state.userColorScheme == "light" ? "fas fa-sun pr3" : "fas fa-magic pr3",
            id: "default",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: "default",
            name: this.state.userColorScheme == "dark" ? resx.GlobalNavigation_ColorScheme_Dark : this.state.userColorScheme == "light" ? resx.GlobalNavigation_ColorScheme_Light : resx.GlobalNavigation_ColorScheme_Auto,
            title: this.state.userColorScheme == "dark" ? resx.GlobalNavigation_ColorScheme_DarkTitle : this.state.userColorScheme == "light" ? resx.GlobalNavigation_ColorScheme_LightTitle : resx.GlobalNavigation_ColorScheme_AutoTitle,
            url: "javascript:window.rct_comp_globalNav.userToggleColorScheme()"
        };
        var profile = {
            ariaLabel: "Global Navigation Profile",
            domIdPrefix: "globalNav_userDropdown_",
            imageClasses: "pr3",
            imageUrl: this.props.baseThemeUrl + "NewImages/profile.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: "profile",
            name: resx.GlobalNavigation_MyProfile,
            url: globalFunctions.replaceBaseUrl("~/MyProfile.aspx")
        };
        var reportadminSetting = {
            ariaLabel: "Global Navigation Setting",
            domIdPrefix: "globalNav_userDropdown_",
            imageClasses: "pr3",
            imageUrl: this.props.baseThemeUrl + "NewImages/settings.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: "admin_setting",
            name: "resx.AjaxFormManager_AdminSettings",
            url: globalFunctions.replaceBaseUrl("~/Administration/Reports.aspx")
        };
        var adminSetting = {
            ariaLabel: "Global Navigation Setting",
            domIdPrefix: "globalNav_userDropdown_",
            imageClasses: "pr3",
            imageUrl: this.props.baseThemeUrl + "NewImages/settings.svg",
            isEnabled: true,
            linkClasses: "nav-drop-menu-item",
            listId: "admin_setting",
            name: resx.AjaxFormManager_AdminSettings,
            url: globalFunctions.replaceBaseUrl("~/Administration.aspx")
        };
        var logout = {
            ariaLabel: "Global Navigation Logout",
            domIdPrefix: "globalNav_userDropdown_",
            isEnabled: true,
            imageClasses: "pr3",
            imageUrl: this.props.baseThemeUrl + "NewImages/logout.svg",
            linkClasses: "nav-drop-menu-item",
            listId: "logout",
            name: resx.AjaxFormManager_Logout,
            url: globalFunctions.replaceBaseUrl("~/Logout.aspx")
        };
        var list = [];
        list.push(profile);
        if (SpiraContext.IsSystemAdmin && SpiraContext.IsReportAdmin) {
            list.push(adminSetting);
        }
        else if (SpiraContext.IsReportAdmin) {
            list.push(reportadminSetting);
        }
        else if (SpiraContext.IsSystemAdmin) {
            list.push(adminSetting);
        }
        list.push(logout);
        this.setState({ userList: list });
    };
    GlobalNavigation.prototype.userColorSchemeGetLocal = function () {
        if (this.supportsCssVars) {
            var localScheme = document.body.dataset.colorscheme;
            if (localScheme && localScheme != "auto") {
                this.setState({ userColorScheme: localScheme }, this.userCreateList);
                this.userSetColorScheme(localScheme);
            }
            else {
                this.userSetColorScheme("auto");
            }
        }
    };
    ;
    GlobalNavigation.prototype.userSetColorScheme = function (newColorScheme) {
        var systemScheme = window.matchMedia('(prefers-color-scheme: dark)');
        var isSystemSchemeDark = systemScheme.matches;
        var colorSchemeToUse = "";
        if (newColorScheme == "auto") {
            colorSchemeToUse = isSystemSchemeDark ? "dark" : "light";
            systemScheme.addListener(this.userSetColorSchemeAuto);
        }
        else {
            systemScheme.removeListener(this.userSetColorSchemeAuto);
            colorSchemeToUse = newColorScheme;
        }
        document.body.dataset.colorscheme = colorSchemeToUse;
        var companyLogo = document.getElementById("footerCompanyLogo");
        if (companyLogo) {
            if (colorSchemeToUse == "dark") {
                companyLogo.src = companyLogo.src.replace("CompanyLogo.svg", "CompanyLogo_Light.svg");
            }
            else {
                companyLogo.src = companyLogo.src.replace("CompanyLogo_Light.svg", "CompanyLogo.svg");
            }
        }
        this.ckeditorSetColorScheme(colorSchemeToUse, null);
    };
    GlobalNavigation.prototype.userSetColorSchemeAuto = function () {
        if (this.state.userColorScheme = "auto")
            this.userSetColorScheme("auto");
    };
    GlobalNavigation.prototype.userToggleColorScheme = function () {
        var newColorScheme = "";
        newColorScheme = "light";
        this.setState({ userColorScheme: newColorScheme });
        this.userCreateList();
        Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.UserSettings_ColorMode_Set(newColorScheme);
        this.userSetColorScheme(newColorScheme);
    };
    GlobalNavigation.prototype.ckeditorSetColorScheme = function (colorSchemeToUse, noCkeditorChecks) {
        if (colorSchemeToUse == "dark") {
            var ckeditorExists = typeof CKEDITOR != "undefined" && CKEDITOR.status == 'loaded' && CKEDITOR.instances;
            if (noCkeditorChecks || ckeditorExists) {
                if (noCkeditorChecks || $("iframe.cke_wysiwyg_frame").contents().length > 0) {
                    $("iframe.cke_wysiwyg_frame, iframe.inflectra-iframe").contents().find("body").attr("data-colorscheme", "dark");
                }
                else {
                    var counter = 0;
                    var ckEditorCheckStatus = setInterval(function () {
                        counter++;
                        if ($("iframe.cke_wysiwyg_frame").contents().length > 0) {
                            setTimeout(function () { return $("iframe.cke_wysiwyg_frame, iframe.inflectra-iframe").contents().find("body").attr("data-colorscheme", "dark"); }, 500);
                            clearInterval(ckEditorCheckStatus);
                        }
                        else if (counter == 10) {
                            clearInterval(ckEditorCheckStatus);
                        }
                    }, 500);
                }
            }
        }
        else {
            $("iframe.cke_wysiwyg_frame, iframe.inflectra-iframe").contents().find("body").attr("data-colorscheme", "auto");
        }
    };
    GlobalNavigation.prototype.adminToggleMenu = function (location) {
        if (this.props.data.adminUrl) {
            if (!this.state.adminMenuShow) {
                this.adminMenuOpen(location);
            }
            else {
                this.adminMenuClose();
            }
        }
    };
    GlobalNavigation.prototype.adminMenuOpen = function (location) {
        var _this = this;
        if (this.props.data.adminUrl) {
            Mousetrap.bind("escape", function (e) { return _this.adminMenuClose(); });
            this.workspaceDrop.current && this.workspaceDrop.current.menuClose();
            this.artifactDrop.current && this.artifactDrop.current.menuClose();
            this.userDrop.current && this.userDrop.current.menuClose();
            this.setState({
                adminMenuShow: true,
                adminMenuPosition: location && location == "sidebar" ? "sidebar" : "global-nav"
            });
        }
    };
    GlobalNavigation.prototype.adminMenuClose = function () {
        this.setState({ adminMenuShow: false });
        Mousetrap.unbind("escape");
    };
    GlobalNavigation.prototype.adminMenuOnBlur = function (e) {
        var _this = this;
        var target = e.currentTarget;
        setTimeout(function () {
            if (!target.contains(document.activeElement)) {
                _this.adminMenuClose();
            }
        }, 0);
    };
    GlobalNavigation.prototype.adminSetMainData = function (workspaceType) {
        var adminNavigation = this.props.data.adminNavigation;
        var mainData = null;
        switch (workspaceType) {
            case this.props.workspaceEnums.product:
                mainData = adminNavigation.project || null;
                break;
            case this.props.workspaceEnums.template:
                var showProject = this.templateAndProjectMatch() && adminNavigation.project;
                var showTemplate = !showProject && adminNavigation.template;
                mainData = showProject ? adminNavigation.project : showTemplate ? adminNavigation.template : null;
                break;
            case this.props.workspaceEnums.program:
                mainData = adminNavigation.program || null;
                break;
        }
        return mainData;
    };
    GlobalNavigation.prototype.adminSetMainType = function (workspaceType) {
        var adminNavigation = this.props.data.adminNavigation;
        var mainType = workspaceType;
        if (workspaceType == this.props.workspaceEnums.template && adminNavigation.project && this.templateAndProjectMatch()) {
            mainType = this.props.workspaceEnums.product;
        }
        return mainType;
    };
    GlobalNavigation.prototype.adminSetSecondaryData = function (workspaceType) {
        var adminNavigation = this.props.data.adminNavigation;
        var secondaryData = null;
        switch (workspaceType) {
            case this.props.workspaceEnums.program:
                secondaryData = null;
                break;
            case this.props.workspaceEnums.product:
            case this.props.workspaceEnums.template:
                secondaryData = adminNavigation.project && adminNavigation.template && this.templateAndProjectMatch() ? adminNavigation.template : null;
                break;
        }
        return secondaryData;
    };
    GlobalNavigation.prototype.adminSetSecondaryType = function (workspaceType) {
        var adminNavigation = this.props.data.adminNavigation;
        var secondaryType = workspaceType;
        if (workspaceType == this.props.workspaceEnums.product && adminNavigation.template && this.templateAndProjectMatch()) {
            secondaryType = this.props.workspaceEnums.template;
        }
        return secondaryType;
    };
    GlobalNavigation.prototype.templateAndProjectMatch = function (templateId, projectId) {
        if (templateId === void 0) { templateId = SpiraContext.ProjectTemplateId; }
        if (projectId === void 0) { projectId = SpiraContext.ProjectId; }
        var templates = this.props.data.templates;
        var currentTemplate = templates.filter(function (x) { return x.id === templateId; });
        var templateMatchesCurrentProject = false;
        if (currentTemplate && currentTemplate.length) {
            var templatesAttachedToCurrentProject = currentTemplate[0].projects.filter(function (x) { return x.id == projectId; });
            templateMatchesCurrentProject = templatesAttachedToCurrentProject && templatesAttachedToCurrentProject.length ? true : false;
        }
        return templateMatchesCurrentProject;
    };
    GlobalNavigation.prototype.expandingToggle = function (parentIds, newStatus, stateName, stateHiddenName) {
        var _a;
        var arrayCopy = this.state[stateName] ? JSON.parse(JSON.stringify(this.state[stateName])) : null;
        if (parentIds && Array.isArray(parentIds) && parentIds.length && Array.isArray(arrayCopy) && stateName && stateHiddenName) {
            var childrenArrays = arrayCopy.filter(function (x) { return parentIds.indexOf(x.listId) >= 0; }).map(function (y) { return y.children; });
            var childrenIds_1 = [];
            for (var i = 0; i < childrenArrays.length; i++) {
                childrenIds_1.push.apply(childrenIds_1, childrenArrays[i]);
            }
            var arrayToggled = arrayCopy.map(function (item) {
                if (parentIds.indexOf(item.listId) >= 0) {
                    item.hideChildren = newStatus;
                }
                if (childrenIds_1.indexOf(item.listId) >= 0) {
                    item.hide = newStatus;
                    if (item.children) {
                        item.hideChildren = newStatus;
                    }
                }
                return item;
            });
            this.setState((_a = {}, _a[stateName] = arrayToggled, _a));
            this.setListInfo(parentIds, stateHiddenName);
        }
    };
    GlobalNavigation.prototype.setListInfo = function (parentIds, stateListName) {
        var _a;
        if (parentIds && Array.isArray(parentIds) && parentIds.length && this.state[stateListName]) {
            var arrayCopy = JSON.parse(JSON.stringify(this.state[stateListName]));
            for (var i = 0; i < parentIds.length; i++) {
                var arrIndex = arrayCopy.indexOf(parentIds[i]);
                if (arrIndex >= 0) {
                    arrayCopy.splice(arrIndex, 1);
                }
                else {
                    arrayCopy.push(parentIds[i]);
                }
            }
            ;
            this.setState((_a = {}, _a[stateListName] = arrayCopy, _a));
            localStorage.setItem(stateListName, JSON.stringify(arrayCopy));
        }
    };
    GlobalNavigation.prototype.replaceWorkplaceTokenUrl = function (url) {
        var token = this.props.workspaceType == this.props.workspaceEnums.program ? "{projGroupId}" : "{projId}";
        var workspaceId = this.props.workspaceType == this.props.workspaceEnums.program ? SpiraContext.ProjectGroupId : SpiraContext.ProjectId;
        return url ? url.replace(token, workspaceId) : url;
    };
    GlobalNavigation.prototype.searchGetLocalTerms = function () {
        var localTerms = JSON.parse(localStorage.getItem(this.enum.searchStorage));
        if (localTerms && localTerms.length > 0)
            this.setState({ searchHistory: localTerms });
    };
    GlobalNavigation.prototype.searchToggleOpen = function (e) {
        var _this = this;
        var newValue = e && e.target ? e.target.checked : !this.state.searchIsOpen;
        this.setState({ searchIsOpen: newValue }, function () {
            if (_this.state.searchIsOpen)
                setTimeout(function () { _this.searchInput.current.focus(); }, 500);
        });
    };
    GlobalNavigation.prototype.closeRecentSearch = function () {
        this.setState({ searchIsOpen: false });
    };
    GlobalNavigation.prototype.mainNavHiddenButtons = function () {
        var missingNavMenus = 0;
        if (!this.state.artifactList || !this.state.artifactList.length)
            missingNavMenus++;
        if (!this.state.reportsButton || !this.state.reportsButton.url)
            missingNavMenus++;
        return missingNavMenus;
    };
    GlobalNavigation.prototype.searchButtonGetOffsetClasses = function () {
        var offset = this.mainNavHiddenButtons();
        var classes = "";
        if (offset == 1) {
            classes = "nav-top-set-ml1-on-search";
        }
        else if (offset == 2) {
            classes = "nav-top-set-ml2-on-search";
        }
        return classes;
    };
    GlobalNavigation.prototype.searchTermUpdate = function (e) {
        this.setState({ searchTerm: e.target.value });
    };
    GlobalNavigation.prototype.searchKeyPress = function (e) {
        if (e.keyCode === 13) {
            this.searchInit(globalFunctions.trim(this.state.searchTerm));
            e.preventDefault();
            e.stopPropagation();
        }
        else if (e.keyCode === 27) {
            this.setState({ searchIsOpen: false });
        }
        else {
            this.setState({ searchIsOpen: true });
        }
    };
    GlobalNavigation.prototype.searchInit = function (searchTerm) {
        var searchService = Inflectra.SpiraTest.Web.Services.Ajax.SearchService, errorMessageControlId = $find('<%=divMessageBox.ClientID %>');
        var keywords = globalFunctions.trim(searchTerm);
        if (keywords && keywords != '') {
            globalSearch.msgBoxId = errorMessageControlId;
            globalSearch.currentProjectId = SpiraContext.ProjectId;
            this.setState({ searchIsOpen: false });
            globalSearch.searchInit(keywords, searchService);
            if (this.state.searchHistory.indexOf(keywords) < 0) {
                var newHistory = __spreadArray([keywords], this.state.searchHistory, true);
                if (newHistory.length > this.enum.searchHistoryMax) {
                    newHistory.slice(0, this.enum.searchHistoryMax - 1);
                }
                this.setState({ searchHistory: newHistory });
                localStorage.setItem(this.enum.searchStorage, JSON.stringify(newHistory));
            }
        }
    };
    GlobalNavigation.prototype.wholeNavMobileToggle = function (e) {
        if (!e.target.checked) {
            this.workspaceDrop && this.workspaceDrop.current.menuClose();
            this.artifactDrop && this.artifactDrop.current.menuClose();
            this.userDrop && this.userDrop.current.menuClose();
            !globalFunctions.objectIsEmpty(this.props.data.adminNavigation) && this.adminMenuClose();
        }
        this.setState({ navMobileIsOpen: e.target.checked });
    };
    GlobalNavigation.prototype.workspaceDropToggleOpen = function () {
        if (this.workspaceDrop.current) {
            this.adminMenuClose();
            this.artifactDrop.current && this.artifactDrop.current.menuClose();
            this.userDrop.current && this.userDrop.current.menuClose();
            this.workspaceDrop.current.menuToggle();
        }
    };
    GlobalNavigation.prototype.artifactDropToggleOpen = function () {
        if (this.artifactDrop.current) {
            this.adminMenuClose();
            this.userDrop.current && this.userDrop.current.menuClose();
            this.workspaceDrop.current && this.workspaceDrop.current.menuClose();
            this.artifactDrop.current.menuToggle();
        }
    };
    GlobalNavigation.prototype.userDropToggleOpen = function () {
        if (this.userDrop.current) {
            this.adminMenuClose();
            this.workspaceDrop.current && this.workspaceDrop.current.menuClose();
            this.artifactDrop.current && this.artifactDrop.current.menuClose();
            this.userDrop.current.menuToggle();
        }
    };
    GlobalNavigation.prototype.spinnerShow = function () {
        var newSpinner = this.state.spinnerShow + 1;
        this.setState({ spinnerShow: newSpinner });
    };
    GlobalNavigation.prototype.spinnerHide = function () {
        var newSpinner = this.state.spinnerShow > 0 ? this.state.spinnerShow - 1 : 0;
        this.setState({ spinnerShow: newSpinner });
    };
    GlobalNavigation.prototype.handleOpenLink = function (name, url, evt) {
        var _a;
        if (evt.ctrlKey || evt.which === 2) {
            window.open(url, '_blank');
        }
        else {
            window.location.assign(url);
            this.setState((_a = {}, _a[name] = true, _a));
        }
    };
    GlobalNavigation.prototype.updateDropStatus = function (dataName, newStatus) {
        var _a;
        if (dataName)
            this.setState((_a = {}, _a[dataName + "IsOpen"] = newStatus, _a));
    };
    GlobalNavigation.prototype.onboardingShow = function (onlyOpenIfHasUnseen) {
        if (SpiraContext.ThemeName === "ValidationMasterTheme") {
            var seenAppIntro = SpiraContext.GuidedToursSeen.guidedToursNavigationBarSeen || SpiraContext.GuidedToursSeen.appIntro || false;
            var seenUpdate = SpiraContext.GuidedToursSeen["update-" + SpiraContext.VersionNumber] ? true : SpiraContext.GuidedTours.filter(function (x) { return x.name == ["update-" + SpiraContext.VersionNumber]; }).length == 0;
            var shouldShowUpdate = false;
            if (seenAppIntro && !seenUpdate) {
                var now = new Date(), year = now.getFullYear(), month = (now.getMonth() + 1) < 10 ? "0" + (now.getMonth() + 1) : (now.getMonth() + 1), day = now.getDate() < 10 ? "0" + now.getDate() : now.getDate(), todayIsoDate = year + "-" + month + "-" + day;
                shouldShowUpdate = new Date(seenAppIntro) < new Date(todayIsoDate);
            }
            if ((onlyOpenIfHasUnseen && (!seenAppIntro || shouldShowUpdate)) || !onlyOpenIfHasUnseen) {
                globalFunctions.dlgGlobalDynamicClear();
                ReactDOM.render(React.createElement(OnBoarding, { tours: SpiraContext.GuidedTours || null, toursSeen: SpiraContext.GuidedToursSeen || null, seenAppIntro: seenAppIntro, seenUpdate: !shouldShowUpdate, updateTourName: "update-" + SpiraContext.VersionNumber }), document.getElementById('dlgGlobalDynamic'));
            }
        }
    };
    GlobalNavigation.prototype.onboardingRegisterPage = function () {
        if (SpiraContext.ThemeName === "ValidationMasterTheme") {
            var pageName = "navigationLink_" + this.state.currentLocation;
            if (!SpiraContext.GuidedToursSeen[pageName]) {
                Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.UserSettings_GuidedTour_SetSeen(pageName);
            }
            var pageCount = "navigationCount_" + this.state.currentLocation;
            Inflectra.SpiraTest.Web.Services.Ajax.GlobalService.UserSettings_GuidedTour_SetNavigationLinkCount(pageCount);
        }
    };
    GlobalNavigation.prototype.keyboardShortcutsInit = function () {
        var _this = this;
        if (!this.kbCodes && !this.kbCodes.codes)
            return;
        var kbCodes = this.kbCodes.codes;
        Mousetrap.bind(kbCodes.showGlossary.term, function (e) {
            _this.keyboardTogglePopup();
        });
        Mousetrap.bind('n 1', function (e) { return window.location.href = globalFunctions.replaceBaseUrl(SpiraContext.Navigation.myPageUrl); });
        var workspaceUrl = this.workspaceUrl();
        if (workspaceUrl)
            Mousetrap.bind('n 2', function (e) { return window.location.href = workspaceUrl; });
        if (this.props.data.adminUrl)
            Mousetrap.bind('n a d', function (e) { return window.location.href = _this.props.data.adminUrl; });
        if (this.props.data.myTimecardUrl)
            Mousetrap.bind('n t i', function (e) { return window.location.href = globalFunctions.replaceBaseUrl(_this.props.data.myTimecardUrl); });
        var _loop_4 = function () {
            var art = this_1.state.artifactList[i];
            if (art.id && art.url && kbCodes[art.id])
                Mousetrap.bind(kbCodes[art.id].term, function () { return window.location.href = art.url; });
        };
        var this_1 = this;
        for (var i = 0; i < this.state.artifactList.length; i++) {
            _loop_4();
        }
        if (this.state.reportsButton && this.state.reportsButton.url) {
            Mousetrap.bind('n r p', function (e) { return window.location.href = _this.state.reportsButton.url; });
        }
        Mousetrap.bind('n 0', function (e) { return window.location.href = globalFunctions.replaceBaseUrl(SpiraContext.Navigation.myProfileUrl); });
        if (!this.state.searchIsOpen) {
            Mousetrap.bind('shift+s', function (e) { return _this.searchToggleOpen(); });
        }
        if (SpiraContext.ProjectId && SpiraContext.BaseUrl) {
            Mousetrap.bind('shift+i', function (e) {
                return window.location.href = SpiraContext.BaseUrl + SpiraContext.ProjectId + '/Incident/New.aspx';
            });
        }
        Mousetrap.bind('mod+alt+w', function (e) { return _this.workspaceDropToggleOpen(); });
        Mousetrap.bind('mod+alt+a', function (e) { return _this.artifactDropToggleOpen(); });
        Mousetrap.bind('mod+alt+u', function (e) { return _this.userDropToggleOpen(); });
        if (!globalFunctions.objectIsEmpty(this.props.data.adminNavigation)) {
            Mousetrap.bind('shift+a', function (e) { return _this.adminToggleMenu(null); });
        }
    };
    GlobalNavigation.prototype.keyboardTogglePopup = function () {
        $('#global-nav-keyboard-shortcuts').modal();
    };
    GlobalNavigation.prototype.render = function () {
        var _this = this;
        var _a = this.state, adminShow = _a.adminShow, artifactList = _a.artifactList, artifactParent = _a.artifactParent, currentLocation = _a.currentLocation, reportsButton = _a.reportsButton, searchHistory = _a.searchHistory, searchTerm = _a.searchTerm, spinnerShow = _a.spinnerShow, userIcon = _a.userIcon, userList = _a.userList, workspaceCurrent = _a.workspaceCurrent, workspaceList = _a.workspaceList;
        var loaderIcon = React.createElement("div", { className: "lds-ellipsis" },
            React.createElement("div", null),
            React.createElement("div", null),
            React.createElement("div", null),
            React.createElement("div", null));
        var productIcon = React.createElement("img", { alt: this.props.product, href: "/ValidationMaster/LandingScreen.aspx", className: "nav-home-logo mh-100 mw5", src: this.props.baseThemeUrl + "NewImages/VM Studio large logo-color 1.svg" });
        var workspaceTitle = artifactParent.name;
        var workspaceIcon = React.createElement("img", { alt: workspaceTitle, className: "navbar-brand d-flex align-items-center  pe-2  me-3", src: this.props.baseThemeUrl + "NewImages/VM Studio large logo-color 1.svg" });
        var isMyPage = currentLocation === globalFunctions.artifactTypeEnum.myPage, isWorkspaceHome = currentLocation === globalFunctions.artifactTypeEnum.projectHome ||
            currentLocation === globalFunctions.artifactTypeEnum.programHome ||
            currentLocation === globalFunctions.artifactTypeEnum.administration && this.props.workspaceType === this.props.workspaceEnums.enterprise, isArtifact = artifactList.filter(function (x) { return x.id; }).map(function (x) { return x.id; }).indexOf(currentLocation.toString()) >= 0, isReporting = currentLocation === globalFunctions.artifactTypeEnum.reports, isUserPage = userList.map(function (x) { return x.listId; }).indexOf(currentLocation.toString()) >= 0, isAdministration = currentLocation === globalFunctions.artifactTypeEnum.administration;
        var searchHistoryListItems = (searchHistory && searchHistory.length > 0) ?
            searchHistory.map(function (searchTerm, i) {
                return React.createElement("li", { className: "lsn my2 mx3 pa0 fs-14", key: i },
                    React.createElement("a", { className: "db tdn tdn-hover mid-gray mid-gray-hover py-2 br2 bg-vlight-gray-hover pointer", onClick: _this.searchInit.bind(null, searchTerm) }, searchTerm));
            })
            : React.createElement("li", { className: "lsn my2 mx3 pa0 fs-14" }, resx.Global_None);
        var mainListClasses = "fw2 cf nav-top-list nav-top-list-" + (5 - this.mainNavHiddenButtons()) + (this.state.workspaceListIsOpen || this.state.artifactListIsOpen ? " z-3" : " z-2");
        var c1 = SpiraContext.ProjectId;
        var button;
        var imagebutton;
        if (c1 === undefined) {
            button = React.createElement("button", { type: "button", title: "Project Admin settings", onClick: this.handleOpenLink.bind(this, "workspaceLoading", SpiraContext.BaseUrl + "Mypage.aspx"), class: "btn btn-outline-secondary  border-grey d-flex align-items-center bg-transparent px-2 py-2" },
                React.createElement("img", { src: this.props.baseThemeUrl + "NewImages/settings.svg", width: "20px", height: "20px", alt: "settings icon" }));
        }
        else {
            button = React.createElement("button", { type: "button", title: "Project Admin settings", onClick: this.handleOpenLink.bind(this, "workspaceLoading", SpiraContext.BaseUrl + SpiraContext.ProjectId + "/Administration.aspx"), class: "btn btn-outline-secondary  border-grey d-flex align-items-center bg-transparent px-2 py-2" },
                React.createElement("img", { src: this.props.baseThemeUrl + "NewImages/settings.svg", width: "20px", height: "20px", alt: "settings icon" }));
        }
        if (c1 === undefined) {
            imagebutton = React.createElement("a", { "aria-label": "Global Navigation Workspace Home", className: "" + (isWorkspaceHome ? " bg-nav-bg-highlight-subtle" : ""), onClick: this.handleOpenLink.bind(this, "workspaceLoading", SpiraContext.BaseUrl + "LandingScreen.aspx"), id: "globalNav_workspaceHome", title: resx.GlobalNavigation_TooltipWorkspaceHome },
                this.state.workspaceLoading ? loaderIcon : workspaceIcon,
                React.createElement("span", { className: "dn-md-up" }, workspaceTitle));
        }
        else {
            imagebutton = React.createElement("a", { "aria-label": "Global Navigation Workspace Home", className: "" + (isWorkspaceHome ? " bg-nav-bg-highlight-subtle" : ""), onClick: this.handleOpenLink.bind(this, "workspaceLoading", SpiraContext.BaseUrl + "LandingScreen.aspx"), id: "globalNav_workspaceHome", title: resx.GlobalNavigation_TooltipWorkspaceHome },
                this.state.workspaceLoading ? loaderIcon : workspaceIcon,
                React.createElement("span", { className: "dn-md-up" }, workspaceTitle));
        }
        var recentClass = this.state.searchIsOpen ? "mt-4 u-popup u-popup_down  is-open" : "mt-4 u-popup u-popup_down";
        return (React.createElement("nav", { className: "nav-top pt-3 px-3 nav-fixed mw-100 z-1000", id: "nav-top", role: "navigation", style: { backgroundColor: SpiraContext.UnsupportedBrowser ? "#e63d3d" : "" } },
            spinnerShow > 0 &&
                React.createElement("div", { id: "globalNav_spinner", className: "absolute h-nav-top w-auto px4 top0 bg-yolk z-3 df items-center right0-sm" + (!globalFunctions.objectIsEmpty(this.props.data.adminNavigation) ? " right8" : " right4") },
                    React.createElement("div", { className: "lds-ellipsis mr5" },
                        React.createElement("div", null),
                        React.createElement("div", null),
                        React.createElement("div", null),
                        React.createElement("div", null)),
                    resx.GlobalFunctions_SpinnerText),
            React.createElement("input", { checked: this.state.searchIsOpen, className: "dn", id: "nav-search-check", onChange: this.searchToggleOpen, type: "checkbox" }),
            React.createElement("input", { type: "checkbox", className: "dn", id: "nav-menu-sm-check", onChange: this.wholeNavMobileToggle }),
            React.createElement("ul", { className: "fw2 cf nav-top-head-sm", role: "navigation" },
                React.createElement("li", { className: "nav-top-li absolute" },
                    React.createElement("label", { className: "nav-top-btn no-indicator ma0", for: "nav-menu-sm-check", id: "globalNav_btn-show-list", href: "products" },
                        React.createElement("i", { className: "nav-hamburger" })))),
            React.createElement("ul", { className: "no-marker " + mainListClasses, role: "navigation" },
                React.createElement("li", { className: "w-100-xs nav-item text-decoration-none", id: "global-navigation-workspace-home" }, imagebutton),
                React.createElement("li", { className: "newdropdown nav-item header-select-dropdown ms-4 fs-14 border-grey shadow-none", id: "global-navigation-workspace-li" },
                    React.createElement(ErrorBoundary, null,
                        React.createElement(RctDrop, { ariaLabelWrapper: "Global Navigation Open Workspace Menu", boxClasses: "nav-drop-box", buttonClasses: "nav-drop-btn remove-menu-dwn min-w6", dataName: "workspaceList", dataHiddenName: "workspaceHidden", defaultText: workspaceList.length ? this.state.workspaceDefaultText : resx.NavigationBar_NoWorkspaceMembership, defaultTitle: resx.GlobalNavigation_TooltipWorkspace, domId: "globalNav_workspaceDropdown", expanderClasses: "nav-text yolk-hover", expanderClickManager: this.expandingToggle, menuToggleCallback: this.updateDropStatus, items: workspaceList, menuClasses: "nav-drop-menu drop-dwn shadow-b-mid-gray workSpaceDropdwn", ref: this.workspaceDrop, selected: workspaceCurrent, showLoaderOnClick: true }))),
                !globalFunctions.objectIsEmpty(this.props.data.adminNavigation) &&
                    React.createElement("li", { className: "ps-2 nav-item nav-setting-btn", id: "global-navigation-workspace-li" }, button),
                React.createElement("li", { className: "d-none d-lg-block nav-item flex-fill pe-3 search-box-width", id: "global-navigation-search-box-li" },
                    React.createElement("aside", { className: "position-relative search-input" },
                        React.createElement("button", { "aria-label": "Global Navigation Search", "aria-hidden": "true", className: "nav-search-go", id: "globalNav_search_button", onClick: this.searchInit.bind(null, globalFunctions.trim(this.state.searchTerm)), title: resx.Global_Search, type: "button" }),
                        React.createElement("input", { className: "nav-search-input", id: "globalNav_search_input", maxlength: "255", onChange: this.searchTermUpdate, onKeyDown: this.searchKeyPress, onClick: this.searchKeyPress, placeholder: resx.Global_Search, ref: this.searchInput, title: resx.GlobalNavigation_SearchTooltip, type: "search", value: searchTerm }),
                        React.createElement("img", { onClick: this.searchInit.bind(null, globalFunctions.trim(this.state.searchTerm)), className: "navitem-search-icon", src: this.props.baseThemeUrl + "NewImages/search-icon.svg" }),
                        React.createElement("div", { className: recentClass },
                            React.createElement("span", { onClick: this.closeRecentSearch, className: "ti ti-x bg-border rounded-circle  pointer p-1 mtn4 mrn4 position-absolute search-close-style r-10px crossBtn" }),
                            React.createElement("div", { class: "  rounded-2 bg-border ", id: "global-search-all-lg" },
                                React.createElement("div", { class: "border-0 border-bottom vm-midgreylight-bg 1" },
                                    React.createElement("div", { class: "pad-y-12 ps-3 pe-5 border-0 border-bottom d-flex align-items-center justify-content-between vm-midgreylight-bg 2" },
                                        React.createElement("div", { class: "d-flex align-items-center gap-1" },
                                            React.createElement("div", { class: "fs-16 fw-medium ti ti-history vm-default" }),
                                            React.createElement("div", { class: "fs-14 fw-medium vm-default" }, "Recent Searches")))),
                                React.createElement("div", { class: "pad-y-10 px-3 border-0 bg-white global-search" }, searchHistoryListItems)))))),
            React.createElement("ul", { className: "dropdown nav-item flex-shrink-0 profile", role: "navigation" },
                React.createElement("li", { className: "d-flex align-items-start gap-md-2 link-body-emphasis text-decoration-none justify-content-end px-2", onBlur: this.adminMenuOnBlur, id: "global-navigation-user-li" },
                    React.createElement(ErrorBoundary, null,
                        React.createElement(RctDrop, { ariaLabelWrapper: "Global Navigation Open User Menu", boxClasses: "w-100 ", buttonClasses: "nav-top-btn remove-menu-dwn py0 mt-n2 min-w6" + (isUserPage ? " bg-nav-bg-highlight-subtle" : ""), defaultText: React.createElement("div", { className: " flex align-items-center" },
                                React.createElement(AvatarIcon, { className: "rounded", hasIcon: userIcon.hasIcon, icon: userIcon.avatarUrl, name: userIcon.name, nameAsIcon: userIcon.nameAsIcon, wrapperClasses: "lh-initial mr3" }),
                                React.createElement("div", null,
                                    React.createElement("p", { className: "ma0 pa0 nowrap admin-title fs-14 fw-bold d-none d-md-block" }, userIcon.name),
                                    React.createElement("p", { className: "ma0 mt-n1 admin-subtitle pa0 sub-txt fs-12 fw-normal" }, SpiraContext.IsSystemAdmin ? "Product Owner" : SpiraContext.ProjectRole.Name))), domId: "globalNav_userDropdown", expanderClasses: "nav-text yolk-hover fs-h5 mr2", expanderClickManager: this.expandingToggle, isMobileMenu: this.state.navMobileIsOpen, items: userList, menuClasses: "nav-drop-menu left-auto right0 shadow-b-mid-gray userDropdwn", menuToggleCallback: this.updateDropStatus, ref: this.userDrop, selected: currentLocation, showLoaderOnClick: true, showDefaultAndSelected: true, showDefaultOnRight: true, extraDefaultClasses: "dn-md-up", extraDefaultText: userIcon.name }))))));
    };
    return GlobalNavigation;
}(React.Component));
function navLoadTry() {
    if (typeof SpiraContext == 'undefined' || typeof SpiraContext.Navigation == 'undefined') {
        console.log(SpiraContext.WorkspaceType);
        setTimeout(function () { return navLoadTry(); }, 100);
    }
    else if (!document.getElementById('global-navigation')) {
        window.requestAnimationFrame(navLoadTry);
    }
    else {
        ReactDOM.render(React.createElement(GlobalNavigation, { data: SpiraContext.Navigation, baseThemeUrl: SpiraContext.BaseThemeUrl, baseUrl: SpiraContext.BaseUrl, isGroupAdmin: SpiraContext.IsGroupAdmin, isPortfolioEnabled: SpiraContext.Features.portfolios, isPortfolioViewer: SpiraContext.IsPortfolioAdmin, isEnterpriseViewer: SpiraContext.IsPortfolioAdmin, isProjectAdmin: SpiraContext.IsProjectAdmin, isSysAdmin: SpiraContext.IsSystemAdmin, isReportAdmin: SpiraContext.isReportAdmin, projectGroupId: SpiraContext.ProjectGroupId, projectId: SpiraContext.ProjectId, product: SpiraContext.ProductType, ref: function (rct_comp_globalNav) { window.rct_comp_globalNav = rct_comp_globalNav; }, workspaceEnums: SpiraContext.WorkspaceEnums, workspaceType: SpiraContext.WorkspaceType }), document.getElementById('global-navigation'));
    }
}
;
navLoadTry();
//# sourceMappingURL=GlobalNavigation.js.map