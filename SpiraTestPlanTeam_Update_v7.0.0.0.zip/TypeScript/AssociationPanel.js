var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var resx = Inflectra.SpiraTest.Web.GlobalResources;
var panelAssociationAdd = {
    addPanelId: '',
    addPanelObj: '',
    lnkAddBtnId: '',
    messageBox: '',
    sortedGridId: '',
    displayType: 0,
    listOfViewableArtifactTypeIds: '',
    displayTypeHasComment: [
        globalFunctions.displayTypeEnum.ArtifactLink,
        globalFunctions.displayTypeEnum.SourceCodeRevision_Associations,
        globalFunctions.displayTypeEnum.SourceCodeFile_Associations
    ],
    blob: resx.ArtifactLinkType_Related,
    artifactLinkList: [
        {
            name: resx.ArtifactLinkType_Related,
            id: 1
        }, {
            name: resx.ArtifactLinkType_Depends,
            id: 2
        }
    ],
    customSaveSuccessFunction: null,
    artifactsIncluded: function (art, dis) {
        var res;
        if (dis === globalFunctions.displayTypeEnum.ArtifactLink) {
            if (art === globalFunctions.artifactTypeEnum.requirement) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.incident) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.testStep,
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.task) {
                res = [
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.testRun) {
                res = [
                    globalFunctions.artifactTypeEnum.task
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.document) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.release,
                    globalFunctions.artifactTypeEnum.testCase,
                    globalFunctions.artifactTypeEnum.testSet,
                    globalFunctions.artifactTypeEnum.testRun,
                    globalFunctions.artifactTypeEnum.testStep,
                    globalFunctions.artifactTypeEnum.automationHost,
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.risk) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.risk,
                    globalFunctions.artifactTypeEnum.testCase,
                    globalFunctions.artifactTypeEnum.incident
                ];
            }
            else if (art === globalFunctions.artifactTypeEnum.testCase) {
                res = [
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
        }
        else if (art === globalFunctions.artifactTypeEnum.requirement && dis === globalFunctions.displayTypeEnum.Requirement_TestCases) {
            res = [globalFunctions.artifactTypeEnum.testCase];
        }
        else if (art === globalFunctions.artifactTypeEnum.release && dis === globalFunctions.displayTypeEnum.Release_TestCases) {
            res = [globalFunctions.artifactTypeEnum.testCase];
        }
        else if (art === globalFunctions.artifactTypeEnum.testSet && dis === globalFunctions.displayTypeEnum.Release_TestCases) {
            res = [globalFunctions.artifactTypeEnum.testCase];
        }
        else if (art === globalFunctions.artifactTypeEnum.testCase && (dis === globalFunctions.displayTypeEnum.TestCase_Requirements || dis === globalFunctions.displayTypeEnum.TestStep_Requirements)) {
            res = [globalFunctions.artifactTypeEnum.requirement];
        }
        else if (art === globalFunctions.artifactTypeEnum.testCase && dis === globalFunctions.displayTypeEnum.TestCase_Releases) {
            res = [globalFunctions.artifactTypeEnum.release];
        }
        else if (art === globalFunctions.artifactTypeEnum.testStep && dis === globalFunctions.displayTypeEnum.TestStep_Incidents) {
            res = [globalFunctions.artifactTypeEnum.incident];
        }
        else if (art === globalFunctions.artifactTypeEnum.testCase && dis === globalFunctions.displayTypeEnum.TestCase_TestSets) {
            res = [globalFunctions.artifactTypeEnum.testSet];
        }
        else if (art === globalFunctions.artifactTypeEnum.testSet && dis === globalFunctions.displayTypeEnum.TestSet_TestCases) {
            res = [globalFunctions.artifactTypeEnum.testCase];
        }
        else if ((art === globalFunctions.artifactTypeEnum.testCase ||
            art === globalFunctions.artifactTypeEnum.testStep) &&
            (dis === globalFunctions.displayTypeEnum.TestCase_Requirements || dis === globalFunctions.displayTypeEnum.TestStep_Requirements)) {
            res = [globalFunctions.artifactTypeEnum.requirement];
        }
        else if (dis === globalFunctions.displayTypeEnum.TestRun_Incidents) {
            res = [globalFunctions.artifactTypeEnum.incident];
        }
        else if (dis === globalFunctions.displayTypeEnum.Attachments) {
            if (art === globalFunctions.artifactTypeEnum.document) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.release,
                    globalFunctions.artifactTypeEnum.testCase,
                    globalFunctions.artifactTypeEnum.testSet,
                    globalFunctions.artifactTypeEnum.testRun,
                    globalFunctions.artifactTypeEnum.testStep,
                    globalFunctions.artifactTypeEnum.automationHost,
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else {
                res = [globalFunctions.artifactTypeEnum.document];
            }
        }
        else if (dis === globalFunctions.displayTypeEnum.SourceCodeRevision_Associations) {
            if (art === globalFunctions.artifactTypeEnum.sourceCodeRevisions) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.release,
                    globalFunctions.artifactTypeEnum.testCase,
                    globalFunctions.artifactTypeEnum.testSet,
                    globalFunctions.artifactTypeEnum.testRun,
                    globalFunctions.artifactTypeEnum.testStep,
                    globalFunctions.artifactTypeEnum.automationHost,
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else {
                res = [globalFunctions.artifactTypeEnum.sourceCodeRevisions];
            }
        }
        else if (dis === globalFunctions.displayTypeEnum.SourceCodeFile_Associations) {
            if (art === globalFunctions.artifactTypeEnum.sourceCode) {
                res = [
                    globalFunctions.artifactTypeEnum.requirement,
                    globalFunctions.artifactTypeEnum.release,
                    globalFunctions.artifactTypeEnum.testCase,
                    globalFunctions.artifactTypeEnum.testSet,
                    globalFunctions.artifactTypeEnum.testRun,
                    globalFunctions.artifactTypeEnum.testStep,
                    globalFunctions.artifactTypeEnum.automationHost,
                    globalFunctions.artifactTypeEnum.task,
                    globalFunctions.artifactTypeEnum.incident,
                    globalFunctions.artifactTypeEnum.risk
                ];
            }
            else {
                res = [globalFunctions.artifactTypeEnum.sourceCodeRevisions];
            }
        }
        var authorizedArtifacts = res.filter(function (x) { return globalFunctions.isAuthorized(globalFunctions.permissionEnum.View, x) === globalFunctions.authorizationStateEnum.authorized; });
        return authorizedArtifacts;
    },
    parseArtifactArray: function (arr) {
        if (!arr || !arr.length) {
            return;
        }
        var res = arr.map(function (item) {
            var newItem = globalFunctions.getArtifactTypes(item)[0];
            return newItem;
        });
        return res;
    },
    artifactsList: function (artifactType, displayType) {
        var arr = panelAssociationAdd.artifactsIncluded(artifactType, displayType);
        if (!arr) {
            alert(resx.AssociationPanel_NoArtifactTypesCanBeAdded);
        }
        return panelAssociationAdd.parseArtifactArray(arr);
    },
    showPanel: function () {
        $("#" + panelAssociationAdd.lnkAddBtnId).addClass('disabled');
        var hasArtifactsToAssociate = panelAssociationAdd.artifactsList(SpiraContext.ArtifactTypeId, panelAssociationAdd.displayType) != undefined;
        if (hasArtifactsToAssociate) {
            ReactDOM.render(React.createElement(AssocationBox, { displayType: panelAssociationAdd.displayType, domId: panelAssociationAdd.addPanelId, lnkAddBtnId: panelAssociationAdd.lnkAddBtnId, messageBox: panelAssociationAdd.messageBox, sortedGridId: panelAssociationAdd.sortedGridId, projectId: SpiraContext.ProjectId, customSaveSuccessFunction: panelAssociationAdd.customSaveSuccessFunction }), document.getElementById(panelAssociationAdd.addPanelId));
        }
    }
};
var AssocationBox = (function (_super) {
    __extends(AssocationBox, _super);
    function AssocationBox(props) {
        var _this = _super.call(this, props) || this;
        var artifactsIncluded = panelAssociationAdd.artifactsIncluded(SpiraContext.ArtifactTypeId, _this.props.displayType), filterAllObj = {
            artifact: { name: resx.AssociationPanel_SelectArtifact, id: 0 },
            folder: { name: _this.setAllFoldersName(null), id: 0, indentLevel: "" },
            project: { name: resx.Global_CurrentProject, id: 0, childIds: artifactsIncluded }
        }, artifacts = panelAssociationAdd.artifactsList(SpiraContext.ArtifactTypeId, _this.props.displayType), artifactTokens = artifacts.map(function (item) { return item.token; }), listOfViewableArtifactTypeIds = panelAssociationAdd.listOfViewableArtifactTypeIds.split(","), folders = [], projects = [];
        artifacts.unshift(filterAllObj.artifact);
        folders.unshift(filterAllObj.folder);
        projects.unshift(filterAllObj.project);
        var viewableArtifactTypes = listOfViewableArtifactTypeIds.map(function (item) { return parseInt(item, 10); });
        _this.state = {
            searchTerm: '',
            searchTermLastSent: '',
            searchTermIsValidToken: false,
            searchCompleted: false,
            isTestCoverage: (_this.props.displayType === globalFunctions.displayTypeEnum.Requirement_TestCases || _this.props.displayType === globalFunctions.displayTypeEnum.Release_TestCases),
            isCreateFromCurrentArtifact: _this.canCreateFromCurrentArtifact(_this.props.displayType),
            newArtifactTypeToCreate: _this.props.displayType === globalFunctions.displayTypeEnum.Requirement_TestCases ? globalFunctions.artifactTypeEnum.testCase :
                _this.props.displayType === globalFunctions.displayTypeEnum.Release_TestCases ? globalFunctions.artifactTypeEnum.testSet :
                    _this.props.displayType === globalFunctions.displayTypeEnum.TestCase_Requirements ? globalFunctions.artifactTypeEnum.requirement :
                        (SpiraContext.ArtifactTypeId === globalFunctions.artifactTypeEnum.incident && _this.props.displayType === globalFunctions.displayTypeEnum.ArtifactLink) ? globalFunctions.artifactTypeEnum.requirement :
                            (SpiraContext.ArtifactTypeId === globalFunctions.artifactTypeEnum.task && _this.props.displayType === globalFunctions.displayTypeEnum.ArtifactLink) ? globalFunctions.artifactTypeEnum.incident :
                                null,
            artifactId: SpiraContext.ArtifactId,
            artifactTypeId: SpiraContext.ArtifactTypeId,
            artifacts: artifacts,
            artifactsEnabled: artifactsIncluded,
            artifactsPermissionToView: viewableArtifactTypes,
            artifactFilter: _this.setInitialArtifactFilter(_this.props.displayType),
            artifactDropDownNotRequired: artifacts.length < 3,
            artifactTokens: artifactTokens,
            artifactTokenRegexPattern: '^\[?(' + artifactTokens.join('|') + '):?[0-9]+\]?',
            folders: folders,
            folderFilter: 0,
            onlyShowFolders: false,
            projects: projects,
            projectFilter: 0,
            results: [],
            resultsNotEmpty: false,
            browseFields: {
                project: 1,
                artifact: 2,
                folder: 3
            },
            selectionAssociations: [],
            selectionLength: 0,
            showComment: globalFunctions.findItemInArray(panelAssociationAdd.displayTypeHasComment, _this.props.displayType),
            linkType: 1,
            linkTypeList: panelAssociationAdd.artifactLinkList,
            commentTerm: ""
        };
        _this.getProject_success = _this.getProject_success.bind(_this);
        _this.getFolderList = _this.getFolderList.bind(_this);
        _this.getFolderList_success = _this.getFolderList_success.bind(_this);
        _this.getFolderList_failure = _this.getFolderList_failure.bind(_this);
        _this.setAllFoldersName = _this.setAllFoldersName.bind(_this);
        _this.setEnabledArtifacts = _this.setEnabledArtifacts.bind(_this);
        _this.resetArtifactSelection = _this.resetArtifactSelection.bind(_this);
        _this.setInitialArtifactFilter = _this.setInitialArtifactFilter.bind(_this);
        _this.browseProjectChange = _this.browseProjectChange.bind(_this);
        _this.browseArtifactChange = _this.browseArtifactChange.bind(_this);
        _this.browseFolderChange = _this.browseFolderChange.bind(_this);
        _this.folderExpandCollapseClick = _this.folderExpandCollapseClick.bind(_this);
        _this.searchTermChange = _this.searchTermChange.bind(_this);
        _this.searchEnterPress = _this.searchEnterPress.bind(_this);
        _this.searchClick = _this.searchClick.bind(_this);
        _this.searchClick_success = _this.searchClick_success.bind(_this);
        _this.searchClick_failure = _this.searchClick_failure.bind(_this);
        _this.onHeaderClick = _this.onHeaderClick.bind(_this);
        _this.onRowClick = _this.onRowClick.bind(_this);
        _this.onExpandCollapseGridClick = _this.onExpandCollapseGridClick.bind(_this);
        _this.onGridRowNameMouseEnter = _this.onGridRowNameMouseEnter.bind(_this);
        _this.populateNameTooltip = _this.populateNameTooltip.bind(_this);
        _this.selectAssociations = _this.selectAssociations.bind(_this);
        _this.setLinkType = _this.setLinkType.bind(_this);
        _this.commentChange = _this.commentChange.bind(_this);
        _this.saveClick = _this.saveClick.bind(_this);
        _this.saveClick_success = _this.saveClick_success.bind(_this);
        _this.closeClick = _this.closeClick.bind(_this);
        _this.createFromCurrentArtifact = _this.createFromCurrentArtifact.bind(_this);
        _this.createFromCurrentArtifact_success = _this.createFromCurrentArtifact_success.bind(_this);
        return _this;
    }
    AssocationBox.prototype.componentDidMount = function () {
        SpiraContext.uiState[this.props.domId] = { isMounted: true };
        var artifactId = this.state.artifactId, artifactTypeIds = panelAssociationAdd.artifactsIncluded(this.state.artifactTypeId, this.props.displayType), projectId = SpiraContext.ProjectId;
        Inflectra.SpiraTest.Web.Services.Ajax.AssociationService.Association_RetrieveForDestProjectAndArtifact(projectId, artifactTypeIds, this.props.displayType, this.getProject_success, this.getProject_failure);
        if (this.props.displayType === globalFunctions.displayTypeEnum.Requirement_TestCases ||
            this.props.displayType === globalFunctions.displayTypeEnum.Release_TestCases ||
            this.props.displayType === globalFunctions.displayTypeEnum.TestStep_Requirements) {
            var projectId = this.state.projectFilter || this.props.projectId;
            this.getFolderList(globalFunctions.artifactTypeEnum.testCase, projectId);
        }
        ;
        $('[data-toggle="tooltip"]').tooltip();
    };
    AssocationBox.prototype.getProject_success = function (data) {
        var _this = this;
        if (data && data.length > 0) {
            this.setState({ projects: __spreadArray(__spreadArray([], this.state.projects, true), data, true) }, function () {
                _this.setEnabledArtifacts(_this.state.projects, _this.state.projectFilter, _this.state.artifactsPermissionToView);
            });
        }
        else {
            this.setEnabledArtifacts(this.state.projects, this.state.projectFilter, this.state.artifactsPermissionToView);
        }
    };
    AssocationBox.prototype.getProject_failure = function () {
    };
    AssocationBox.prototype.getFolderList = function (artifactTypeId, projectId) {
        var self = this, activeProjectId = projectId || this.props.projectId;
        if (artifactTypeId > 0 && activeProjectId > 0) {
            Inflectra.SpiraTest.Web.Services.Ajax.AssociationService.Association_RetrieveArtifactFolders(activeProjectId, artifactTypeId, self.getFolderList_success, self.getFolderList_failure);
        }
    };
    AssocationBox.prototype.getFolderList_success = function (data) {
        var folderTitle = [];
        folderTitle.push(this.state.folders[0]);
        var allFoldersName = this.setAllFoldersName(this.state.artifactFilter);
        folderTitle[0].name = allFoldersName;
        var newData = this.setCollapsibleProperties(data);
        var newFolders = folderTitle.concat(newData);
        this.setState({
            folders: newFolders,
            folderFilter: 0
        }, this.searchClick);
    };
    AssocationBox.prototype.getFolderList_failure = function () {
        this.setState({
            folders: [],
            folderFilter: 0
        });
    };
    AssocationBox.prototype.setAllFoldersName = function (artifact) {
        var newName;
        switch (artifact) {
            case globalFunctions.artifactTypeEnum.testCase:
            case globalFunctions.artifactTypeEnum.testSet:
            case globalFunctions.artifactTypeEnum.testStep:
                newName = resx.Folders_Root;
                break;
            case globalFunctions.artifactTypeEnum.requirement:
                newName = resx.Folders_AllPackages;
                break;
            default:
                newName = resx.Global_AllFolders;
        }
        return newName;
    };
    AssocationBox.prototype.setCollapsibleProperties = function (data) {
        if (!data) {
            return;
        }
        ;
        var newData = data, l = data.length, i = 0;
        for (i; i < l; i++) {
            if (newData[i].indentLevel && newData[i].indentLevel.length > 0) {
                var nextItemIsChild = indentLevelIsGreater(newData, i, i + 1);
                if (nextItemIsChild) {
                    newData[i].children = new Array;
                    newData[i].hideChildren = false;
                    for (var j = i + 1; j < l; j++) {
                        if (indentLevelIsGreater(newData, i, j)) {
                            newData[i].children.push(newData[j].id);
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        return newData;
        function indentLevelIsGreater(array, currentPosition, positionToCheck) {
            var currentIemExists = currentPosition < array.length ? true : false, currentItemIndentLevel = currentIemExists ? array[currentPosition].indentLevel.length : null, nextItemExists = positionToCheck < array.length ? true : false, nextItemIndentLevel = nextItemExists ? array[positionToCheck].indentLevel.length : null;
            return (currentIemExists && nextItemExists) ? nextItemIndentLevel > currentItemIndentLevel : false;
        }
    };
    AssocationBox.prototype.toggleShowHideChildren = function (array, children, newHideChildrenStatus) {
        var newArray = array.map(function (item) {
            if (children.indexOf(item.id) >= 0) {
                item.hide = newHideChildrenStatus;
                if (item.children) {
                    item.hideChildren = newHideChildrenStatus;
                }
            }
            return item;
        });
        return newArray;
    };
    AssocationBox.prototype.setEnabledArtifacts = function (projects, projectFilter, artifactsPermissionToView) {
        var sharedBySelectedProject = projects.filter(function (item) {
            return item.id === projectFilter;
        })[0], sharedArtifactTypeIds = sharedBySelectedProject.childIds;
        var sharedAndViewable = globalFunctions.filterArrayByList(sharedArtifactTypeIds, artifactsPermissionToView);
        this.setState({ artifactsEnabled: sharedAndViewable });
        if (!globalFunctions.findItemInArray(sharedAndViewable, this.state.artifactFilter)) {
            if (sharedAndViewable.length > 1) {
                this.resetArtifactSelection();
            }
            else {
                this.setState({ artifactFilter: sharedAndViewable[0] }, function () {
                    this.setArtifactFoldersAndResults(projectFilter);
                });
            }
        }
        else {
            this.setArtifactFoldersAndResults(projectFilter);
        }
    };
    AssocationBox.prototype.resetArtifactSelection = function () {
        var cleanResults = [];
        this.setState({
            artifactFilter: 0,
            results: cleanResults
        });
    };
    AssocationBox.prototype.setArtifactFoldersAndResults = function (projectFilter) {
        if (globalFunctions.getArtifactTypes(this.state.artifactFilter)[0].hasFolders) {
            this.getFolderList(this.state.artifactFilter, projectFilter);
        }
        else {
            this.searchClick(null);
        }
    };
    AssocationBox.prototype.setInitialArtifactFilter = function (displayType) {
        var filter = 0;
        switch (displayType) {
            case globalFunctions.displayTypeEnum.ArtifactLink:
            case globalFunctions.displayTypeEnum.Attachments:
            case globalFunctions.displayTypeEnum.SourceCodeRevision_Associations:
            case globalFunctions.displayTypeEnum.SourceCodeFile_Associations:
                filter = 0;
                break;
            case globalFunctions.displayTypeEnum.Requirement_TestCases:
            case globalFunctions.displayTypeEnum.Release_TestCases:
            case globalFunctions.displayTypeEnum.TestSet_TestCases:
                filter = globalFunctions.artifactTypeEnum.testCase;
                break;
            case globalFunctions.displayTypeEnum.TestCase_Requirements:
            case globalFunctions.displayTypeEnum.TestStep_Requirements:
                filter = globalFunctions.artifactTypeEnum.requirement;
                break;
            case globalFunctions.displayTypeEnum.TestCase_Releases:
                filter = globalFunctions.artifactTypeEnum.release;
                break;
            case globalFunctions.displayTypeEnum.TestRun_Incidents:
                filter = globalFunctions.artifactTypeEnum.incident;
                break;
            default:
                filter = 0;
                break;
        }
        return filter;
    };
    AssocationBox.prototype.browseProjectChange = function (projectFilter, e) {
        if (projectFilter >= 0) {
            this.setState({ projectFilter: projectFilter }, this.setEnabledArtifacts(this.state.projects, projectFilter, this.state.artifactsPermissionToView));
        }
    };
    AssocationBox.prototype.browseArtifactChange = function (filter, enabled, e) {
        if (enabled && filter >= 0) {
            var projectId = this.state.projectFilter || this.props.projectId;
            if (globalFunctions.getArtifactTypes(filter)[0].hasFolders) {
                this.setState({
                    artifactDropdownOpen: false,
                    artifactFilter: filter,
                    onlyShowFolders: globalFunctions.getArtifactTypes(filter)[0].foldersAreDifferentArtifactType ? true : false
                }, this.getFolderList(filter, projectId));
            }
            else {
                this.setState({
                    artifactFilter: filter
                }, this.searchClick);
            }
            ;
        }
        ;
    };
    AssocationBox.prototype.browseFolderChange = function (filter, e) {
        if (filter >= 0) {
            this.setState({ folderFilter: filter }, this.searchClick);
        }
        else {
            this.searchClick(null);
        }
    };
    AssocationBox.prototype.folderExpandCollapseClick = function (children, newData, newHideChildrenStatus) {
        var toggleShowHideData = this.toggleShowHideChildren(newData, children, newHideChildrenStatus);
        this.setState({
            folders: toggleShowHideData
        });
    };
    AssocationBox.prototype.searchTermChange = function (event) {
        var searchTerm = event.target.value;
        var regexMatch = false;
        var regExPattern = new RegExp(this.state.artifactTokenRegexPattern, "gi");
        if (searchTerm.match(regExPattern)) {
            regexMatch = true;
        }
        ;
        this.setState({
            searchTerm: searchTerm,
            searchTermIsValidToken: regexMatch
        });
    };
    AssocationBox.prototype.searchEnterPress = function (event) {
        this.searchClick(13);
        if (event.keyCode == 13) {
            var isEnter = 13;
        }
    };
    AssocationBox.prototype.searchClick = function (isEnter) {
        var isSearchEnabled = this.state.artifactDropDownNotRequired ||
            this.state.artifactFilter > 0 ||
            this.state.searchTermIsValidToken;
        console.log('searchClick', this.state.artifactDropDownNotRequired, this.state.artifactFilter, this.state.searchTermIsValidToken);
        if (isSearchEnabled) {
            var self = this, artifactTypeId = this.state.artifactTypeId, artifactId = this.state.artifactId, projectId = this.props.projectId, searchArtifactTypeId = this.state.artifactFilter, searchFolderId = this.state.folderFilter ? this.state.folderFilter : null, searchProjectId = this.state.projectFilter || this.props.projectId, searchTerm = this.state.searchTerm ? this.state.searchTerm : null;
            Inflectra.SpiraTest.Web.Services.Ajax.AssociationService.Association_SearchByProjectAndArtifact(projectId, artifactTypeId, artifactId, searchArtifactTypeId, searchFolderId, searchProjectId, searchTerm, self.searchClick_success, self.searchClick_failure);
        }
        else if (isEnter === 13) {
            alert(resx.AssociationPanel_SelectArtifact);
        }
    };
    AssocationBox.prototype.searchClick_success = function (data) {
        var self = this, newData = this.setCollapsibleProperties(data).map(function (item) {
            if (item.children)
                item.hideChildren = self.state.onlyShowFolders;
            item.hide = item.children ? false : self.state.onlyShowFolders;
            return item;
        }), cleanResults = [];
        var artifactTypeId = data.length ? data[0].artifactTypeId : this.state.artifactFilter;
        if (artifactTypeId == globalFunctions.artifactTypeEnum.testCase && data.length > 1) {
            artifactTypeId = data[1].artifactTypeId;
        }
        if (this.state.artifactFilter !== artifactTypeId) {
            this.getFolderList(artifactTypeId, this.props.projectId);
        }
        this.setState({
            results: cleanResults.concat(newData),
            resultsNotEmpty: data.length ? true : false,
            artifactFilter: artifactTypeId,
            searchCompleted: true,
            searchTermLastSent: this.state.searchTerm
        });
    };
    AssocationBox.prototype.searchClick_failure = function (error) {
        var messageBox = document.getElementById(this.props.messageBox);
        globalFunctions.display_error(messageBox, error);
    };
    AssocationBox.prototype.onHeaderClick = function (event) {
        var newResults = this.state.results.map(function (item) {
            if (item.id > 0) {
                item.selected = !item.selected;
            }
            return item;
        });
        this.setState({
            results: newResults,
        });
        this.selectAssociations(newResults);
    };
    AssocationBox.prototype.onRowClick = function (index, event) {
        if (this.state.results[index].id < 0)
            return;
        var newSelectedValue = !this.state.results[index].selected;
        var newResults = this.state.results;
        newResults[index].selected = newSelectedValue;
        this.setState({
            results: newResults
        });
        this.selectAssociations(newResults);
    };
    AssocationBox.prototype.onExpandCollapseGridClick = function (index, children, event) {
        event.stopPropagation();
        var newHideChildrenStatus = !this.state.results[index].hideChildren;
        var newData = this.state.results;
        newData[index].hideChildren = newHideChildrenStatus;
        var toggleShowHideData = this.toggleShowHideChildren(newData, children, newHideChildrenStatus);
        this.setState({
            results: toggleShowHideData
        });
    };
    AssocationBox.prototype.onGridRowNameMouseEnter = function (id, index, event) {
        if (!this.state.results[index].nameTooltip) {
            Inflectra.SpiraTest.Web.Services.Ajax.AssociationService.Association_RetrieveTooltip(this.props.projectId, this.state.artifactFilter, id, this.populateNameTooltip, ajaxCall_failure, index);
        }
        function ajaxCall_failure(err) {
        }
        ;
    };
    AssocationBox.prototype.populateNameTooltip = function (data, index) {
        var resultsDeepCopy = JSON.parse(JSON.stringify(this.state.results));
        resultsDeepCopy[index].nameTooltip = data;
        this.setState({ results: resultsDeepCopy });
    };
    AssocationBox.prototype.selectAssociations = function (results) {
        var selectedResults = results.filter(function (item) {
            return item.selected;
        })
            .map(function (item) {
            var obj = {
                projectId: item.projectId,
                artifactId: item.id,
                artifactTypeId: item.artifactTypeId
            };
            return obj;
        });
        this.setState({ selectionAssociations: selectedResults });
        this.setState({ selectionLength: selectedResults.length });
    };
    AssocationBox.prototype.setLinkType = function (newType, e) {
        this.setState({ linkType: newType });
    };
    AssocationBox.prototype.commentChange = function (event) {
        this.setState({ commentTerm: event.target.value });
    };
    AssocationBox.prototype.saveClick = function (isActive, e) {
        if (isActive) {
            var self = this, projectId = this.props.projectId, artifactTypeId = SpiraContext.ArtifactTypeId, artifactId = this.state.artifactId, displayType = this.props.displayType, artifactLinkTypeId = this.state.linkType, comment = this.state.commentTerm, selectionAssociations = this.state.selectionAssociations;
            var existingItemId = null;
            if (this.props.sortedGridId) {
                var grid = $find(this.props.sortedGridId);
                if (grid.get_selected_items && grid.get_selected_items() && grid.get_selected_items().length == 1) {
                    existingItemId = parseInt(grid.get_selected_items()[0]);
                }
            }
            if (!pageProps.isTestExecution) {
                Inflectra.SpiraTest.Web.Services.Ajax.AssociationService.Association_Add(projectId, artifactTypeId, artifactId, displayType, artifactLinkTypeId, comment, selectionAssociations, existingItemId, self.saveClick_success, self.saveClick_failure);
            }
            else {
                var incidentIds = selectionAssociations.map(function (item) {
                    return item.artifactId;
                }), testRunStepId = artifactId;
                var service = Inflectra.SpiraTest.Web.Services.Ajax.TestExecutionService || Inflectra.SpiraTest.Web.Services.Ajax.TestExecutionExploratoryService;
                service.TestExecution_AddIncidentAssociation(projectId, testRunStepId, incidentIds, self.saveClick_success, self.saveClick_failure);
            }
        }
    };
    AssocationBox.prototype.saveClick_success = function (data) {
        if (pageProps.associationWithoutPanel) {
            if (this.props.customSaveSuccessFunction) {
                this.props.customSaveSuccessFunction();
            }
        }
        else {
            $find(this.props.sortedGridId).load_data();
        }
        $("#" + this.props.lnkAddBtnId).removeClass('disabled');
        SpiraContext.uiState[this.props.domId].isMounted = false;
        ReactDOM.unmountComponentAtNode(document.getElementById(this.props.domId));
    };
    AssocationBox.prototype.saveClick_failure = function (error) {
        var messageBox = document.getElementById(this.props.messageBox);
        globalFunctions.display_error(messageBox, error);
    };
    AssocationBox.prototype.closeClick = function (e) {
        e.stopPropagation();
        $("#" + this.props.lnkAddBtnId).removeClass('disabled');
        SpiraContext.uiState[this.props.domId].isMounted = false;
        ReactDOM.unmountComponentAtNode(document.getElementById(this.props.domId));
    };
    AssocationBox.prototype.canCreateFromCurrentArtifact = function (displayType) {
        var canCreate = false;
        var currentArtifact = SpiraContext.ArtifactTypeId, artifactEnums = globalFunctions.artifactTypeEnum, createPermission = globalFunctions.permissionEnum.Create, isAuthorizedEnum = globalFunctions.authorizationStateEnum.authorized, displayEnums = globalFunctions.displayTypeEnum;
        if (!displayType) {
            return canCreate;
        }
        if (currentArtifact === artifactEnums.requirement && displayType === displayEnums.Requirement_TestCases) {
            canCreate = globalFunctions.isAuthorized(createPermission, artifactEnums.testCase) === isAuthorizedEnum;
        }
        else if (currentArtifact === artifactEnums.release && displayType === displayEnums.Release_TestCases) {
            canCreate = globalFunctions.isAuthorized(createPermission, artifactEnums.testCase) === isAuthorizedEnum && globalFunctions.isAuthorized(createPermission, artifactEnums.testSet) === isAuthorizedEnum;
        }
        else if (currentArtifact === artifactEnums.testCase && displayType === displayEnums.TestCase_Requirements) {
            canCreate = globalFunctions.isAuthorized(createPermission, artifactEnums.requirement) === isAuthorizedEnum;
        }
        else if (currentArtifact === artifactEnums.incident && displayType === displayEnums.ArtifactLink) {
            canCreate = globalFunctions.isAuthorized(createPermission, artifactEnums.requirement) === isAuthorizedEnum;
        }
        else if (currentArtifact === artifactEnums.task && displayType === displayEnums.ArtifactLink) {
            canCreate = globalFunctions.isAuthorized(createPermission, artifactEnums.incident) === isAuthorizedEnum;
        }
        return canCreate;
    };
    AssocationBox.prototype.createFromCurrentArtifact = function () {
        if (this.state.projectFilter === 0) {
            var self = this, serviceToUse = "";
            switch (this.state.newArtifactTypeToCreate) {
                case globalFunctions.artifactTypeEnum.testCase:
                    serviceToUse = Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService;
                    break;
                case globalFunctions.artifactTypeEnum.requirement:
                    serviceToUse = Inflectra.SpiraTest.Web.Services.Ajax.RequirementsService;
                    break;
                case globalFunctions.artifactTypeEnum.incident:
                    serviceToUse = Inflectra.SpiraTest.Web.Services.Ajax.IncidentsService;
                    break;
                case globalFunctions.artifactTypeEnum.testSet:
                    serviceToUse = Inflectra.SpiraTest.Web.Services.Ajax.TestCaseService;
                    break;
                default:
            }
            globalFunctions.display_spinner();
            serviceToUse && serviceToUse.AssociationPanel_CreateNewLinkedItem(self.props.projectId, self.state.artifactId, self.state.artifactTypeId, null, self.state.folderFilter || null, self.createFromCurrentArtifact_success, self.createFromCurrentArtifact_failure);
        }
    };
    AssocationBox.prototype.createFromCurrentArtifact_success = function (errorMessage, context) {
        globalFunctions.hide_spinner();
        if (errorMessage == '') {
            var newArtifactName = globalFunctions.getArtifactTypes(this.state.newArtifactTypeToCreate)[0].name, currentArtifactName = globalFunctions.getArtifactTypes(this.state.artifactTypeId)[0].name, message = resx.AssociationPanel_ArtifactXCreatedFromArtifactY.replace('{0}', newArtifactName).replace('{1}', currentArtifactName);
            $find(this.props.sortedGridId).load_data();
            var messageBox = document.getElementById(this.props.messageBox);
            globalFunctions.display_info_message(messageBox, message);
        }
        else {
            globalFunctions.display_error_message(messageBox, errorMessage);
        }
    };
    AssocationBox.prototype.createFromCurrentArtifact_failure = function (exception) {
        globalFunctions.hide_spinner();
        var messageBox = document.getElementById(this.props.messageBox);
        globalFunctions.display_error(messageBox, exception);
    };
    AssocationBox.prototype.render = function () {
        var isProjectActive = this.state.projects.length > 1, isArtifactActive = (this.props.displayType === globalFunctions.displayTypeEnum.ArtifactLink || this.props.displayType === globalFunctions.displayTypeEnum.Attachments || this.props.displayType === globalFunctions.displayTypeEnum.SourceCodeRevision_Associations || this.props.displayType === globalFunctions.displayTypeEnum.SourceCodeFile_Associations), isFolderActive = this.state.folders.length > 0 &&
            this.state.artifactFilter > 0 &&
            globalFunctions.getArtifactTypes(this.state.artifactFilter)[0].hasFolders, isSearchEnabled = this.state.artifactDropDownNotRequired ||
            this.state.artifactFilter > 0 ||
            this.state.searchTermIsValidToken, firstAvailableArtifactToken = this.state.artifacts[1].token;
        var searchButtonClasses = isSearchEnabled ? "btn primary-button" : "btn primary-button disabled", saveButtonClasses = this.state.selectionLength ? "btn primary-button" : "btn primary-button disabled";
        return (React.createElement("div", { class: "modal", id: "exampleModal1", style: { display: "block" }, "aria-labelledby": "exampleModalLabel", "aria-hidden": "true" },
            React.createElement("div", { class: "modal-dialog modal-dialog-centered modal-xl", role: "document" },
                React.createElement("div", { class: "modal-content top-30" },
                    React.createElement("div", { class: "modal-header" },
                        React.createElement("div", { class: "modal-title d-flex gap-2 align-items-center", id: "exampleModalLabel" },
                            " ",
                            React.createElement("img", { src: this.state.artifacts[1].name == 'Requirement' ? '/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/Requirement.svg' : this.state.artifacts[1].name == 'Release' ? '/ValidationMaster/App_Themes/ValidationMasterTheme/Images/Release.svg' : this.state.artifacts[1].name == 'Test Case' ? '/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/ReqDetails/Frame-1.svg' : '', alt: "" }),
                            React.createElement("span", { class: "fs-16 fw-bold" }, isArtifactActive ? resx.Associations : this.state.artifacts[1].name)),
                        React.createElement("button", { type: "button", class: "ti ti-x bg-transparent bg-border vm-midgrey p-1 rounded-circle", onClick: this.closeClick, "aria-label": "Close" })),
                    React.createElement("div", { class: "modal-body p-0" },
                        React.createElement("div", { class: "border-bottom p-3 fs-12 d-flex justify-content-between align-items-center" },
                            React.createElement("div", { class: "position-relative" },
                                React.createElement("img", { src: "/ValidationMaster/App_Themes/ValidationMasterTheme/NewImages/search-icon.svg", class: "position-absolute absolute-img", alt: "search icon" }),
                                React.createElement("input", { type: "text", className: " form-control pl-30 w-20", placeholder: resx.AssociationPanel_FilterPlaceholder + firstAvailableArtifactToken + ":4)", value: this.state.searchTerm, onChange: this.searchTermChange, onKeyUp: this.searchEnterPress })),
                            React.createElement("div", null,
                                isProjectActive ? (React.createElement(Assn_DropButton, { currentFilter: this.state.projectFilter, itemClickExternalFunction: this.browseProjectChange, items: this.state.projects }))
                                    : null,
                                isArtifactActive ?
                                    React.createElement(Assn_DropButton, { enabled: this.state.artifactsEnabled, currentFilter: this.state.artifactFilter, itemClickExternalFunction: this.browseArtifactChange, items: this.state.artifacts })
                                    : null,
                                isFolderActive ? (React.createElement(Assn_DropButton, { currentFilter: this.state.folderFilter, itemClickExternalFunction: this.browseFolderChange, items: this.state.folders, expandCollapseExternalFunction: this.folderExpandCollapseClick }))
                                    : null)),
                        React.createElement("div", { class: "p-3" },
                            React.createElement("div", { onClick: this.closeTopDropdowns },
                                this.state.searchCompleted ?
                                    React.createElement(Assn_Grid, { onExpandCollapseGridClick: this.onExpandCollapseGridClick, onGridRowNameMouseEnter: this.onGridRowNameMouseEnter, onHeaderClick: this.onHeaderClick, onRowClick: this.onRowClick, project: this.state.projectFilter, results: this.state.results, resultsNotEmpty: this.state.resultsNotEmpty, searchCompleted: this.state.searchCompleted, searchTerm: this.state.searchTerm, searchTermLastSent: this.state.searchTermLastSent })
                                    : null,
                                this.state.selectionLength ?
                                    React.createElement("p", { className: "alert alert-warning alert-narrow mt3 mb0" },
                                        this.state.selectionLength,
                                        " ",
                                        resx.Global_RowsSelected)
                                    : null,
                                this.state.showComment && this.state.results.length ?
                                    React.createElement("div", { className: "my3" },
                                        React.createElement("div", { className: "mb2 form-group" },
                                            React.createElement(Assn_DropButton, { currentFilter: this.state.linkType, itemClickExternalFunction: this.setLinkType, items: this.state.linkTypeList })),
                                        React.createElement("span", { className: "mr4" },
                                            resx.Global_Comment,
                                            ": "),
                                        React.createElement("input", { type: "text", className: "text-box mr3 w9 xxs-w8", value: this.state.commentTerm, onChange: this.commentChange }))
                                    : null,
                                React.createElement("div", { className: "d-flex justify-content-end mt3 align-items-center gap-6" },
                                    React.createElement("div", { className: "btn-group" },
                                        React.createElement("div", { className: "btn secondary-button", onClick: this.closeClick }, resx.Global_Cancel)),
                                    React.createElement("div", { className: "btn-group" },
                                        React.createElement("div", { className: saveButtonClasses, onClick: this.saveClick.bind(null, this.state.selectionLength) }, resx.Global_Save))),
                                this.state.isCreateFromCurrentArtifact ?
                                    React.createElement(Assn_NewArtifactFromThisItem, { artifactId: this.state.artifactId, artifactTypeId: this.state.artifactTypeId, newArtifactTypeToCreate: this.state.newArtifactTypeToCreate, createFromCurrentArtifact: this.createFromCurrentArtifact, isCurrentProject: this.state.projectFilter === 0 })
                                    : null)))))));
    };
    return AssocationBox;
}(React.Component));
var Assn_DropButton = (function (_super) {
    __extends(Assn_DropButton, _super);
    function Assn_DropButton(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            dropdownIsOpen: false
        };
        _this.toggleExpandCollapse = _this.toggleExpandCollapse.bind(_this);
        _this.collapseDropdown = _this.collapseDropdown.bind(_this);
        _this.onDropDownBlur = _this.onDropDownBlur.bind(_this);
        _this.onItemClick = _this.onItemClick.bind(_this);
        _this.onItemExpandCollapseClick = _this.onItemExpandCollapseClick.bind(_this);
        return _this;
    }
    Assn_DropButton.prototype.bindKeyboardShortcuts = function () {
        Mousetrap.bind('down', function downKeyInDropDown() {
            return false;
        });
        Mousetrap.bind('up', function upKeyInDropDown() {
            return false;
        });
    };
    Assn_DropButton.prototype.unbindKeyboardShortcuts = function () {
        Mousetrap.unbind('down');
        Mousetrap.unbind('up');
    };
    Assn_DropButton.prototype.toggleExpandCollapse = function (e) {
        e.stopPropagation();
        this.state.dropdownIsOpen ? this.unbindKeyboardShortcuts() : this.bindKeyboardShortcuts();
        this.setState({ dropdownIsOpen: !this.state.dropdownIsOpen });
    };
    Assn_DropButton.prototype.collapseDropdown = function (e) {
        this.setState({ dropdownIsOpen: false });
    };
    Assn_DropButton.prototype.onDropDownBlur = function (e) {
        var _this = this;
        var currentTarget = e.currentTarget;
        this.unbindKeyboardShortcuts();
        setTimeout(function () {
            if (!currentTarget.contains(document.activeElement)) {
                _this.collapseDropdown(null);
            }
        }, 0);
    };
    Assn_DropButton.prototype.onItemClick = function (filterId, enabled, e) {
        this.props.itemClickExternalFunction(filterId, enabled, e);
        this.collapseDropdown(e);
    };
    Assn_DropButton.prototype.onItemExpandCollapseClick = function (index, children, event) {
        event.preventDefault();
        event.stopPropagation();
        var newHideChildrenStatus = !this.props.items[index].hideChildren, newData = this.props.items;
        newData[index].hideChildren = newHideChildrenStatus;
        this.props.expandCollapseExternalFunction(children, newData, newHideChildrenStatus);
    };
    Assn_DropButton.prototype.render = function () {
        var self = this, dropdownClasses = this.state.dropdownIsOpen ? "dropdown-menu mh9 ov-y-auto db dropdwn-style" : "dropdown-menu dn", ariaExpanded = this.state.dropdownIsOpen ? "false" : "true", hasItems = this.props.items.length > 1 && this.props.items[1] != undefined, activeItem = hasItems ?
            this.props.items.filter(function (item) {
                return item.id === self.props.currentFilter;
            })[0]
                ||
                    this.props.items.filter(function (item) {
                        return item.id === self.props.items[0].id;
                    })[0]
            : this.props.items[0], itemNodes = hasItems ?
            this.props.items.map(function (item, index) {
                var enabled = self.props.enabled ? globalFunctions.findItemInArray(self.props.enabled, item.id) : true;
                return (React.createElement("li", null,
                    React.createElement(Assn_BtnItem, { children: item.children, clickFunction: self.onItemClick, enabled: enabled, filter: self.props.currentFilter, hide: item.hide, hideChildren: item.hideChildren, expandCollapseClick: self.onItemExpandCollapseClick, id: item.id, indent: item.indentLevel, index: index, key: item.id, name: item.name })));
            })
            : null;
        return (React.createElement("div", { className: "btn-group", onBlur: this.onDropDownBlur },
            React.createElement("button", { "aria-expanded": ariaExpanded, "aria-haspopup": "true", className: "btn btn-flat dropdown-toggle d-flex align-items-center fs-14 bg-border-alltype", onClick: this.toggleExpandCollapse, type: "button" },
                activeItem.name,
                hasItems ?
                    React.createElement("span", { className: "caret" })
                    : null),
            hasItems ?
                React.createElement("ul", { className: dropdownClasses }, itemNodes)
                : null));
    };
    return Assn_DropButton;
}(React.Component));
function Assn_BtnItem(props) {
    var indentPx, indentStyle;
    var itemClasses = props.hide ? "dn" : props.enabled ? (props.filter === props.id ? "active" : null) : "disabled", expandCollapseClasses = props.children ? "w4 mln4 pointer fas fa-fw orange-hover" + (props.hideChildren ? " fa-caret-right" : " fa-caret-down") : "";
    if (props.indent) {
        indentPx = ((props.indent.length - 1) / 2);
        indentStyle = {
            marginLeft: indentPx + "em",
            marginBottom: 0
        };
    }
    ;
    return (React.createElement("a", { className: itemClasses, style: indentStyle, href: "javascript:void(0)", onClick: function () { return props.clickFunction(props.id, props.enabled); } },
        props.children ?
            React.createElement("span", { className: expandCollapseClasses, onClick: props.expandCollapseClick.bind(null, props.index, props.children) })
            : null,
        props.name));
}
function Assn_Grid(props) {
    var self = this;
    var displayMessage = !props.resultsNotEmpty && props.searchCompleted;
    var rowNodes = props.results.map(function (item, index) {
        var mainIcon = globalFunctions.getArtifactTypes(item.artifactTypeId)[0].image, subIcon = item.artifactSubType ? globalFunctions.getArtifactTypes(item.artifactTypeId, item.artifactSubType)[0].image : null, iconToUse = subIcon || mainIcon;
        return (React.createElement(Assn_GridRow, { children: item.children, id: item.id, icon: SpiraContext.BaseThemeUrl + iconToUse, indent: item.indentLevel, index: index, isDisabled: item.id < 0, hide: item.hide, hideChildren: item.hideChildren, key: index, name: item.name, nameTooltip: item.nameTooltip, onGridRowNameMouseEnter: props.onGridRowNameMouseEnter, onRowClick: props.onRowClick, projectId: item.projectId, projectName: item.projectName, selected: item.selected, token: globalFunctions.getArtifactTypes(item.artifactTypeId)[0].token, onExpandCollapseGridClick: props.onExpandCollapseGridClick, type: item.artifactTypeId }));
    });
    var rowMessage = React.createElement(Assn_GridRow_Message, { text: resx.AssociationPanel_NoUnassociatedResults + ": " + props.searchTermLastSent });
    return (React.createElement("div", { className: "table-responsive height-8rem resize-v scrollbox" },
        React.createElement("table", { className: "table DataGrid DataGrid-no-bands always-visible" },
            !displayMessage ?
                React.createElement("thead", null,
                    React.createElement("tr", { className: "Header" },
                        React.createElement("th", { className: "Checkbox", onClick: props.onHeaderClick },
                            React.createElement("span", { className: "fas fa-check pointer", "data-toggle": "tooltip", "data-placement": "bottom", title: resx.Global_SelectAll })),
                        React.createElement("th", null, resx.Global_ID),
                        React.createElement("th", null, resx.Global_Name),
                        React.createElement("th", { className: "hidden-xs" }, resx.Global_Project)))
                : null,
            React.createElement("tbody", null, displayMessage ? rowMessage : rowNodes))));
}
function Assn_GridRow(props) {
    var indentPx, indentStyle;
    if (props.indent) {
        indentPx = ((props.indent.length - 1) / 2);
        indentStyle = {
            marginLeft: indentPx + "em"
        };
    }
    ;
    var rowClasses = props.hide ? "dn" : props.isDisabled ? "is-disabled silver" : props.selected ? "Highlighted" : "", expandCollapseClasses = props.children ? "w4 mln4 pointer fas fa-fw" + (props.hideChildren ? " fa-caret-right" : " fa-caret-down") : "";
    return (React.createElement("tr", { className: rowClasses, onClick: props.isDisabled ? null : props.onRowClick.bind(null, props.index) },
        React.createElement("td", null,
            React.createElement("input", { type: "checkbox", checked: props.selected, disabled: props.isDisabled, defaultChecked: props.selected })),
        React.createElement("td", { className: "w6" },
            props.token,
            ":",
            Math.abs(props.id)),
        React.createElement("td", null,
            React.createElement("span", { className: "has-tooltip db", onMouseEnter: props.isDisabled ? null : props.onGridRowNameMouseEnter.bind(null, props.id, props.index), style: indentStyle },
                props.children ?
                    React.createElement("span", { className: expandCollapseClasses, onClick: props.onExpandCollapseGridClick.bind(null, props.index, props.children) })
                    : null,
                React.createElement("img", { src: props.icon, className: "mr3 w4 h4" }),
                props.name || resx.Global_None2,
                props.nameTooltip ?
                    React.createElement("div", { className: "is-tooltip", dangerouslySetInnerHTML: { __html: filterXSS(props.nameTooltip) } })
                    : null)),
        React.createElement("td", { className: "hidden-xs" },
            React.createElement("span", { "data-toggle": "tooltip", "data-placement": "bottom", title: "PR:" + props.projectId }, props.projectName))));
}
function Assn_GridRow_Message(props) {
    return (React.createElement("tr", null,
        React.createElement("td", null,
            React.createElement("div", { className: "font-125 py3 px4" },
                "~ ",
                props.text,
                " ~"))));
}
function Assn_NewArtifactFromThisItem(props) {
    var currentArtifactType = globalFunctions.getArtifactTypes(props.artifactTypeId)[0], currentArtifactIcon = SpiraContext.BaseThemeUrl + currentArtifactType.image, currentArtifactName = currentArtifactType.name, newArtifactName = globalFunctions.getArtifactTypes(props.newArtifactTypeToCreate)[0].name, newArtifactIcon = SpiraContext.BaseThemeUrl + globalFunctions.getArtifactTypes(props.newArtifactTypeToCreate)[0].image, classes = props.isCurrentProject ? "btn primary-button pull-right" : "btn primary-button pull-right disabled", tooltip = resx.AssociationPanel_CreateArtifactXFromArtifactYTooltip.replace('{0}', newArtifactName).replace('{1}', currentArtifactName), text = resx.AssociationPanel_CreateArtifactXFromArtifactY.replace('{0}', newArtifactName).replace('{1}', currentArtifactName);
    return (React.createElement("div", { className: classes, "data-placement": "bottom", "data-toggle": "tooltip", onClick: props.createFromCurrentArtifact, title: tooltip },
        React.createElement("span", { className: "fas fa-plus pr3" }),
        React.createElement("span", { className: "pr3" }, text)));
}
//# sourceMappingURL=AssociationPanel.js.map