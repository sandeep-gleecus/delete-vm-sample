/***************************************************************
**	Insert script for table TST_PROJECT_COLLECTION_ENTRY
***************************************************************/
INSERT INTO TST_PROJECT_COLLECTION_ENTRY
(
USER_ID, PROJECT_ID, PROJECT_COLLECTION_ID, ENTRY_KEY, ENTRY_VALUE, ENTRY_TYPE_CODE
)
VALUES
(
2, 1, 1, 'SortExpression', 'PriorityName DESC', 18
),
(
2, 1, 2, 'IncidentTypeId', '2', 9
),
(
2, 1, 2, 'OpenerId', '2', 9
)
GO

