/***************************************************************
**	Insert script for table TST_TEST_SET_PARAMETER
***************************************************************/
INSERT INTO TST_TEST_SET_PARAMETER
(
TEST_SET_ID, TEST_CASE_PARAMETER_ID, VALUE
)
VALUES
(
1, 4, 'Safari'
),
(
2, 4, 'Microsoft Edge'
),
(
5, 4, 'Chrome'
),
(
6, 4, 'Firefox'
),
(
3, 4, 'Internet Explorer'
),
(
4, 4, 'Firefox'
),
(
1, 2, 'librarian'
),
(
2, 2, 'librarian'
),
(
5, 2, 'librarian'
),
(
6, 2, 'borrower'
),
(
3, 2, 'borrower'
),
(
4, 2, 'borrower'
),
(
1, 3, 'librarian'
),
(
2, 3, 'librarian'
),
(
5, 3, 'librarian'
),
(
6, 3, 'borrower'
),
(
3, 3, 'borrower'
),
(
4, 3, 'borrower'
)
GO

