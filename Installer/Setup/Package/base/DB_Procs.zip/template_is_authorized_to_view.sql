-- ================================================================
-- Author:			Inflectra Corporation
-- Business Object: TemplateManager
-- Description:		Is the user authorized to view artifacts that are part of the template
-- ================================================================
IF OBJECT_ID ( 'TEMPLATE_IS_AUTHORIZED_TO_VIEW', 'P' ) IS NOT NULL 
    DROP PROCEDURE TEMPLATE_IS_AUTHORIZED_TO_VIEW;
GO
CREATE PROCEDURE TEMPLATE_IS_AUTHORIZED_TO_VIEW
	@UserId INT,
	@ProjectTemplateId INT
AS
BEGIN
	IF EXISTS(
		SELECT TMP.PROJECT_TEMPLATE_ID
		FROM TST_PROJECT_TEMPLATE TMP
			INNER JOIN TST_PROJECT PRJ ON TMP.PROJECT_TEMPLATE_ID = PRJ.PROJECT_TEMPLATE_ID
			INNER JOIN TST_PROJECT_USER PRU ON PRJ.PROJECT_ID = PRU.PROJECT_ID
			INNER JOIN TST_PROJECT_ROLE PRR ON PRU.PROJECT_ROLE_ID = PRR.PROJECT_ROLE_ID
		WHERE
			PRU.USER_ID = @UserId AND
			TMP.PROJECT_TEMPLATE_ID = @ProjectTemplateId AND
			PRR.IS_ACTIVE = 1 AND
			TMP.IS_ACTIVE = 1
			)
	BEGIN
		SELECT CAST (1 AS BIT) AS IS_AUTHORIZED
	END
	ELSE
	BEGIN
		SELECT CAST (0 AS BIT) AS IS_AUTHORIZED
	END
END
GO
