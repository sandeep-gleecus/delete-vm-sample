var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var resx = Inflectra.SpiraTest.Web.GlobalResources;
var RctMessagePopup = (function (_super) {
    __extends(RctMessagePopup, _super);
    function RctMessagePopup(props) {
        var _this = _super.call(this, props) || this;
        _this.handleClose = _this.handleClose.bind(_this);
        _this.confirm = _this.confirm.bind(_this);
        return _this;
    }
    RctMessagePopup.prototype.componentDidMount = function () {
        var _this = this;
        Mousetrap.bind("escape", function (e) { return _this.handleClose(); });
    };
    RctMessagePopup.prototype.handleClose = function () {
        if (this.props.confirm) {
            this.props.confirm(false, this.props.refs || null);
        }
        globalFunctions.dlgGlobalDynamicClear();
        Mousetrap.unbind("escape");
    };
    RctMessagePopup.prototype.hasItems = function () {
        return this.props.items && this.props.items.length > 0 && this.props.items[0] != undefined;
    };
    RctMessagePopup.prototype.selectedItem = function () {
        var existingItemId = null;
        if (this.props.sortedGridId) {
            existingItemId = 1;
            var grid = $find(this.props.sortedGridId);
            if (grid.get_selected_items && grid.get_selected_items() && grid.get_selected_items().length == 1) {
                existingItemId = parseInt(grid.get_selected_items()[0]);
            }
        }
        return existingItemId;
    };
    RctMessagePopup.prototype.confirm = function () {
        if (this.props.confirm) {
            this.props.confirm(true, this.props.refs || null);
        }
        globalFunctions.dlgGlobalDynamicClear();
        Mousetrap.unbind("escape");
    };
    RctMessagePopup.prototype.render = function () {
        var selectedItem = this.props.count;
        var isdelete = this.props.isdelete;
        var Test = this.props.Test;
        if (Test == "DeleteAll") {
            if (selectedItem == 0) {
                return (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                        React.createElement("div", { class: "modal-content" },
                            React.createElement("div", { class: "modal-body p-0 vm-redlight-bg rounded-2" },
                                React.createElement("div", { class: "pad-10 d-flex align-items-center justify-content-between" },
                                    React.createElement("div", { class: "d-flex align-items-center gap-2" },
                                        React.createElement("i", { class: "ti ti-info-circle vm-red d-flex me-2" }),
                                        React.createElement("div", { class: "fs-14" },
                                            React.createElement("div", { class: " fw-medium vm-reddark mb-1" }, resx.DeletePopUp_CerificationSay),
                                            React.createElement("div", { class: "textcolor" }, resx.Global_SelectOneCheckBoxForDelete))),
                                    React.createElement("button", { type: "button", class: "ti ti-x bg-transparent bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })))))));
            }
            else if (selectedItem == 1) {
                return (React.createElement(React.Fragment, null,
                    this.props.isModal &&
                        React.createElement("div", { className: "DialogBoxModalBackground visibility-none fade-in-50 fixed left0 right0 top0 bottom0", onClick: this.handleClose }),
                    React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                        React.createElement("div", { class: "modal-dialog" },
                            React.createElement("div", { class: "modal-content" },
                                React.createElement("div", { class: "modal-header" },
                                    React.createElement("div", { class: "modal-title fs-14 fw-bold", id: "exampleModalLabel" },
                                        resx.DeletePopUp_DeleConfirmation,
                                        " "),
                                    React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })),
                                React.createElement("div", { class: "modal-body p-0" },
                                    React.createElement("div", { class: "p-3" },
                                        React.createElement("div", { class: "mb-3 fs-14 fw-medium" }, this.props.message),
                                        React.createElement("div", { class: "fs-14 fw-medium" }, resx.DeletePopUp_deletethisItems))),
                                React.createElement("div", { class: "d-flex justify-content-end gap-2 p-3 border-top" },
                                    React.createElement("button", { type: "button", class: "btn secondary-button width-style", onClick: this.handleClose }, resx.Global_Cancel),
                                    React.createElement("button", { type: "button", class: "btn danger-button width-style", onClick: this.confirm }, resx.DeletePopUp_delete)))))));
            }
            else
                return (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                        React.createElement("div", { class: "modal-dialog" },
                            React.createElement("div", { class: "modal-content" },
                                React.createElement("div", { class: "modal-header" },
                                    React.createElement("div", { class: "modal-title fs-14 fw-bold", id: "exampleModalLabel" }, resx.DeletePopUp_DeleConfirmation),
                                    React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })),
                                React.createElement("div", { class: "modal-body p-0" },
                                    React.createElement("div", { class: "p-3" },
                                        React.createElement("div", { class: "mb-3 fs-14 fw-medium" }, this.props.message),
                                        React.createElement("div", { class: "fs-14 fw-medium" },
                                            resx.DeletePopUp_Deletingthis,
                                            " ",
                                            selectedItem,
                                            " ",
                                            resx.DeletePopUp_Pleaseconfirm))),
                                React.createElement("div", { class: "d-flex justify-content-end gap-2 p-3 border-top" },
                                    React.createElement("button", { type: "button", class: "btn secondary-button width-style", onClick: this.handleClose }, resx.Global_Cancel),
                                    React.createElement("button", { type: "button", class: "btn danger-button width-style", onClick: this.confirm },
                                        resx.DeletePopUp_delete,
                                        " (",
                                        selectedItem,
                                        ")")))))));
        }
        else if (Test == "Revert") {
            if (this.props.message == "hyslist") {
                if (selectedItem == 0) {
                    return (React.createElement(React.Fragment, null,
                        React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                            React.createElement("div", { class: "modal-content" },
                                React.createElement("div", { class: "modal-body p-0 vm-redlight-bg rounded-2" },
                                    React.createElement("div", { class: "pad-10 d-flex align-items-center justify-content-between" },
                                        React.createElement("div", { class: "d-flex align-items-center gap-2" },
                                            React.createElement("i", { class: "ti ti-info-circle vm-red d-flex me-2" }),
                                            React.createElement("div", { class: "fs-14" },
                                                React.createElement("div", { class: " fw-medium vm-reddark mb-1" }, resx.DeletePopUp_CerificationSay),
                                                React.createElement("div", { class: "textcolor" },
                                                    resx.DeletePopUp_CheckBoxselect,
                                                    " ",
                                                    Test,
                                                    " ",
                                                    resx.DeletePopUp_Command))),
                                        React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-transparent vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })))))));
                }
                else {
                    return (React.createElement(React.Fragment, null,
                        this.props.isModal &&
                            React.createElement("div", { className: "DialogBoxModalBackground visibility-none fade-in-50 fixed left0 right0 top0 bottom0", onClick: this.handleClose }),
                        React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                            React.createElement("div", { class: "modal-dialog" },
                                React.createElement("div", { class: "modal-content" },
                                    React.createElement("div", { class: "modal-header" },
                                        React.createElement("div", { class: "modal-title fs-14 fw-bold", id: "exampleModalLabel" },
                                            resx.DeletePopUp_Confirmation,
                                            " "),
                                        React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })),
                                    React.createElement("div", { class: "modal-body p-0" },
                                        React.createElement("div", { class: "p-3" },
                                            React.createElement("div", { class: "mb-3 fs-14 fw-medium" }, resx.DeletePopUp_RevertitemsText))),
                                    React.createElement("div", { class: "d-flex justify-content-end gap-2 p-3 border-top" },
                                        React.createElement("button", { type: "button", class: "btn primary-button width-style", onClick: this.confirm }, resx.DeletePopUp_ok),
                                        React.createElement("button", { type: "button", class: "btn secondary-button width-style", onClick: this.handleClose }, resx.Global_Cancel)))))));
                }
            }
            else {
                return (React.createElement(React.Fragment, null,
                    this.props.isModal &&
                        React.createElement("div", { className: "DialogBoxModalBackground visibility-none fade-in-50 fixed left0 right0 top0 bottom0", onClick: this.handleClose }),
                    React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                        React.createElement("div", { class: "modal-dialog" },
                            React.createElement("div", { class: "modal-content" },
                                React.createElement("div", { class: "modal-header" },
                                    React.createElement("div", { class: "modal-title fs-14 fw-bold", id: "exampleModalLabel" },
                                        resx.DeletePopUp_Confirmation,
                                        " "),
                                    React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })),
                                React.createElement("div", { class: "modal-body p-0" },
                                    React.createElement("div", { class: "p-3" },
                                        React.createElement("div", { class: "mb-3 fs-14 fw-medium" }, this.props.message))),
                                React.createElement("div", { class: "d-flex justify-content-end gap-2 p-3 border-top" },
                                    React.createElement("button", { type: "button", class: "btn primary-button width-style", onClick: this.confirm }, resx.DeletePopUp_ok),
                                    React.createElement("button", { type: "button", class: "btn secondary-button width-style", onClick: this.handleClose }, resx.Global_Cancel)))))));
            }
        }
        else {
            return (React.createElement(React.Fragment, null,
                this.props.isModal &&
                    React.createElement("div", { className: "DialogBoxModalBackground visibility-none fade-in-50 fixed left0 right0 top0 bottom0", onClick: this.handleClose }),
                React.createElement("div", { className: "u-popup u-popup_down mw960 min-w9 max-h-insideHead-xs is-open" },
                    React.createElement("div", { class: "modal-dialog" },
                        React.createElement("div", { class: "modal-content" },
                            React.createElement("div", { class: "modal-header" },
                                React.createElement("div", { class: "modal-title fs-14 fw-bold", id: "exampleModalLabel" },
                                    resx.DeletePopUp_Confirmation,
                                    " "),
                                React.createElement("button", { type: "button", class: "ti ti-x bg-white bg-border vm-midgrey p-1 rounded-circle", "data-bs-dismiss": "modal", "aria-label": "Close", onClick: this.handleClose })),
                            React.createElement("div", { class: "modal-body p-0" },
                                React.createElement("div", { class: "p-3" },
                                    React.createElement("div", { class: "mb-3 fs-14 fw-bold" }, this.props.message))),
                            React.createElement("div", { class: "d-flex justify-content-end gap-2 p-3 border-top" },
                                React.createElement("button", { type: "button", class: "btn primary-button width-style", onClick: this.confirm }, resx.DeletePopUp_ok),
                                React.createElement("button", { type: "button", class: "btn secondary-button width-style", onClick: this.handleClose }, resx.Global_Cancel)))))));
        }
    };
    return RctMessagePopup;
}(React.Component));
//# sourceMappingURL=rct_comp_messagePopup.js.map