/***************************************************************
**	Insert script for table TST_DATA_SYNC_PROJECT
***************************************************************/
INSERT INTO TST_DATA_SYNC_PROJECT
(
DATA_SYNC_SYSTEM_ID, PROJECT_ID, EXTERNAL_KEY, ACTIVE_YN
)
VALUES
(
1, 1, 'LIS', 'N'
),
(
1, 2, 'SMP', 'N'
),
(
2, 1, 'library', 'N'
),
(
3, 1, 'Library Information System', 'N'
)
GO

