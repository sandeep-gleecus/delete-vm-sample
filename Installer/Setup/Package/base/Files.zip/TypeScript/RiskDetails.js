function riskDetails_ajxWorkflowOperations_operationExecuted(transitionId, isStatusOpen) {
    riskDetails_update_closed_date(isStatusOpen);
}
function riskDetails_ajxFormManager_operationReverted(statusId, isStatusOpen) {
    riskDetails_update_closed_date(isStatusOpen);
}
function riskDetails_update_closed_date(isStatusOpen) {
    var closedDate = $find(datClosedDate_id);
    if (isStatusOpen) {
        closedDate.clearDatetime();
    }
    else {
        closedDate.selectCurrent();
    }
}
function riskDetails_btnFind_click() {
    var newArtifactId = parseInt($('#' + txtRiskId_id).val());
    if (newArtifactId && newArtifactId != NaN && newArtifactId > 0) {
        Inflectra.SpiraTest.Web.Services.Ajax.RisksService.Risk_CheckExists(SpiraContext.ProjectId, newArtifactId, riskDetails_btnFind_click_success, riskDetails_btnFind_click_failure, newArtifactId);
    }
}
function riskDetails_btnFind_click_success(exists, newArtifactId) {
    if (exists) {
        var ajxFormManager = $find(ajxFormManager_id);
        ajxFormManager.set_suppressErrors(true);
        SpiraContext.ArtifactId = newArtifactId;
        ajxFormManager.set_primaryKey(newArtifactId, true);
        ajxFormManager.load_data();
        if (history && history.pushState) {
            var newRiskUrl = urlTemplate_artifactRedirectUrl.replace(globalFunctions.artifactIdToken, newArtifactId.toString());
            history.pushState(null, null, newRiskUrl);
        }
    }
    else {
        alert(resx.RiskDetails_RiskNotFound);
    }
}
function riskDetails_btnFind_click_failure(ex) {
    var msg = $get(lblMessage_id);
    globalFunctions.display_error(msg, ex);
}
var riskDetails_riskId = -1;
function updatePageContent() {
    if (SpiraContext.Mode == 'new') {
        $('#divMitigationsPanel').hide();
        $('#Commentsdiv').hide();
    }
    else {
        $('#divMitigationsPanel').show();
        $('#Commentsdiv').show();
        var isDisabled = false;
        var ajxFormManager = $find(ajxFormManager_id);
        var isCreatorOrOwner = ajxFormManager.get_isArtifactCreatorOrOwner();
        var authorizedViewTS = globalFunctions.isAuthorized(globalFunctions.permissionEnum.Modify, globalFunctions.artifactTypeEnum.risk);
        if (authorizedViewTS == globalFunctions.authorizationStateEnum.prohibited) {
            isDisabled = true;
        }
        if (authorizedViewTS == globalFunctions.authorizationStateEnum.limited && !isCreatorOrOwner) {
            isDisabled = true;
        }
        if (isDisabled) {
            document.getElementById(lnkStepInsert_id).setAttribute("disabled", "disabled");
            document.getElementById(lnkStepDelete_id).setAttribute("disabled", "disabled");
            document.getElementById(lnkStepCopy_id).setAttribute("disabled", "disabled");
        }
        else {
            document.getElementById(lnkStepInsert_id).removeAttribute("disabled");
            document.getElementById(lnkStepDelete_id).removeAttribute("disabled");
            document.getElementById(lnkStepCopy_id).removeAttribute("disabled");
        }
        var grdMitigations = $find(grdMitigations_id);
        if (riskDetails_riskId != SpiraContext.ArtifactId) {
            grdMitigations.set_allowEdit(!isDisabled);
            var filters = {};
            filters[globalFunctions.keyPrefix + 'RiskId'] = globalFunctions.serializeValueInt(SpiraContext.ArtifactId);
            grdMitigations.set_standardFilters(filters);
            grdMitigations.load_data();
            riskDetails_riskId = SpiraContext.ArtifactId;
        }
    }
}
$(document).ready(function () {
    if (SpiraContext.PlaceholderId && SpiraContext.PlaceholderId > 0) {
        $('#' + hdnPlaceholderId_id).val(SpiraContext.PlaceholderId);
    }
});
//# sourceMappingURL=RiskDetails.js.map