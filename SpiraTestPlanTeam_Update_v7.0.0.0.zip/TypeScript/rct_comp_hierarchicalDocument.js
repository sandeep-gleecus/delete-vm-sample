var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var lastId = 0;
function newId(prefix) {
    lastId++;
    return "".concat(prefix, "_").concat(lastId);
}
var react_HierarchicalDocument = {
    documentDomId: '',
    messageBoxId: '',
    webServiceClass: '',
    artifactToken: '',
    artifactType: 0,
    itemImage: '',
    alternateItemImage: '',
    summaryItemImage: '',
    urlTemplate: '',
    urlUploadTemplate: '',
    loadData: function () {
        ReactDOM.render(React.createElement(HierarchicalDocument, { domId: this.documentDomId, projectId: SpiraContext.ProjectId, messageBoxId: this.messageBoxId, webServiceClass: this.webServiceClass, artifactToken: this.artifactToken, artifactType: this.artifactType, itemImage: this.itemImage, alternateItemImage: this.alternateItemImage, ref: function (rct_comp_hierarchicalDocument) { window.rct_comp_hierarchicalDocument = rct_comp_hierarchicalDocument; }, showOutlineCode: this.showOutlineCode, parentRequirementId: this.parentRequirementId || null, summaryItemImage: this.summaryItemImage, urlTemplate: this.urlTemplate, urlUploadTemplate: this.urlUploadTemplate }), document.getElementById(this.documentDomId));
    }
};
var HierarchicalDocument = (function (_super) {
    __extends(HierarchicalDocument, _super);
    function HierarchicalDocument(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            itemsAll: null,
            itemsIdsAll: null,
            itemsVisible: null,
            headerFields: ["RequirementStatusId", "RequirementTypeId", "ImportanceId", "OwnerId"],
            visibleCount: null,
            totalCount: null,
            parentRequirementId: _this.props.parentRequirementId,
            visibleStartRow: null,
            visibleEndRow: null,
            visiblePage: 1,
            visiblePageInput: 1,
            idsInEditMode: [],
            changesCount: 0,
        };
        _this.reload = _this.reload.bind(_this);
        _this.loadData = _this.loadData.bind(_this);
        _this.loadData_success = _this.loadData_success.bind(_this);
        _this.focusOnRequirement = _this.focusOnRequirement.bind(_this);
        _this.focusOnRequirementConfirmed = _this.focusOnRequirementConfirmed.bind(_this);
        _this.pageMove = _this.pageMove.bind(_this);
        _this.pageMoveConfirmed = _this.pageMoveConfirmed.bind(_this);
        _this.handlePageInputChange = _this.handlePageInputChange.bind(_this);
        _this.handlePageInputKeyDown = _this.handlePageInputKeyDown.bind(_this);
        _this.startRow = 1;
        _this.retrieveSize = 50;
        _this.pageSize = 50;
        _this.maxRowsToRetrieve = 5000;
        _this.userCanBulkEdit = globalFunctions.isAuthorized(globalFunctions.permissionEnum.BulkEdit, _this.props.artifactType) == globalFunctions.authorizationStateEnum.authorized;
        _this.editModeToggle = _this.editModeToggle.bind(_this);
        _this.updateChangesCount = _this.updateChangesCount.bind(_this);
        _this.pageMoveTemp = null;
        _this.focusChangeIdTemp = null;
        return _this;
    }
    HierarchicalDocument.prototype.componentDidMount = function () {
        this.loadData();
    };
    HierarchicalDocument.prototype.reload = function () {
        var _this = this;
        this.setState({
            itemsAll: null,
            itemsIdsAll: null,
            itemsVisible: null,
            visibleStartRow: 1,
            visibleEndRow: null,
            visiblePage: 1,
            visiblePageInput: 1
        }, function () {
            _this.startRow = 1;
            _this.loadData();
        });
    };
    HierarchicalDocument.prototype.loadData = function () {
        globalFunctions.display_spinner();
        var self = this;
        this.props.webServiceClass.HierarchicalDocument_Retrieve(this.props.projectId, this.startRow, this.retrieveSize, this.state.parentRequirementId, self.loadData_success.bind(self), self.loadData_failure.bind(self));
    };
    HierarchicalDocument.prototype.loadDataLazy = function () {
        this.startRow += this.retrieveSize;
        var self = this;
        this.props.webServiceClass.HierarchicalDocument_Retrieve(this.props.projectId, this.startRow, this.retrieveSize, this.state.parentRequirementId, self.loadData_success.bind(self), self.loadData_failure.bind(self));
    };
    HierarchicalDocument.prototype.focusOnRequirement = function (parentRequirementId, forceMove) {
        var _this = this;
        if (this.state.changesCount === 0 || forceMove) {
            var sidebarRequirement = null;
            if (this.state.parentRequirementId) {
                sidebarRequirement = document.getElementById("lstPackages_artifactId-" + this.state.parentRequirementId);
            }
            if (!this.state.parentRequirementId || !sidebarRequirement) {
                sidebarRequirement = document.getElementById("lstPackages_artifactRoot");
            }
            if (sidebarRequirement) {
                sidebarRequirement.classList.remove("list-item-selected");
            }
            this.setState({ parentRequirementId: parentRequirementId || null }, function () {
                _this.reload();
            });
        }
        else {
            this.focusChangeIdTemp = parentRequirementId;
            globalFunctions.globalConfirm(resx.AjxFormManager_UnsavedChanges, "info", this.focusOnRequirementConfirmed);
        }
    };
    HierarchicalDocument.prototype.focusOnRequirementConfirmed = function (shouldMove) {
        if (shouldMove) {
            this.focusOnRequirement(this.focusChangeIdTemp, true);
        }
        else {
            this.focusChangeIdTemp = null;
        }
    };
    HierarchicalDocument.prototype.loadData_success = function (newData) {
        var _this = this;
        globalFunctions.hide_spinner();
        var newDataIds = newData.items.map(function (x) { return x.primaryKey; });
        var fullItemsArray = this.state.itemsAll ? __spreadArray(__spreadArray([], this.state.itemsAll, true), newData.items, true) : newData.items;
        var fullIdsArray = this.state.itemsIdsAll ? __spreadArray(__spreadArray([], this.state.itemsIdsAll, true), newDataIds, true) : newDataIds;
        if (!this.state.itemsAll) {
            var sidebarRequirement = null;
            if (this.state.parentRequirementId) {
                sidebarRequirement = document.getElementById("lstPackages_artifactId-" + this.state.parentRequirementId);
            }
            if (!this.state.parentRequirementId || !sidebarRequirement) {
                sidebarRequirement = document.getElementById("lstPackages_artifactRoot");
            }
            if (sidebarRequirement) {
                sidebarRequirement.classList.add("list-item-selected");
            }
            this.setState({
                totalCount: newData.totalCount,
                visibleCount: newData.visibleCount,
            });
        }
        this.setState({
            itemsAll: fullItemsArray,
            itemsIdsAll: fullIdsArray
        }, function () {
            if (!_this.state.itemsVisible && (_this.state.itemsAll.length >= _this.pageSize || _this.state.itemsAll.length == newData.totalCount)) {
                _this.setVisibleData(_this.state.itemsAll, _this.pageSize, _this.state.visiblePage, newData.totalCount, null, null);
            }
        });
        var moreDataAvailable = (this.startRow + this.retrieveSize - 1) < this.state.totalCount;
        var shouldGetMoreData = (this.startRow + this.retrieveSize) < this.maxRowsToRetrieve;
        if (moreDataAvailable && shouldGetMoreData) {
            setTimeout(function () { this.loadDataLazy(); }.bind(this), 100);
        }
    };
    HierarchicalDocument.prototype.loadData_failure = function (exception) {
        globalFunctions.hide_spinner();
        globalFunctions.display_error($get(this.props.messageBoxId), exception);
    };
    HierarchicalDocument.prototype.setVisibleData = function (items, pageSize, visiblePage, totalCount, callback, callbackParam) {
        var startRow = 1 + (pageSize * (visiblePage - 1)), endOfPage = pageSize * visiblePage, endRow = totalCount < (endOfPage) ? totalCount : endOfPage;
        this.pageMoveTemp = null;
        this.setState({
            itemsVisible: items.slice(startRow - 1, endRow),
            visibleEndRow: endRow > this.maxRowsToRetrieve ? this.maxRowsToRetrieve : endRow,
            visiblePage: visiblePage,
            visiblePageInput: visiblePage,
            visibleStartRow: startRow,
            changesCount: 0,
            idsInEditMode: [],
        }, function () { callback && callback(callbackParam); });
        window.onbeforeunload = null;
        SpiraContext.uiState.hierarchicalDocumentHasChanges = false;
    };
    HierarchicalDocument.prototype.pageMove = function (newPage, callback, callbackParam, forceMove) {
        var canMove = newPage > 0 && newPage <= Math.ceil(this.state.totalCount / this.pageSize);
        if (canMove) {
            if (this.state.changesCount === 0 || forceMove) {
                this.startRow = (this.pageSize * (newPage - 1)) + 1;
                if (this.state.itemsAll.length >= this.startRow) {
                    this.setVisibleData(this.state.itemsAll, this.pageSize, newPage, this.state.totalCount, callback, callbackParam);
                }
            }
            else {
                this.pageMoveTemp = [newPage, callback, callbackParam];
                globalFunctions.globalConfirm(resx.AjxFormManager_UnsavedChanges, "info", this.pageMoveConfirmed);
            }
        }
    };
    HierarchicalDocument.prototype.pageMoveConfirmed = function (shouldMove) {
        if (shouldMove) {
            this.pageMove(this.pageMoveTemp[0], this.pageMoveTemp[1], this.pageMoveTemp[2], true);
        }
        else {
            this.pageMoveTemp = null;
            this.setState({
                visiblePageInput: this.state.visiblePage,
            });
        }
    };
    HierarchicalDocument.prototype.handlePageInputChange = function (event) {
        if (event.target.value <= Math.ceil(this.state.totalCount / this.pageSize)) {
            this.setState({ visiblePageInput: event.target.value });
        }
    };
    HierarchicalDocument.prototype.handlePageInputKeyDown = function (event) {
        if (event.key === 'Enter') {
            if (event.target.value > 0 && event.target.value <= Math.ceil(this.state.totalCount / this.pageSize)) {
                this.pageMove(parseInt(event.target.value), null, null, false);
            }
        }
    };
    HierarchicalDocument.prototype.artifactTokenGenerate = function (item) {
        var artifactImage = SpiraContext.BaseThemeUrl + 'Images/';
        if (item.summary) {
            artifactImage += this.props.summaryItemImage;
        }
        else if (item.alternate) {
            artifactImage += this.props.alternateItemImage;
        }
        else {
            artifactImage += this.props.itemImage;
        }
        return artifactImage;
    };
    HierarchicalDocument.prototype.getOutlineCodeFromIndent = function (indent) {
        var indentSplit = indent.toLowerCase().match(/[A-Za-z]{1,3}/g);
        var indentsAsNumbers = indentSplit.map(function (x) {
            var lettersToNumbers = x.split("").map(function (y) { return y.charCodeAt(0) - 97; });
            var index = 1;
            if (lettersToNumbers[2] > 0) {
                index = index + lettersToNumbers[2];
            }
            if (lettersToNumbers[1] > 0) {
                index = index + (lettersToNumbers[1] * 26);
            }
            if (lettersToNumbers[0] > 0) {
                index = index + (lettersToNumbers[0] * 26 * 26);
            }
            return index;
        });
        if (indentSplit.length > 1) {
            return indentsAsNumbers.join(".");
        }
        else {
            return indentsAsNumbers[0];
        }
    };
    HierarchicalDocument.prototype.getArtifactUrlFromTemplate = function (url, primaryKey) {
        return url.replace('{0}', primaryKey).replace('~/', SpiraContext.BaseUrl);
    };
    HierarchicalDocument.prototype.getUploadUrl = function (url, primaryKey, artifactType) {
        return url.replace('{0}', primaryKey + "/" + artifactType).replace('~/', SpiraContext.BaseUrl);
    };
    HierarchicalDocument.prototype.getHeaderFields = function (fields) {
        if (!fields)
            return;
        var headerArray = [];
        for (var prop in fields) {
            if (fields.hasOwnProperty(prop) && fields[prop].fieldType > 0 && fields[prop].fieldType != globalFunctions._fieldType_html && fields[prop].fieldName != "Name") {
                headerArray.push(fields[prop]);
            }
        }
        headerArray.sort(function (a, b) { return a.Name - b.Name; });
        return headerArray;
    };
    HierarchicalDocument.prototype.getRichTextFields = function (fields) {
        if (!fields)
            return;
        var richTextArray = [];
        for (var prop in fields) {
            if (fields.hasOwnProperty(prop) && fields[prop].fieldType == globalFunctions._fieldType_html) {
                richTextArray.push(fields[prop]);
            }
        }
        return richTextArray;
    };
    HierarchicalDocument.prototype.editModeToggle = function (id) {
        if (id && this.state.idsInEditMode) {
            var index = this.state.idsInEditMode.length ? this.state.idsInEditMode.indexOf(id) : -1;
            if (index > -1) {
                var splicedArray = __spreadArray([], this.state.idsInEditMode, true);
                splicedArray.splice(index, 1);
                this.setState({
                    idsInEditMode: splicedArray
                });
            }
            else {
                this.setState({
                    idsInEditMode: __spreadArray(__spreadArray([], this.state.idsInEditMode, true), [id], false)
                });
            }
        }
    };
    HierarchicalDocument.prototype.updateChangesCount = function (increment) {
        if (this.state.changesCount + increment > 0) {
            window.onbeforeunload = function (event) {
                event.preventDefault();
                event.returnValue = "";
            };
            SpiraContext.uiState.hierarchicalDocumentHasChanges = true;
        }
        else {
            window.onbeforeunload = null;
            SpiraContext.uiState.hierarchicalDocumentHasChanges = false;
        }
        this.setState({ changesCount: this.state.changesCount + increment });
    };
    HierarchicalDocument.prototype.render = function () {
        var _this = this;
        var isAtEnd = this.state.visibleEndRow == this.state.totalCount || (this.state.totalCount > this.maxRowsToRetrieve && this.state.visibleEndRow == this.maxRowsToRetrieve);
        var pageCount = Math.ceil(this.state.totalCount / this.pageSize);
        return (React.createElement(React.Fragment, null,
            React.createElement("div", { className: "Header sticky df items-center justify-between h5 w-100 top0 z-3 bg-white bb b-near-white bw2", id: this.props.domId + "-hierarchicalDoc-header", role: "header" },
                this.state.totalCount > 0 ?
                    React.createElement("span", { className: "fw-normal" },
                        this.state.visibleStartRow,
                        "-",
                        this.state.visibleEndRow,
                        " / ",
                        this.state.totalCount)
                    :
                        React.createElement("p", { className: "fw-b fs-110" }, resx.RequirementDocument_NoRequirements),
                this.state.idsInEditMode.length > 0 &&
                    React.createElement("span", null, resx.HierarchicalDocument_EditingTitle.replace("{0}", this.state.idsInEditMode.length).replace("{1}", this.state.changesCount)),
                pageCount > 1 ?
                    React.createElement("div", { className: "mx3", id: this.props.domId + "-hierarchicalDoc-header-page-selector" },
                        React.createElement("div", { class: "mx3 dib" },
                            React.createElement("input", { className: "u-input w6 tr", id: "txt-document-page", onChange: this.handlePageInputChange, onKeyDown: this.handlePageInputKeyDown, value: this.state.visiblePageInput }),
                            " / ",
                            pageCount),
                        React.createElement("div", { className: "btn-group" },
                            React.createElement("button", { className: "btn btn-default lh1 py2 px3", disabled: this.state.visiblePage == 1 ? "true" : "", onClick: this.pageMove.bind(null, this.state.visiblePage - 1, false, false, false), title: resx.Pagination_Previous, type: "button" },
                                React.createElement("i", { className: "fas fa-caret-left" })),
                            React.createElement("button", { className: "btn btn-default lh1 py2 px3", disabled: isAtEnd ? "true" : "", onClick: this.pageMove.bind(null, this.state.visiblePage + 1, false, false, false), title: resx.Pagination_Next, type: "button" },
                                React.createElement("i", { className: "fas fa-caret-right" }))))
                    :
                        React.createElement("div", { id: this.props.domId + "-hierarchicalDoc-header-page-selector" })),
            React.createElement("div", { className: "Body ", id: this.props.domId + "-hierarchicalDoc-body", role: "body" }, this.state.itemsVisible && this.state.itemsVisible.map(function (item, i) {
                return React.createElement(HierarchicalDocumentBodyItem, { key: item.primaryKey, index: i, item: item, headerFields: _this.getHeaderFields(item.Fields), richTextFields: _this.getRichTextFields(item.Fields), artifactToken: _this.props.artifactToken, artifactImage: _this.artifactTokenGenerate(item), artifactUrl: _this.getArtifactUrlFromTemplate(_this.props.urlTemplate, item.primaryKey), imageUploadUrl: _this.getUploadUrl(_this.props.urlUploadTemplate, item.primaryKey, _this.props.artifactType), outlineCode: _this.props.showOutlineCode ? _this.getOutlineCodeFromIndent(item.indent) : null, canEdit: _this.userCanBulkEdit, editModeToggle: _this.editModeToggle, updateChangesCount: _this.updateChangesCount, webServiceClass: _this.props.webServiceClass, domId: _this.props.domId, messageBoxId: _this.props.messageBoxId, reloadAll: _this.reload });
            })),
            (isAtEnd && this.state.totalCount > this.maxRowsToRetrieve) ?
                React.createElement("div", { className: "ma4 alert alert-inf" }, resx.MoreArtifactsThanCanDisplay)
                : null));
    };
    return HierarchicalDocument;
}(React.Component));
var HierarchicalDocumentBodyItem = (function (_super) {
    __extends(HierarchicalDocumentBodyItem, _super);
    function HierarchicalDocumentBodyItem(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            original_Name: _this.props.item.Fields.Name.textValue,
            current_Name: _this.props.item.Fields.Name.textValue,
            concurrencyValue: _this.props.item.concurrencyValue,
            isEditing: false,
            hasChanges: false,
            errorFields: [],
        };
        _this.editor = null;
        _this.cancelEdit = _this.cancelEdit.bind(_this);
        _this.cancelEditConfirmed = _this.cancelEditConfirmed.bind(_this);
        _this.enableEdit = _this.enableEdit.bind(_this);
        _this.saveChanges = _this.saveChanges.bind(_this);
        _this.saveChanges_success = _this.saveChanges_success.bind(_this);
        _this.saveChanges_failure = _this.saveChanges_failure.bind(_this);
        _this.handleNameChange = _this.handleNameChange.bind(_this);
        _this.ref = React.createRef();
        return _this;
    }
    HierarchicalDocumentBodyItem.prototype.componentDidMount = function () {
        var _this = this;
        this.props.richTextFields.forEach(function (field) {
            var _a;
            _this.setState((_a = {},
                _a["original_" + field.fieldName] = field.textValue,
                _a["current_" + field.fieldName] = field.textValue,
                _a));
        });
    };
    HierarchicalDocumentBodyItem.prototype.enableEdit = function (event) {
        if (this.props.canEdit) {
            event.preventDefault();
            this.props.editModeToggle(this.props.item.primaryKey);
            this.setState({ isEditing: true });
        }
    };
    HierarchicalDocumentBodyItem.prototype.scrollIntoView = function () {
        if (this.ref.current) {
            this.ref.current.scrollIntoView();
        }
    };
    HierarchicalDocumentBodyItem.prototype.cancelEdit = function () {
        if (this.state.hasChanges) {
            globalFunctions.globalConfirm(resx.AjxFormManager_UnsavedChanges, "info", this.cancelEditConfirmed);
        }
        else {
            this.cancelEditConfirmed(true);
        }
    };
    HierarchicalDocumentBodyItem.prototype.cancelEditConfirmed = function (shouldCancel) {
        var _this = this;
        if (shouldCancel) {
            this.props.editModeToggle(this.props.item.primaryKey);
            if (this.state.hasChanges) {
                this.props.updateChangesCount(-1);
            }
            this.props.richTextFields.forEach(function (field) {
                var _a;
                _this.setState((_a = {},
                    _a["current_" + field.fieldName] = _this.state["original_" + field.fieldName],
                    _a));
            });
            this.setState({
                current_Name: this.state.original_Name,
                hasChanges: false,
                isEditing: false,
            });
        }
    };
    HierarchicalDocumentBodyItem.prototype.saveChanges = function () {
        var _this = this;
        if (this.state.hasChanges) {
            if (!this.state.current_Name.trim()) {
                globalFunctions.globalAlert(resx.FormValidation_FillInRequiredFields, "error", true, "fas fa-exclamation-triangle");
                this.setState({ errorFields: [this.props.item.Fields.Name.fieldName] });
            }
            else {
                globalFunctions.display_spinner();
                var dataItem_1 = JSON.parse(JSON.stringify(this.props.item));
                dataItem_1.Fields.Name.textValue = this.state.current_Name;
                dataItem_1.concurrencyValue = this.state.concurrencyValue;
                this.props.richTextFields.forEach(function (field) {
                    dataItem_1.Fields[field.fieldName].textValue = _this.state["current_" + field.fieldName];
                });
                var self_1 = this;
                this.props.webServiceClass.HierarchicalDocument_Save(SpiraContext.ProjectId, dataItem_1, self_1.saveChanges_success, self_1.saveChanges_failure);
            }
        }
    };
    HierarchicalDocumentBodyItem.prototype.saveChanges_success = function (messages) {
        var _this = this;
        globalFunctions.hide_spinner();
        var hasMessages = messages && messages.length ? true : false;
        var errorMessages = hasMessages && messages.filter(function (message) { return message.FieldName === null || (message.FieldName && message.FieldName.indexOf("$") !== 0); });
        var newConcurrency = hasMessages && messages.filter(function (message) { return message.FieldName && message.FieldName.indexOf("$newConcurrency") == 0; });
        if (errorMessages.length) {
            var documentFields_1 = [];
            for (var prop in this.props.item.Fields) {
                documentFields_1.push(this.props.item.Fields[prop].fieldName);
            }
            var errorFields = errorMessages.filter(function (message) { return message.FieldName !== null; }).map(function (message) { return message.FieldName; });
            var documentErrorFields = errorFields.length ? errorFields.filter(function (field) { return documentFields_1.indexOf(field) >= 0; }) : [];
            this.setState({ errorFields: documentErrorFields });
            var alertMessage = errorMessages.map(function (message) { return message.Message; }).join("\n");
            if (errorFields.length && documentErrorFields.length < errorFields.length) {
                alertMessage += " " + resx.HierarchicalDocument_ErrorsInFieldsNotVisible;
            }
            globalFunctions.globalAlert(alertMessage, "error", true, "fas fa-exclamation-triangle");
        }
        else if (newConcurrency) {
            this.props.editModeToggle(this.props.item.primaryKey);
            this.props.updateChangesCount(-1);
            this.props.richTextFields.forEach(function (field) {
                var _a;
                var editor = _this.state["editor_" + field.fieldName];
                editor.isReadOnly = true;
                _this.setState((_a = {},
                    _a["original_" + field.fieldName] = _this.state["current_" + field.fieldName],
                    _a));
            });
            this.setState({
                original_Name: this.state.current_Name,
                concurrencyValue: newConcurrency[0].Message,
                hasChanges: false,
                errorFields: [],
                isEditing: false,
            });
        }
        else {
            this.props.reloadAll();
        }
    };
    HierarchicalDocumentBodyItem.prototype.saveChanges_failure = function (exception) {
        globalFunctions.hide_spinner();
        var messages = exception.map(function (x) { return x.FieldName + ": " + x.Message; }).join("\n");
        globalFunctions.globalAlert(messages, "error", true, "fas fa-exclamation-triangle");
    };
    HierarchicalDocumentBodyItem.prototype.handleNameChange = function (event) {
        var errorFields = __spreadArray([], this.state.errorFields, true);
        var index = errorFields.length ? errorFields.indexOf(this.props.item.Fields.Name.fieldName) : -1;
        if (event.target.value && event.target.value.trim()) {
            if (index > -1) {
                errorFields.splice(index, 1);
            }
        }
        else if (index === -1) {
            errorFields.push(this.props.item.Fields.Name.fieldName);
        }
        this.setState({
            current_Name: event.target.value,
            errorFields: errorFields
        }, this.setHasChanges);
    };
    HierarchicalDocumentBodyItem.prototype.handleRichTextFieldChange = function (event, editor, fieldName) {
        var _a, _b;
        var data = this.state["editor_" + fieldName].getData();
        var index = this.state.errorFields.length ? this.state.errorFields.indexOf(fieldName) : -1;
        if (index > -1) {
            var errorFields = __spreadArray([], this.state.errorFields, true);
            if (data.length) {
                errorFields.splice(index, 1);
                this.setState((_a = {},
                    _a["current_" + fieldName] = data,
                    _a.errorFields = errorFields,
                    _a), this.setHasChanges);
            }
        }
        else {
            this.setState((_b = {}, _b["current_" + fieldName] = data, _b), this.setHasChanges);
        }
    };
    HierarchicalDocumentBodyItem.prototype.setHasChanges = function () {
        var _this = this;
        var nameHasChanges = this.state.original_Name != this.state.current_Name;
        var richTextHasChanges = this.props.richTextFields.some(function (field) {
            return _this.state["original_" + field.fieldName] != _this.state["current_" + field.fieldName];
        });
        var hasChanges = nameHasChanges || richTextHasChanges;
        if (this.state.hasChanges !== hasChanges) {
            var newChangesIncrement = this.state.hasChanges ? -1 : 1;
            this.props.updateChangesCount(newChangesIncrement);
        }
        this.setState({ hasChanges: hasChanges });
    };
    HierarchicalDocumentBodyItem.prototype.render = function () {
        var _this = this;
        return (React.createElement("div", { className: "hierarchical-body-item bg-border py-3 px-4 fs-14 border-radius-default mb1" + (this.props.index > 0 ? " mt5" : ""), style: { marginLeft: ((this.props.item.indent.length - 3) * 10) + 'px' }, ref: this.ref, role: "treeitem", "aria-label": this.props.artifactToken + ':' + this.props.item.primaryKey, "data-primarykey": this.props.item.primaryKey },
            React.createElement("div", { className: "fs-14 fw-medium d-flex align-items-center mb-3 gap-2" + (this.state.isEditing ? " bg-peach-light" : " bg-white") },
                React.createElement("h2", { className: "fs-16 fw-medium mb-0 d-flex align-items-center" + (this.props.item.summary ? " fw-b" : ""), role: "heading" },
                    React.createElement("img", { src: this.props.artifactImage, className: "w-h-16 mr3" }),
                    this.props.outlineCode &&
                        React.createElement("span", { className: "mr3 fs-h6 fw-normal" }, this.props.outlineCode),
                    !this.state.isEditing ?
                        React.createElement("a", { className: "tdn transition-all", href: this.props.artifactUrl }, this.state.current_Name)
                        :
                            React.createElement("input", { className: "u-input pa0 mbn1 grow-1" + (this.state.errorFields.includes(this.props.item.Fields.Name.fieldName) ? " validation-error" : ""), value: this.state.current_Name, onChange: this.handleNameChange }),
                    React.createElement("span", { className: "fs-h5 light-silver ms-2" },
                        "[",
                        this.props.artifactToken,
                        ":",
                        this.props.item.primaryKey,
                        "]")),
                this.props.canEdit ?
                    !this.state.isEditing ?
                        React.createElement("button", { type: "button", className: "df pa3 o-50 o-100-hover u-btn-minimal transition-all", onClick: this.enableEdit },
                            React.createElement("i", { class: "hierarchical-body-item-edit fas fa-edit" }))
                        :
                            React.createElement("div", { role: "group", className: "dif" },
                                React.createElement("button", { type: "button", className: "df pa3 u-btn-minimal transition-all" + (this.state.hasChanges ? " orange scale-150" : " o-50"), onClick: this.saveChanges, disabled: !this.state.hasChanges && !this.state.errorFields.length },
                                    React.createElement("i", { class: "fas fa-save" })),
                                React.createElement("button", { type: "button", className: "df pa3 u-btn-minimal", onClick: this.cancelEdit },
                                    React.createElement("i", { class: "fas fa-times 45" })))
                    : null),
            React.createElement("div", { className: "hierarchical-body-item-fields fs-14 fw-medium desc-wrapper" }, this.props.headerFields && this.props.headerFields.map(function (field, i) {
                return React.createElement("div", { className: " mr5 my2  d-flex flex-column gap-1", "aria-label": field.fieldName, key: i },
                    React.createElement("span", { className: "Caption fs-14 fw-normal vm-midgrey" }, field.caption),
                    React.createElement("span", { className: "Value df fs-16 fw-bold " + (field.cssClass ? (field.cssClass.charAt(0) == "#" ? " px3 br2 black-always" : " " + field.cssClass) : "") + (field.tooltip ? " has-tooltip" : ""), style: (field.cssClass && field.cssClass.charAt(0) == "#") ? { backgroundColor: field.cssClass } : null },
                        field.tooltip &&
                            React.createElement("div", { class: "is-tooltip" }, field.tooltip),
                        field.textValue ?
                            field.textValue
                            :
                                field.equalizerGray >= 0 ?
                                    React.createElement(EqualizerMiniChart, { field: field })
                                    :
                                        resx.Global_None2));
            })),
            this.props.richTextFields.map(function (field, i) {
                return React.createElement(React.Fragment, { key: i },
                    _this.props.richTextFields.length > 1 &&
                        React.createElement("label", { className: "mt-4 fw-semibold fs-16" + (field.tooltip ? " has-tooltip cursor-default" : "") },
                            field.tooltip &&
                                React.createElement("div", { class: "is-tooltip" }, field.tooltip),
                            field.caption,
                            ":"),
                    !_this.state.isEditing ?
                        React.createElement("div", { className: "mt-2 fs-14 description-style" },
                            React.createElement("div", { dangerouslySetInnerHTML: { __html: filterXSS(_this.state["current_" + field.fieldName], filterXssInlineStyleOptions) } }))
                        :
                            React.createElement("div", { className: "ml5 ml0-xs pl3 mt0 br3 wb-word responsive-images" + (_this.state.errorFields.includes(field.fieldName) ? " validation-error" : "") },
                                React.createElement(RctCkeditor.CKEditor, { editor: CKEDITOR.InlineEditor, data: _this.state["current_" + field.fieldName], config: {
                                        simpleUpload: { uploadUrl: _this.props.imageUploadUrl }
                                    }, onReady: function (editor) {
                                        _this.state["editor_" + field.fieldName] = editor;
                                    }, onChange: function (event, editor) {
                                        _this.handleRichTextFieldChange(event, editor, field.fieldName);
                                    }, onBlur: function (event, editor) {
                                    }, onFocus: function (event, editor) {
                                    } })));
            }),
            (this.props.item.Fields._Diagram && this.props.item.Fields._Diagram.textValue) &&
                React.createElement(HierarchicalDocumentBodyItemDiagram, { item: this.props.item, domId: this.props.domId, messageBoxId: this.props.messageBoxId })));
    };
    return HierarchicalDocumentBodyItem;
}(React.Component));
var HierarchicalDocumentBodyItemDiagram = (function (_super) {
    __extends(HierarchicalDocumentBodyItemDiagram, _super);
    function HierarchicalDocumentBodyItemDiagram(props) {
        return _super.call(this, props) || this;
    }
    HierarchicalDocumentBodyItemDiagram.prototype.componentWillMount = function () {
        this.dotNotation = null;
        if (this.props.item.Fields._Diagram && this.props.item.Fields._Diagram.textValue) {
            this.svgDomId = newId(this.props.domId);
            this.dotNotation = this.props.item.Fields._Diagram.textValue;
        }
    };
    HierarchicalDocumentBodyItemDiagram.prototype.componentDidMount = function () {
        if (this.dotNotation && this.svgDomId) {
            if (Array.prototype['find']) {
                this.renderDiagram(this.dotNotation, this.svgDomId);
            }
            else {
                $get(this.svgDomId).style.height = '0px';
            }
        }
    };
    HierarchicalDocumentBodyItemDiagram.prototype.renderDiagram = function (dotNotation, svgDomId) {
        try {
            var inner = $("#" + svgDomId + " g")[0];
            globalFunctions.clearContent(inner);
            if (dotNotation) {
                g = graphlibDot.read(dotNotation);
                if (!g.graph().hasOwnProperty("marginx") &&
                    !g.graph().hasOwnProperty("marginy")) {
                    g.graph().marginx = 20;
                    g.graph().marginy = 20;
                }
                g.graph().transition = function (selection) {
                    return selection.transition().duration(500);
                };
                d3.select("#" + svgDomId + " g").call(render, g);
                var svgUseCaseDiagram = $get(svgDomId);
                var bBox = svgUseCaseDiagram.getBBox();
                var unscaled_width = parseInt(bBox.width + 100);
                var unscaled_height = parseInt(bBox.height + 80);
                svgUseCaseDiagram.style.width = unscaled_width + 'px';
                if (unscaled_height > 80) {
                    svgUseCaseDiagram.style.height = unscaled_height + 'px';
                }
                else {
                    svgUseCaseDiagram.style.height = '0px';
                }
            }
        }
        catch (err) {
            globalFunctions.display_error_message($get(this.props.messageBoxId), err);
        }
    };
    HierarchicalDocumentBodyItemDiagram.prototype.render = function () {
        var that = this;
        if (this.dotNotation && this.svgDomId) {
            return (React.createElement("div", { className: "Diagram ml5 ml0-xs dn-xs" },
                React.createElement("svg", { id: this.svgDomId, class: "graphviz-hierarchical graphviz-large-text" },
                    React.createElement("g", null))));
        }
        else {
            return null;
        }
    };
    return HierarchicalDocumentBodyItemDiagram;
}(React.Component));
var EqualizerMiniChart = function (props) {
    var WIDTH_DEFAULT = 110;
    return (React.createElement("div", { className: "equalizer df br2 ov-hidden " + (props.widthClass && !props.widthPixels ? " " + props.widthClass : ""), style: { width: props.widthPixels || WIDTH_DEFAULT + "px" } },
        props.field.equalizerGreen ?
            React.createElement("span", { className: "EqualizerGreen", style: { width: props.field.equalizerGreen + "%" } })
            : null,
        props.field.equalizerRed ?
            React.createElement("span", { className: "EqualizerRed", style: { width: props.field.equalizerRed + "%" } })
            : null,
        props.field.equalizerOrange ?
            React.createElement("span", { className: "EqualizerOrange", style: { width: props.field.equalizerOrange + "%" } })
            : null,
        props.field.equalizerYellow ?
            React.createElement("span", { className: "EqualizerYellow", style: { width: props.field.equalizerYellow + "%" } })
            : null,
        props.field.equalizerGray ?
            React.createElement("span", { className: "EqualizerGray", style: { width: props.field.equalizerGray + "%" } })
            : null));
};
//# sourceMappingURL=rct_comp_hierarchicalDocument.js.map