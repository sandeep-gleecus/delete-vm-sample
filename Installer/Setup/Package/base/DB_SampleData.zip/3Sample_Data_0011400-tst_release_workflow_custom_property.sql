/***************************************************************
**	Insert script for table TST_RELEASE_WORKFLOW_CUSTOM_PROPERTY
***************************************************************/
INSERT INTO TST_RELEASE_WORKFLOW_CUSTOM_PROPERTY
(
RELEASE_WORKFLOW_ID, RELEASE_STATUS_ID, WORKFLOW_FIELD_STATE_ID, CUSTOM_PROPERTY_ID
)
VALUES
(
1, 3, 1, 8
),
(
1, 3, 1, 9
),
(
1, 4, 1, 8
),
(
1, 4, 1, 9
)
GO

